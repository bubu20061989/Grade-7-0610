Engine.register({
  id: 'leadin-compare', section: 'Lead-in', title: 'Compare herbivores & carnivores', mech: 'quiz', bg: 'leadin',
  render(root, ctx) {
    const q = h('div', { class: 'task' });
    q.innerHTML = 'Compare the digestive systems of <span class="hl-h">herbivores</span> and <span class="hl-c">carnivores</span>.';
    root.appendChild(h('div', { class: 'headrow fixed' }, [h('div', { class: 'pill', text: 'Lead-in' }), q]));
    root.appendChild(h('div', { class: 'note fixed opt-note', text: 'Look at the pictures. Choose the correct word.' }));
    const grow = h('div', { class: 'grow nofold stagger', style: 'display:flex;flex-direction:column;gap:clamp(8px,1.6vh,18px)' });
    grow.appendChild(h('div', { class: 'photo hero-img keep' }, [ctx.img('assets/img/image22.png', { alt: 'Digestive systems of a herbivore (rabbit) and a carnivore (fox)' })]));
    const a = Lab.ich(ctx, ['longer', 'shorter'], 0);
    const b = Lab.ich(ctx, ['more', 'less'], 0);
    const box = h('div', { class: 'passage fixed' });
    box.append(
      Lab.para('1. The digestive system / intestine in <b class="hl-h">herbivores</b> is [[a]] than in <b class="hl-c">carnivores</b>.', { a }),
      Lab.para('2. The <b class="hl-h">herbivores’</b> appendix develops [[b]] than <b class="hl-c">carnivores’</b>.', { b })
    );
    root.append(grow, box);
    const g = Lab.ichGroup([a, b]);
    root.appendChild(ctx.buttons({ check: g.check, show: g.show, reset: g.reset }));
  }
});
