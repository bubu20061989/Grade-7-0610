Engine.register({
  id: 'vocab-match', section: 'Vocabulary', title: 'Match the words', mech: 'match', bg: 'vocab',
  render(root, ctx) {
    const W = [
      ['ingestion', '/ɪnˈdʒes.tʃən/', 'sự đưa thức ăn vào cơ thể'],
      ['digestion', '/daɪˈdʒes.tʃən/', 'sự tiêu hoá'],
      ['absorption', '/əbˈzɔːrp.ʃən/', 'sự hấp thụ'],
      ['digestive system', '/daɪˈdʒes.tɪv ˌsɪs.təm/', 'hệ tiêu hoá'],
      ['excretion', '/ɪkˈskriː.ʃən/', 'sự bài tiết']
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each new word to its pronunciation and meaning' }));
    const items = W.map(r => ({ id: r[0], label: r[0] }));
    const zones = W.map(r => ({ id: 'z-' + r[0], accept: [r[0]], capacity: 1 }));
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'card bin slot' }) });
    const grid = h('div', { class: 'matchrows stagger' });
    ctx.shuffle(W).forEach(r => {
      const m = h('div', { class: 'mean' }); m.textContent = r[2];
      grid.append(dd.zoneEls['z-' + r[0]], h('div', { class: 'ipa', text: r[1] }), m);
    });
    root.appendChild(h('div', { class: 'grow center-col nofold' }, [grid]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
