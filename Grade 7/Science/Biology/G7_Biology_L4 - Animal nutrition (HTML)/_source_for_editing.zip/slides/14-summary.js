Engine.register({
  id: 'summary', section: 'Consolidation', title: 'What we learned', mech: 'review', bg: 'cream2',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap a word to hear it · Tick what you can do' }));
    const card = h('div', { class: 'stagecard stagger' });
    const chips = h('div', { class: 'vchips' });
    const C = ['c-yel', 'c-blu', 'c-pnk', 'c-grn', 'c-org'];
    ['ingestion', 'digestion', 'digestive system', 'absorption', 'excretion'].forEach((w, i) => {
      const b = h('button', { class: 'vchip ' + C[i], text: w });
      ctx.on(b, 'click', () => Sound.speak(w));
      chips.appendChild(b);
    });
    card.appendChild(chips);
    const L = ['I know the words: ingestion, digestion, digestive system, absorption, excretion.', 'I understand the role of the digestive system in animal nutrition.', 'I will prepare the next lesson.'];
    let n = 0;
    const st = h('div', { class: 'starbig' });
    const paint = () => {
      st.innerHTML = '';
      const s = Engine.stars || 0;
      st.append(h('div', { class: 'num', text: '⭐ ' + s }),
        h('div', { class: 'lbl', text: n === L.length ? (s > 0 ? 'Great work today!' : 'Well done — try the activities again for stars!') : (s > 0 ? 'Stars earned in this lesson' : 'Do the activities to earn stars') }));
    };
    L.forEach(t => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => {
        const on = b.classList.toggle('on'); b.firstChild.textContent = on ? '✓' : '';
        n += on ? 1 : -1; Sound.playEffect('click');
        if (n === L.length) Engine.confetti('star');
        paint();
      });
      card.appendChild(b);
    });
    card.appendChild(st);
    paint();
    root.appendChild(h('div', { class: 'grow center-col nofold' }, [card]));
  }
});
