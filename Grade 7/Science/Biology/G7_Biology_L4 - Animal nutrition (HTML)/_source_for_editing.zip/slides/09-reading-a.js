Engine.register({
  id: 'reading-a', section: 'Reading', title: 'Reading (1): types of digestive systems', mech: 'quiz', bg: 'sort',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Reading' }));
    root.appendChild(h('div', { class: 'task fixed', text: 'Task 3: Read the passage and choose the correct word (1–5).' }));
    /* các phương án đều lấy từ khung từ gốc của bài: reabsorbs, absorption, breakdown, elimination, ingestion, Ruminants, digestion */
    const c1 = Lab.ich(ctx, ['Ruminants', 'breakdown'], 0);
    const c2 = Lab.ich(ctx, ['digestion', 'ingestion'], 1);
    const c3 = Lab.ich(ctx, ['digestion', 'absorption'], 0);
    const c4 = Lab.ich(ctx, ['elimination', 'absorption'], 1);
    const c5 = Lab.ich(ctx, ['elimination', 'reabsorbs'], 0);
    const box = h('div', { class: 'passage' });
    box.appendChild(h('div', { class: 'ptitle', text: 'Types of digestive systems' }));
    box.appendChild(Lab.para('Different animals have different digestive systems to meet their dietary needs. Humans and many other animals have monogastric digestive systems with a single-chambered stomach. A bird’s digestive system has a gizzard. It helps to crush food into smaller pieces. This makes up for their inability to chew. (1) [[c1]] eat large amounts of plant materials and have a multi-chambered stomach to help digest those materials. Processing food involves (2) [[c2]] <span class="gloss">(eating)</span>, (3) [[c3]] <span class="gloss">(mechanical and enzymatic breakdown of large molecules)</span>, (4) [[c4]] <span class="gloss">(cellular uptake of nutrients)</span>, and (5) [[c5]] <span class="gloss">(removal of undigested waste as feces)</span>.', { c1, c2, c3, c4, c5 }));
    root.appendChild(h('div', { class: 'grow center-col stagger nofold' }, [box]));
    const g = Lab.ichGroup([c1, c2, c3, c4, c5]);
    const br = ctx.buttons({ check: g.check, show: g.show, reset: g.reset });
    br.classList.add('tight'); root.appendChild(br);
  }
});
