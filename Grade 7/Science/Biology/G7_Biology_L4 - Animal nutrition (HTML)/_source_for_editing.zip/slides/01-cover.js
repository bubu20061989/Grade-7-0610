Engine.register({
  id: 'cover', section: 'Lesson 4', title: 'Animal Nutrition', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover rev stagger' });
    const media = h('div', { class: 'cover-media mascot' });
    const sci = ctx.img('assets/img/image4.png', { alt: 'A scientist looking into a microscope', zoom: false, class: 'hero-img float-anim' });
    ctx.on(sci, 'click', () => {
      sci.classList.remove('nudge'); void sci.offsetWidth; sci.classList.add('nudge');
      Sound.speak('Welcome to Biology, Lesson 4: Animal Nutrition!');
    });
    media.appendChild(sci);

    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Science · Biology' })]));
    const t = h('div', { class: 'hero-title' });
    t.innerHTML = '<span class="l1">Biology · Lesson 4</span>Animal <em>Nutrition</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => { Engine.confetti('star'); Engine.next(); });
    txt.append(t, h('div', { class: 'hero-sub', text: '👆 Tap the scientist to say hello' }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
