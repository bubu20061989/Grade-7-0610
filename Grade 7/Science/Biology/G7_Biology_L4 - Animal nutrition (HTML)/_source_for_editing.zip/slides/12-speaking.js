Engine.register({
  id: 'speaking', section: 'Speaking', title: 'Share your diet', mech: 'speak', bg: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Speaking' }));
    root.appendChild(h('div', { class: 'task fixed', text: 'Watch this video and share your diet to stay healthy.' }));
    const v = h('video', { class: 'vid', src: 'assets/video/media3.mp4', poster: 'assets/img/poster3.jpg', controls: '', preload: 'metadata', playsinline: '' });
    ctx.on(v, 'play', () => Sound.stopAll());
    ctx._off.push(() => { try { v.pause(); } catch (e) { } });
    const media = h('div', { class: 'media' }, [h('div', { class: 'vidwrap' }, [v])]);
    const T = ['I usually eat …', 'I drink …', 'To stay healthy, I …'];
    const card = h('div', { class: 'stagecard', style: 'width:100%' });
    card.appendChild(h('div', { class: 'qtitle', style: 'font-size:var(--f-h2);font-weight:800;color:var(--accent);font-family:var(--font-display)', text: 'My healthy diet' }));
    T.forEach(t => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => { const on = b.classList.toggle('on'); b.firstChild.textContent = on ? '✓' : ''; Sound.playEffect('click'); });
      card.appendChild(b);
    });
    const tm = h('button', { class: 'btn btn-primary', text: '⏱ 60s' });
    ctx.on(tm, 'click', () => Engine.timer(60));
    card.appendChild(h('div', { class: 'btnrow' }, [tm]));
    root.appendChild(h('div', { class: 'split speak nofold stagger' }, [media, h('div', {}, [card])]));
  }
});
