Engine.register({
  id: 'consolidation-video', section: 'Consolidation', title: 'Nutrition in animals (video)', mech: 'video', bg: 'cream2',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    root.appendChild(h('div', { class: 'note fixed', text: '▶ Watch: Nutrition in animals' }));
    const v = h('video', { class: 'vid', src: 'assets/video/media4.mp4', poster: 'assets/img/image54.png', controls: '', preload: 'metadata', playsinline: '' });
    root.appendChild(h('div', { class: 'grow vidwrap stagger' }, [v]));
    ctx.on(v, 'play', () => Sound.stopAll());
    ctx._off.push(() => { try { v.pause(); } catch (e) { } });
  }
});
