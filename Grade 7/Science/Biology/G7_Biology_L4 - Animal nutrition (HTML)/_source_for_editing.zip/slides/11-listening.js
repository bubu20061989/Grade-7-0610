Engine.register({
  id: 'listening', section: 'Listening', title: 'True or False', mech: 'listen', bg: 'cream',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Listening' }));
    root.appendChild(h('div', { class: 'task fixed', text: 'Task 2: Listen and tick True or False for each statement.' }));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [Lab.player(ctx, 'assets/audio/media2.mp3', 'Play the track')]));
    const S = [
      ['a', 'BMI over 25 is underweight.', 1],
      ['b', 'BMI over 30 is obese.', 0],
      ['c', 'Over 4 million people died because of overweight or obesity in 2017.', 0],
      ['d', 'From 1975 to 2016, the overweight or obesity from ages 5 – 19 years increased by more than four times.', 0],
      ['e', 'More people are obese than underweight in Asia.', 1]
    ];
    const tbl = h('div', { class: 'tftable stagger' });
    const list = S.map(([k, t, a]) => {
      const st = h('div', { class: 'st' }); st.innerHTML = '<b>' + k + '.</b>' + t;
      const w = Lab.ich(ctx, ['True', 'False'], a);
      tbl.append(st, w);
      return w;
    });
    root.appendChild(h('div', { class: 'grow center-col nofold' }, [tbl]));
    const g = Lab.ichGroup(list);
    root.appendChild(ctx.buttons({ check: g.check, show: g.show, reset: g.reset }));
  }
});
