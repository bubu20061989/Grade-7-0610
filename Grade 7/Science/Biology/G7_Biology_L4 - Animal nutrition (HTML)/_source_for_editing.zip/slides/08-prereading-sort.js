Engine.register({
  id: 'prereading-sort', section: 'Pre-reading', title: 'Types of digestive systems', mech: 'sort', bg: 'pre',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Pre-reading' }));
    root.appendChild(h('div', { class: 'task fixed', text: 'Look at the picture and answer the questions' }));
    const q1 = h('button', { class: 'qb' }, [h('span', { text: 'How many types of digestive systems are there?' }), h('span', { class: 'ans', text: '👆 Tap for the answer' })]);
    const q2 = h('button', { class: 'qb' }, [h('span', { text: 'Why do you think these animals have different digestive systems?' }), h('span', { class: 'ans', text: '👆 Tap for the answer' })]);
    ctx.on(q1, 'click', () => { q1.lastChild.textContent = 'There are 3 types: avian, monogastric and ruminant.'; Sound.playEffect('click'); });
    ctx.on(q2, 'click', () => { q2.lastChild.textContent = 'To meet their dietary needs.'; Sound.playEffect('click'); });
    root.appendChild(h('div', { class: 'qbubbles fixed' }, [q1, q2]));

    const A = { cat: 'image40.jpeg', cow: 'image38.jpeg', turkey: 'image43.jpeg', pig: 'image36.jpeg', goat: 'image37.jpeg', dog: 'image39.jpeg', chicken: 'image41.jpeg', sheep: 'image42.jpeg' };
    const items = Object.keys(A).map(k => ({ id: k, label: k }));
    const zones = [
      { id: 'avian', label: 'AVIAN', accept: ['chicken', 'turkey'] },
      { id: 'mono', label: 'MONOGASTRICS', accept: ['pig', 'dog', 'cat'] },
      { id: 'rum', label: 'RUMINANTS', accept: ['cow', 'sheep', 'goat'] }
    ];
    const dd = ctx.dragDrop({
      items, zones,
      renderItem: it => h('div', { class: 'ani' }, [h('img', { src: 'assets/img/' + A[it.id], alt: it.id, draggable: 'false' }), h('span', { text: it.id })]),
      renderZone: z => h('div', { class: 'card bin' }, [h('div', { class: 'bin-label', text: z.label })])
    });
    root.appendChild(h('div', { class: 'grow bins3 nofold stagger' }, zones.map(z => dd.zoneEls[z.id])));
    dd.tray.classList.add('oneline');
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
