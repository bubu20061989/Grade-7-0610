Engine.register({
  id: 'prereading-animals', section: 'Pre-reading', title: 'Same digestive system?', mech: 'fact', bg: 'animals',
  render(root, ctx) {
    const A = [['image40.jpeg', 'cat'], ['image38.jpeg', 'cow'], ['image43.jpeg', 'turkey'], ['image36.jpeg', 'pig'],
      ['image37.jpeg', 'goat'], ['image39.jpeg', 'dog'], ['image41.jpeg', 'chicken'], ['image42.jpeg', 'sheep']];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Pre-reading' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap an animal to hear its name' }));
    const grid = h('div', { class: 'anigrid stagger' });
    A.forEach(([f, n]) => {
      const c = h('div', { class: 'acell' }, [ctx.img('assets/img/' + f, { alt: n, zoom: false }), h('div', { class: 'chip', text: n })]);
      ctx.on(c, 'click', () => {
        grid.querySelectorAll('.acell').forEach(x => x.classList.remove('on'));
        c.classList.add('on'); Sound.speak(n);
      });
      grid.appendChild(c);
    });
    root.appendChild(h('div', { class: 'grow nofold', style: 'display:flex;flex-direction:column' }, [grid]));
    const yes = h('button', { class: 'btn', text: '👍 Yes' });
    const no = h('button', { class: 'btn', text: '👎 No' });
    const ans = h('div', { class: 'note fixed', text: ' ' });
    const pick = ok => {
      [yes, no].forEach(b => ctx.clearResult(b));
      ctx.markResult(ok ? no : yes, ok, { sound: true });
      ans.textContent = ok ? 'Right! Different animals have different digestive systems.' : 'Look again: do they all eat the same food?';
      if (ok) Engine.confetti();
    };
    ctx.on(yes, 'click', () => pick(false));
    ctx.on(no, 'click', () => pick(true));
    root.appendChild(h('div', { class: 'vote fixed' }, [h('div', { class: 'q', text: 'Do you think these animals have the same digestive system?' }), yes, no]));
    root.appendChild(ans);
  }
});
