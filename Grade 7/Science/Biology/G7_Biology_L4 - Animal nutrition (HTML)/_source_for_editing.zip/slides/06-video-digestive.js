Engine.register({
  id: 'video-digestive', section: 'Digestive system', title: 'How the digestive system works', mech: 'video', bg: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Digestive system' }));
    root.appendChild(h('div', { class: 'note fixed', text: '▶ Watch: How the digestive system works' }));
    const v = h('video', { class: 'vid', src: 'assets/video/media1.mp4', poster: 'assets/img/poster1.jpg', controls: '', preload: 'metadata', playsinline: '' });
    root.appendChild(h('div', { class: 'grow vidwrap stagger' }, [v]));
    ctx.on(v, 'play', () => Sound.stopAll());
    ctx._off.push(() => { try { v.pause(); } catch (e) { } });
  }
});
