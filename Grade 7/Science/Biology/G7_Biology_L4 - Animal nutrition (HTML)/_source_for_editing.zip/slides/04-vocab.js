Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'New words', mech: 'flashcard', bg: 'vocab',
  render(root, ctx) {
    const W = [
      { w: 'ingestion', ipa: '/ɪnˈdʒes.tʃən/', img: ['image31.png'], c: 'c-yel', vi: 'sự đưa thức ăn vào cơ thể', def: 'the process of absorbing nutrients or medications into the body by eating or drinking them.' },
      { w: 'digestion', ipa: '/daɪˈdʒes.tʃən/', img: ['image31.png'], c: 'c-blu', vi: 'sự tiêu hoá', def: 'the process by which your body digests food, or your ability to digest food.' },
      { w: 'absorption', ipa: '/əbˈzɔːrp.ʃən/', img: ['image31.png', 'image32.png'], c: 'c-pnk', vi: 'sự hấp thụ', def: 'the process of taking something into another substance.' },
      { w: 'digestive system', ipa: '/daɪˈdʒes.tɪv ˌsɪs.təm/', img: ['image33.jpeg'], c: 'c-grn', vi: 'hệ tiêu hoá', def: 'the organs in your body involved with the digestion of food.' },
      { w: 'excretion', ipa: '/ɪkˈskriː.ʃən/', img: ['image34.png'], c: 'c-org', vi: 'sự bài tiết', def: 'the process of getting rid of material such as solid waste or urine from the body.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col nofold stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    grow.append(h('div', { class: 'fc-wrap fill-w', style: 'display:flex;justify-content:center' }, [box]));
    const dots = h('div', { class: 'dots fixed' });
    root.append(grow, dots);

    let i = 0; const seen = {}; let cheered = false;
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      const pics = h('div', { class: 'vimg' });
      v.img.forEach(f => pics.appendChild(ctx.img('assets/img/' + f, { alt: v.w, zoom: false })));
      front.append(pics, h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vipa', text: v.ipa }), h('div', { class: 'vtap', text: '👆 Tap to flip' })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def }), h('div', { class: 'vvi', text: v.vi }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !cheered) { cheered = true; Engine.toast('All 5 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
