Engine.register({
  id: 'goodbye', section: 'Goodbye', title: 'Goodbye', mech: 'outro', bg: 'bye',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media mascot' });
    const t = ctx.img('assets/img/image55.png', { alt: 'A science teacher', zoom: false, class: 'hero-img float-anim' });
    ctx.on(t, 'click', () => { t.classList.remove('nudge'); void t.offsetWidth; t.classList.add('nudge'); Sound.speak('Science is magic that actually works. Goodbye!'); });
    media.appendChild(t);
    const txt = h('div', { class: 'cover-text' });
    const ti = h('div', { class: 'hero-title' }); ti.innerHTML = '<em style="color:#EA580C">Goodbye!</em>';
    const b = h('button', { class: 'btn btn-primary', text: '🎉 See you next lesson' });
    ctx.on(b, 'click', () => Engine.confetti('star'));
    txt.append(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Biology · Lesson 4' })]), ti,
      h('div', { class: 'quote', text: '“Science is magic that actually works.”' }),
      h('div', { class: 'hero-sub', text: '👆 Tap the teacher' }), h('div', { class: 'btnrow' }, [b]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
