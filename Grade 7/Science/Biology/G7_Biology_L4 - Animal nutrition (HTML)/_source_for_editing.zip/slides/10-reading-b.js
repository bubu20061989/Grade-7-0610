Engine.register({
  id: 'reading-b', section: 'Reading', title: 'Reading (2): organs work together', mech: 'cloze', bg: 'sort',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Reading' }));
    root.appendChild(h('div', { class: 'task fixed', text: 'Task 3: Read on and fill in the blanks (6–7).' }));
    const ANS = ['breakdown', 'reabsorbs'];
    const BANK = ['reabsorbs', 'absorption', 'breakdown', 'elimination', 'ingestion', 'Ruminants', 'digestion'];
    const items = BANK.map(w => ({ id: w, label: w }));
    const zones = ANS.map((w, i) => ({ id: 's' + (i + 6), accept: [w], capacity: 1 }));
    const dd = ctx.dragDrop({ items, zones, shuffle: false, renderZone: () => h('span', { class: 'card slot' }) });
    const s = {}; zones.forEach(z => { s[z.id] = dd.zoneEls[z.id]; });
    const box = h('div', { class: 'passage' });
    box.appendChild(h('div', { class: 'ptitle', text: 'Types of digestive systems' }));
    box.appendChild(Lab.para('Many organs work together to digest food and absorb nutrients. The (6) [[s6]] of food begins in the mouth. The food travels through the esophagus to the stomach. Further digestion and absorption take place in the small intestine. The large intestine (7) [[s7]] water and stores waste until elimination.', s));
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/image33.jpeg', { alt: 'The digestive system of a pig' }), ctx.zoomHint()]);
    root.appendChild(h('div', { class: 'split safe text-wide nofold stagger' }, [media, h('div', {}, [box])]));
    root.appendChild(dd.tray);
    const br = ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones), show: () => { Lab.ddClear(ctx, dd); dd.show(); }, reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    });
    br.classList.add('tight'); root.appendChild(br);
  }
});
