Engine.register({
  id: 'leadin-list', section: 'Lead-in', title: 'List the organs', mech: 'order', bg: 'leadin',
  render(root, ctx) {
    const q = h('div', { class: 'task' });
    q.innerHTML = 'List the organs of the digestive system in <span class="hl-h">herbivores</span> and <span class="hl-c">carnivores</span>.';
    root.appendChild(h('div', { class: 'headrow fixed' }, [h('div', { class: 'pill', text: 'Lead-in' }), q]));
    root.appendChild(h('div', { class: 'note fixed opt-note', text: 'Look at the pictures. Drag the organs into boxes 1–5, from top to bottom.' }));

    const ORG = ['esophagus', 'stomach', 'small intestine', 'appendix', 'large intestine'];
    const items = ORG.map(o => ({ id: o, label: o }));
    const zones = ORG.map((o, i) => ({ id: 'z' + i, accept: [o], capacity: 1, n: i + 1 }));
    const dd = ctx.dragDrop({
      items, zones,
      renderZone: z => h('div', { class: 'card bin slot num', 'data-n': String(z.n) })
    });
    const grow = h('div', { class: 'grow nofold stagger', style: 'display:flex;flex-direction:column;gap:clamp(6px,1.2vh,14px)' });
    const pic = h('div', { class: 'photo hero-img keep' }, [ctx.img('assets/img/image22.png', { alt: 'Digestive systems of a herbivore (rabbit) and a carnivore (fox)' })]);
    const row = h('div', { class: 'fixed', style: 'display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:clamp(6px,1vw,14px);flex:0 0 auto' });
    zones.forEach(z => {
      const zn = dd.zoneEls[z.id];
      zn.style.minHeight = 'var(--touch)';
      row.appendChild(zn);
      zn.style.width = '100%';
    });
    grow.append(pic);
    root.append(grow, row);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
