Engine.register({
  id: 'xylem-phloem', section: "Let's learn", title: 'Xylem and phloem diagram', mech: 'explore',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Xylem and Phloem' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Look at the diagram. Tap each card to find out more.' }));
    const all = [];
    const col = (cls, name, img, alt, facts, tubeFirst) => {
      const fx = h('div', { class: 'facts' });
      facts.forEach(f => {
        const b = h('button', { class: 'fact', text: '❓ Tap' });
        b.__t = f;
        ctx.on(b, 'click', () => {
          if (!b.classList.contains('on')) { b.classList.add('on', 'pop-in'); b.textContent = f; }
          Sound.speak(name + '. ' + f);
        });
        all.push(b); fx.appendChild(b);
      });
      const tube = h('div', { class: 'tube' }, [ctx.img('assets/img/' + img, { alt: alt })]);
      const body = h('div', { class: 'xpbody' }, tubeFirst ? [tube, fx] : [fx, tube]);
      return h('div', { class: 'xpcol ' + cls }, [h('div', { class: 'xpname', text: name }), body]);
    };
    const xy = col('xy', 'Xylem', 'image19.png', 'Xylem tube: water moves upwards only', ['One-way flow', 'Water and minerals', 'No end walls between cells'], true);
    const ph = col('ph', 'Phloem', 'image21.png', 'Phloem tube: food moves up and down', ['Two-way flow', 'Water and food', 'End walls with perforations'], false);
    const mid = h('div', { class: 'xpmid' }, [
      h('div', { class: 'flowtag f', text: '⇅ Photosynthesis products' }),
      h('div', { class: 'plant' }, [ctx.img('assets/img/image18.png', { alt: 'A young plant growing in soil' })]),
      h('div', { class: 'flowtag w', text: '⬆ Water and minerals' })
    ]);
    root.appendChild(h('div', { class: 'xp stagger' }, [xy, mid, ph]));
    const bAll = h('button', { class: 'btn btn-show', text: '👁 Show all' });
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bAll, 'click', () => all.forEach(b => { b.classList.add('on'); b.textContent = b.__t; }));
    ctx.on(bR, 'click', () => all.forEach(b => { b.classList.remove('on', 'pop-in'); b.textContent = '❓ Tap'; }));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bAll, bR]));
  }
});
