Engine.register({
  id: 'leadin-roots', section: 'Lead-in', title: 'How does a plant drink?', mech: 'reveal',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'How does a plant drink?' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' }, [
      ctx.img('assets/img/image7.png', { alt: 'A plant in a pot: water moves into the roots and up the plant', class: 'hero-img' }),
      ctx.zoomHint()
    ]);
    const q1 = h('div', { class: 'bubble q' }, [h('span', { class: 'who', text: 'Teacher' }), 'A plant has no mouth. How does it drink water?']);
    const a1 = h('div', { class: 'bubble a wait' });
    const q2 = h('div', { class: 'bubble q wait' });
    const fill = (b, who, t) => { b.innerHTML = ''; b.append(h('span', { class: 'who', text: who }), t); };
    const blank = () => { fill(a1, 'Student', '…'); fill(q2, 'Teacher', '…'); a1.classList.add('wait'); q2.classList.add('wait'); };
    blank();
    const tap = h('button', { class: 'bubble tapme', text: '👆 Tap to answer' });
    const chat = h('div', { class: 'chat' }, [q1, a1, q2, tap]);
    let step = 0;
    const next = () => {
      if (step === 0) {
        fill(a1, 'Student', 'Through its roots.'); a1.classList.remove('wait'); a1.classList.add('pop-in'); Sound.speak('Through its roots.');
        tap.textContent = '👆 Tap for the next question';
      } else if (step === 1) {
        fill(q2, 'Teacher', 'Where does the water go next?'); q2.classList.remove('wait'); q2.classList.add('pop-in'); Sound.speak('Where does the water go next?');
        tap.textContent = '🤔 Think and guess — then go to the next slide!';
      }
      step++;
    };
    ctx.on(tap, 'click', next);
    const say = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak('A plant has no mouth. How does it drink water?'));
    const timer = h('button', { class: 'btn', text: '⏱ 20s' });
    ctx.on(timer, 'click', () => Engine.timer(20));
    const reset = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(reset, 'click', () => { step = 0; blank(); tap.textContent = '👆 Tap to answer'; });
    const right = h('div', {}, [chat, h('div', { class: 'btnrow' }, [say, timer, reset])]);
    sp.append(media, right);
    root.appendChild(sp);
  }
});
