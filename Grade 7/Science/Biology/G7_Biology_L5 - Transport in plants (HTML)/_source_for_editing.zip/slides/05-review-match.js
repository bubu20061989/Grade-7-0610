Engine.register({
  id: 'review-match', section: 'New words', title: 'Review: match the words', mech: 'match',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its picture' }));
    const P = [
      { id: 'epidermal', img: 'image9' }, { id: 'root hairs', img: 'image10' }, { id: 'stomata', img: 'image11' },
      { id: 'transpiration', img: 'image12' }, { id: 'vapor', img: 'image13' }
    ];
    const items = P.map(p => ({ id: p.id, label: p.id }));
    const zones = P.map(p => ({ id: 'z-' + p.id, accept: [p.id], capacity: 1 }));
    this._dd = ctx.dragDrop({
      items, zones,
      renderZone: z => {
        const p = P.find(x => 'z-' + x.id === z.id);
        return h('div', { class: 'dd-zone matcell' }, [ctx.img('assets/img/' + p.img + '.png', { alt: 'Picture for a new word', zoom: false }), h('div', { class: 'slothint', text: 'Drop the word here' })]);
      }
    });
    const grid = h('div', { class: 'imgrid match6' });
    ctx.shuffle(zones).forEach(z => grid.appendChild(this._dd.zoneEls[z.id]));
    const tbl = h('div', { class: 'cell tablecell' }, [
      ctx.img('assets/img/image15.png', { alt: 'Review table: new words, pronunciation and meaning' }),
      h('div', { class: 'chip', text: '🔍 Word table' })
    ]);
    grid.appendChild(tbl);
    const grow = h('div', { class: 'grow stagger', style: 'display:flex;flex-direction:column;min-height:0' }, [grid]);
    root.appendChild(grow);
    root.appendChild(this._dd.tray);
    const dd = this._dd;
    root.appendChild(ctx.buttons({
      check: () => dd.check(),
      show: () => dd.show(),
      reset: () => dd.reset()
    }));
  }
});
