Engine.register({
  id: 'video-xp', section: "Let's learn", title: 'Video: xylem and phloem', mech: 'video',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Watch: Transport in Plants' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Watch the video. Where do water and food go?' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'stagecard vidcard' }, [h('div', { class: 'vidbox' }, [Lab.video(ctx, 'assets/video/media1.mp4')])]);
    grow.appendChild(card);
    root.appendChild(grow);
  }
});
