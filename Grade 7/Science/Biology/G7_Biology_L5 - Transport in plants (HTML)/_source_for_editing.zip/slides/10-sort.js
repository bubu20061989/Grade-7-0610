Engine.register({
  id: 'sort-xp', section: "Let's practice", title: 'Sort: xylem, phloem or both?', mech: 'sort',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Sort the statements' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Work in pairs. Drag each statement to Xylem, Phloem or Both.' }));
    const items = [
      { id: 's1', label: 'Carries water and minerals.' },
      { id: 's2', label: 'Moves substances upwards only.' },
      { id: 's3', label: 'Carries dissolved sugars.' },
      { id: 's4', label: 'Can move substances upwards or downwards.' },
      { id: 's5', label: 'Has end walls with holes.' },
      { id: 's6', label: 'Transports substances around the plant.' }
    ];
    const zones = [
      { id: 'xy', label: 'Xylem', accept: ['s1', 's2'] },
      { id: 'ph', label: 'Phloem', accept: ['s3', 's4', 's5'] },
      { id: 'bo', label: 'Both', accept: ['s6'] }
    ];
    const K = { xy: 'k-xy', ph: 'k-ph', bo: 'k-bo' };
    const dd = ctx.dragDrop({
      items, zones,
      tray: h('div', { class: 'dd-tray statements fixed' }),
      renderZone: z => h('div', { class: 'card dd-zone bin ' + K[z.id] }, [h('div', { class: 'bin-label', text: z.label })])
    });
    const grow = h('div', { class: 'grow stagger', style: 'display:flex;flex-direction:column;min-height:0' }, [
      h('div', { class: 'bins3' }, [dd.zoneEls.xy, dd.zoneEls.ph, dd.zoneEls.bo])
    ]);
    root.appendChild(grow);
    root.appendChild(dd.tray);
    const timer = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(timer, 'click', () => Engine.timer(60));
    const row = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    row.appendChild(timer);
    root.appendChild(row);
  }
});
