Engine.register({
  id: 'leadin-celery', section: 'Lead-in', title: 'The coloured water test', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'The coloured water test' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1fr) minmax(0,1.2fr)' });
    const q = h('div', { class: 'bubble q' }, [h('span', { class: 'who', text: 'Teacher' }), 'The colour moved up the stem. What does this tell us?']);
    const opts = h('div', { class: 'optgrid', style: 'grid-template-columns:minmax(0,1fr);width:100%' });
    const ans = h('div', { class: 'bubble a wait' });
    const setAns = on => { ans.innerHTML = ''; ans.append(h('span', { class: 'who', text: 'Student' }), on ? 'The water moves up the stem.' : '…'); ans.classList.toggle('wait', !on); };
    setAns(false);
    let first = true;
    const OPTS = [['The water moves up the stem.', true], ['The water moves down to the roots.', false]];
    const btns = OPTS.map(([t, ok]) => {
      const b = h('button', { class: 'opt', text: t });
      ctx.on(b, 'click', () => {
        btns.forEach(x => { ctx.clearResult(x); x.classList.remove('picked'); });
        b.classList.add('picked');
        ctx.markResult(b, ok, { sound: !first });
        if (first) { Engine.score(ok ? 1 : 0, 1); first = false; }
        if (ok) { setAns(true); Sound.speak('The water moves up the stem.'); }
      });
      return b;
    });
    opts.append(...btns);
    const left = h('div', {}, [q, opts, ans]);
    const media = h('div', { class: 'media' }, [
      ctx.img('assets/img/image8.png', { alt: 'Celery in blue water; the blue colour moves up the stem', class: 'hero-img' }),
      ctx.zoomHint()
    ]);
    sp.append(left, media);
    root.appendChild(sp);
    const row = h('div', { class: 'btnrow fixed' });
    const bS = h('button', { class: 'btn btn-show', text: '👁 Show answer' });
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bS, 'click', () => { btns.forEach(x => ctx.clearResult(x)); ctx.markResult(btns[0], true); setAns(true); });
    ctx.on(bR, 'click', () => { setAns(false); btns.forEach(x => { ctx.clearResult(x); x.classList.remove('picked'); }); });
    row.append(bS, bR);
    root.appendChild(row);
  }
});
