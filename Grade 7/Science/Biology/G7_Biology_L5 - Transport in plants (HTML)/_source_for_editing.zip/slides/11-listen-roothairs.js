Engine.register({
  id: 'listen-roothairs', section: "Let's practice", title: 'Listen: Root hairs', mech: 'listen',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Listen and fill in the blanks' }));
    const W = ['water', 'tiny', 'longer', 'nutrients', 'dry'];
    const items = W.map(w => ({ id: w, label: w }));
    const zones = W.map((w, i) => ({ id: 'b' + (i + 1), accept: [w], capacity: 1 }));
    const dd = ctx.dragDrop({
      items, zones,
      renderZone: z => h('span', { class: 'dd-zone slot', 'data-n': '(' + z.id.slice(1) + ')' })
    });
    const T = 'Roots have root hairs. They are an extension of plant epidermal cells in growing plant roots. The function of root hairs is to take in (1) [[b1]] and mineral ions from the soil. Root hairs do not live for a very long time. When roots grow, new root hairs appear. Root hairs are very (2) [[b2]], but there are many of them. For example, in <i>Arabidopsis</i>, the root hairs of a plant are about 10 micrometres in diameter and can grow to 1 millimetre or (3) [[b3]]. They increase the surface area of plant roots, help the plant get more water from the soil, and extract (4) [[b4]] more efficiently. Under (5) [[b5]] conditions, root hairs expand the plant’s ability to take in water from the soil.';
    const cut = T.indexOf('For example');
    const p = h('p');
    p.innerHTML = '<span data-pg="1">' + T.slice(0, cut) + '</span><span data-pg="2">' + T.slice(cut) + '</span>';
    p.innerHTML = p.innerHTML.replace(/\(\d\) \[\[(b\d)\]\]/g, '<span data-slot="$1"></span>');
    p.querySelectorAll('[data-slot]').forEach(s => s.replaceWith(dd.zoneEls[s.dataset.slot]));
    const passage = h('div', { class: 'passage' }, [h('div', { class: 'ptitle', text: 'Root hairs' }), p]);
    const top = h('div', { class: 'listenrow fixed' }, [Lab.player(ctx, 'assets/audio/media2.mp3', 'Track 5'), Lab.portrait() ? null : h('span', { class: 'note', text: 'Listen, then drag the words into the gaps' }), Lab.pager(ctx, passage)]);
    root.appendChild(top);
    root.appendChild(h('div', { class: 'grow readgrow stagger' }, [passage]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => { Lab.ddClear(ctx, dd); dd.show(); },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
