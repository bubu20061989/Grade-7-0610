Engine.register({
  id: 'pair-qa', section: "Let's practice", title: 'Ask and answer in pairs', mech: 'quiz',
  render(root, ctx) {
    const Q = [
      { q: 'What types of transport systems do plants have?', o: ['Xylem and phloem', 'Roots and leaves'], a: 0, s: 'Plants have xylem and phloem.' },
      { q: 'Does water move up or down?', o: ['Up', 'Down'], a: 0, s: 'Up.' },
      { q: 'What does phloem carry?', o: ['Water and minerals', 'Sugars / food'], a: 1, s: 'Sugars / food.' },
      { q: 'Which system has walls with holes?', o: ['Xylem', 'Phloem'], a: 1, s: 'Phloem.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Ask and answer' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' }, [
      ctx.img('assets/img/image27.jpeg', { alt: 'Diagram: xylem and phloem in a flowering plant', class: 'hero-img' }),
      ctx.zoomHint()
    ]);
    const cnt = h('div', { class: 'qcount' });
    const qb = h('div', { class: 'bubble q' });
    const opts = h('div', { class: 'optgrid two' });
    const ab = h('div', { class: 'bubble a wait' });
    const qd = h('div', { class: 'qdots' });
    const right = h('div', {}, [cnt, qb, opts, ab, qd]);
    sp.append(media, right);
    root.appendChild(sp);
    let i = 0; const scored = {}; const okd = {};
    const setAns = on => { ab.innerHTML = ''; ab.append(h('span', { class: 'who', text: 'Student B' }), on ? Q[i].s : '…'); ab.classList.toggle('wait', !on); };
    const paint = () => {
      const v = Q[i];
      cnt.textContent = 'Question ' + (i + 1) + ' of ' + Q.length + ' · Student A asks, Student B answers';
      qb.innerHTML = ''; qb.append(h('span', { class: 'who', text: 'Student A' }), v.q);
      setAns(!!okd[i]);
      opts.innerHTML = '';
      v.o.forEach((t, j) => {
        const b = h('button', { class: 'opt', text: t });
        ctx.on(b, 'click', () => {
          opts.querySelectorAll('.opt').forEach(x => { ctx.clearResult(x); x.classList.remove('picked'); });
          b.classList.add('picked');
          const ok = j === v.a;
          ctx.markResult(b, ok, { sound: !!scored[i] });
          if (!scored[i]) { scored[i] = 1; Engine.score(ok ? 1 : 0, 1); }
          if (ok) { okd[i] = 1; setAns(true); Sound.speak(v.s); paintDots(); }
        });
        opts.appendChild(b);
      });
      paintDots();
    };
    const paintDots = () => { qd.innerHTML = ''; Q.forEach((_, k) => qd.appendChild(h('i', { class: k === i ? 'now' : (okd[k] ? 'ok' : '') }))); };
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bSay = h('button', { class: 'btn', text: '🔊 Question' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next question ▶' });
    const bShow = h('button', { class: 'btn btn-show', text: '👁 Show answer' });
    ctx.on(bPrev, 'click', () => { i = (i + Q.length - 1) % Q.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % Q.length; paint(); });
    ctx.on(bSay, 'click', () => Sound.speak(Q[i].q));
    ctx.on(bShow, 'click', () => { const b = opts.children[Q[i].a]; opts.querySelectorAll('.opt').forEach(x => ctx.clearResult(x)); ctx.markResult(b, true); setAns(true); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bShow, bNext]));
    paint();
  }
});
