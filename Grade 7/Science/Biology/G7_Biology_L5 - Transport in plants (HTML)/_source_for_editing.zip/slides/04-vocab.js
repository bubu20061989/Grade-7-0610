Engine.register({
  id: 'vocab', section: 'New words', title: 'New words: flashcards', mech: 'flashcard',
  render(root, ctx) {
    const W = [
      { w: 'epidermal', pos: '(adj)', ipa: '/ˌepɪˈdɜːməl/', img: 'image9', c: 'c-grn', def: 'Related to the outer layer of cells covering a plant.' },
      { w: 'root hairs', pos: '(n)', ipa: '/ˈruːt heəz/', img: 'image10', c: 'c-org', def: 'Tiny extensions of root cells that absorb water and minerals from soil.' },
      { w: 'stomata', pos: '(n)', ipa: '/ˈstəʊmətə/', img: 'image11', c: 'c-mint', def: 'Tiny openings on leaves that let gases and water vapour pass through.' },
      { w: 'transpiration', pos: '(n)', ipa: '/ˌtrænspɪˈreɪʃən/', img: 'image12', c: 'c-blu', def: 'The loss of water vapour from a plant, mainly through its leaves.' },
      { w: 'vapor', pos: '(n)', ipa: '/ˈveɪpə/', img: 'image13', c: 'c-pur', def: 'A substance, such as water, in its gas form.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'New words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    grow.append(h('div', { class: 'fc-wrap fill-w', style: 'display:flex;justify-content:center' }, [box]));
    root.appendChild(grow);
    const dots = h('div', { class: 'dots fixed' });
    root.appendChild(dots);

    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.append(
        h('div', { class: 'vimg' }, [ctx.img('assets/img/' + v.img + '.png', { alt: v.w, zoom: false })]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: v.pos }), h('div', { class: 'vipa', text: v.ipa })]));
      back.append(
        h('div', { class: 'vimg' }, [ctx.img('assets/img/' + v.img + '.png', { alt: v.w, zoom: false })]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def })]));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; Engine.toast('🎉 All 5 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
