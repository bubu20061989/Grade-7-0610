Engine.register({
  id: 'speaking', section: "Let's produce", title: 'Speaking practice', mech: 'speak',
  render(root, ctx) {
    const R = [
      ['Why do plants need water?', 'Plants need water to make food and stay cool.'],
      ['How do plants take in water?', 'They absorb water from the soil through their roots.'],
      ['Where does the water go next?', 'It travels up the stems to the leaves.'],
      ['Which tissue carries water and minerals?', 'Xylem carries water and minerals.'],
      ['How does water help the leaves?', 'The leaves use water to make food during photosynthesis.']
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Speaking Practice' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Work in pairs to ask and answer. Tap a question to hear it.' }));
    const tb = h('div', { class: 'sptable stagger' }, [h('div', { class: 'hd', text: 'Questions' }), h('div', { class: 'hd', text: 'Sample answers' })]);
    const qs = [], as = [];
    R.forEach(([q, a]) => {
      const qb = h('button', { class: 'spq', text: q });
      const ab = h('button', { class: 'spa', text: '👆 Tap to show' });
      ctx.on(qb, 'click', () => { qs.forEach(x => x.classList.remove('cur')); qb.classList.add('cur'); Sound.speak(q); });
      ctx.on(ab, 'click', () => { if (!ab.classList.contains('on')) { ab.classList.add('on', 'pop-in'); ab.textContent = a; } Sound.speak(a); });
      qs.push(qb); as.push(ab); tb.append(qb, ab);
    });
    root.appendChild(h('div', { class: 'grow', style: 'display:flex;flex-direction:column;min-height:0' }, [tb]));
    const bRand = h('button', { class: 'btn btn-primary', text: '🎲 Random question' });
    ctx.on(bRand, 'click', () => {
      const k = Math.floor(Math.random() * R.length);
      qs.forEach(x => x.classList.remove('cur')); qs[k].classList.add('cur', 'nudge');
      ctx.timeout(() => qs[k].classList.remove('nudge'), 400);
      Sound.speak(R[k][0]);
    });
    const bT = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(bT, 'click', () => Engine.timer(60));
    const bS = h('button', { class: 'btn btn-show', text: '👁 Show all' });
    ctx.on(bS, 'click', () => as.forEach((b, i) => { b.classList.add('on'); b.textContent = R[i][1]; }));
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bR, 'click', () => { as.forEach(b => { b.classList.remove('on', 'pop-in'); b.textContent = '👆 Tap to show'; }); qs.forEach(x => x.classList.remove('cur')); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bRand, bT, bS, bR]));
  }
});
