Engine.register({
  id: 'cover', section: 'Start', title: 'Transport in Plants', mech: 'intro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const cl = h('div', { class: 'diacluster' });
    cl.append(
      h('div', { class: 'dia d1', style: 'background-image:url("assets/img/bg-fern.jpg")' }),
      h('div', { class: 'dia d2', style: 'background-image:url("assets/img/bg-leaf.jpg")' }),
      h('div', { class: 'dia d3', style: 'background-image:url("assets/img/bg-palm.jpg")' })
    );
    const core = h('button', { class: 'dcore float-anim', 'aria-label': 'Say the lesson title' });
    core.appendChild(ctx.img('assets/img/image4.png', { alt: 'Leaf', zoom: false }));
    cl.appendChild(core);
    media.appendChild(cl);

    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [
      h('span', { class: 'tag', text: 'Grade 7 · Biology' }),
      h('span', { class: 'tag', text: "Let's Explore English in Sciences 6" })
    ]));
    const t = h('div', { class: 'hero-title' });
    t.innerHTML = '<span class="lsn">Lesson 5</span>Transport in <em>Plants</em>';
    const hint = h('div', { class: 'hero-sub', text: '👆 Tap the leaf to hear the title' });
    ctx.on(core, 'click', () => {
      core.classList.remove('nudge'); void core.offsetWidth; core.classList.add('nudge');
      Sound.speak('Lesson 5. Transport in plants.');
      hint.textContent = 'How does water travel in a plant?';
    });
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, hint, h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
