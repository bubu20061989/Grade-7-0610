Engine.register({
  id: 'learn-intro', section: "Let's learn", title: 'What are xylem and phloem?', mech: 'intro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const cl = h('div', { class: 'diacluster' });
    cl.append(
      h('div', { class: 'dia d1', style: 'background-image:url("assets/img/bg-leaf.jpg")' }),
      h('div', { class: 'dia d2', style: 'background-image:url("assets/img/bg-fern.jpg")' })
    );
    const core = h('div', { class: 'dcore big float-anim' });
    core.appendChild(ctx.img('assets/img/image18.png', { alt: 'A young plant growing in soil', zoom: false }));
    cl.appendChild(core);
    media.appendChild(cl);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: "Let's learn" })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'What are <em>Xylem</em> and <em>Phloem</em>?';
    const bX = h('button', { class: 'btn btn-primary', text: '🔊 xylem' });
    const bP = h('button', { class: 'btn btn-primary', text: '🔊 phloem' });
    ctx.on(bX, 'click', () => Sound.repeat('xylem', 2));
    ctx.on(bP, 'click', () => Sound.repeat('phloem', 2));
    txt.append(t, h('div', { class: 'hero-sub', text: 'Listen and say the two new words' }), h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [bX, bP]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
