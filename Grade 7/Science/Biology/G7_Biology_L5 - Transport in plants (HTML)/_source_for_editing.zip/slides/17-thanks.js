Engine.register({
  id: 'thanks', section: "Let's conclude", title: 'Thank you!', mech: 'summary',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const stars = Engine.stars || 0;
    const done = Object.keys(Engine.done || {}).length;
    const media = h('div', { class: 'cover-media' });
    const cl = h('div', { class: 'diacluster' });
    cl.append(
      h('div', { class: 'dia d1', style: 'background-image:url("assets/img/bg-fern.jpg")' }),
      h('div', { class: 'dia d2', style: 'background-image:url("assets/img/bg-leaf.jpg")' }),
      h('div', { class: 'dia d3', style: 'background-image:url("assets/img/bg-palm.jpg")' })
    );
    const core = h('div', { class: 'dcore float-anim' }, [ctx.img('assets/img/image4.png', { alt: 'Leaf', zoom: false })]);
    cl.appendChild(core);
    media.appendChild(cl);
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Thank <em>you!</em>';
    const quote = h('div', { class: 'quote', text: '“Growth takes time, roots, and light. Keep growing!”' });
    const sb = h('div', { class: 'starbig', style: 'align-items:flex-start' }, [
      h('div', { class: 'num', text: '⭐ ' + stars }),
      h('div', { class: 'lbl', text: stars ? 'stars today — well done!' : (done > 2 ? 'Keep practising — you can do it!' : 'Ready to try the activities?') })
    ]);
    txt.append(t, quote, sb);
    const wrong = (Engine.wrongList() || []).filter(id => Engine.slides.some(s => s.id === id));
    if (wrong.length) {
      txt.appendChild(h('div', { class: 'hero-sub', text: "Let's review:" }));
      const row = h('div', { class: 'btnrow', style: 'justify-content:flex-start' });
      wrong.slice(0, 3).forEach(id => { const s = Engine.slides.find(x => x.id === id); const b = h('button', { class: 'btn', text: s.title }); ctx.on(b, 'click', () => Lab.goTo(id)); row.appendChild(b); });
      txt.appendChild(row);
    }
    const again = h('button', { class: 'btn btn-primary', text: '↺ Start again' });
    ctx.on(again, 'click', () => Engine.go(0, 'jump'));
    txt.appendChild(h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [again]));
    cov.append(media, txt);
    root.appendChild(cov);
    if (stars) ctx.timeout(() => Engine.confetti('star'), 500);
  }
});
