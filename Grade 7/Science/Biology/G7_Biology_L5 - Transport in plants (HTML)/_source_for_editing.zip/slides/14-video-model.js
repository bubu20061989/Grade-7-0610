Engine.register({
  id: 'video-model', section: "Let's produce", title: 'Video: Why do plants need water?', mech: 'video',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Watch and listen' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Watch two friends ask and answer. Then it is your turn!' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    grow.appendChild(h('div', { class: 'stagecard vidcard' }, [h('div', { class: 'vidbox' }, [Lab.video(ctx, 'assets/video/media3.mp4', 'assets/img/image33.png')])]));
    root.appendChild(grow);
  }
});
