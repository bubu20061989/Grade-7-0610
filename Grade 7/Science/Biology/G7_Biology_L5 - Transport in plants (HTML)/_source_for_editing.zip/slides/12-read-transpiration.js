Engine.register({
  id: 'read-transpiration', section: "Let's practice", title: 'Read: Transpiration', mech: 'choose',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Read and choose the words' }));
    const P = [
      'Transpiration happens when plant roots take in water from the topsoil layer and change it into vapors. Then, vapors [[1]] from the surface of leaves. Transpiration is an important factor in the water cycle because it is one of the major sources of water [[2]] the atmosphere. This process [[3]] 10% of the total atmospheric water and is [[4]] similar to perspiration or sweating in animals.',
      'Plant leaves have stomata. These stomata play a part in [[5]] water loss from leaves. The stomata open for two [[6]]: to get carbon dioxide (CO₂) from the atmosphere and to limit the loss of water due to evaporation. Stomata close in events such as droughts to prevent the loss of water. The opening and closing of stomata depend on the swelling of the guard cell.'
    ];
    const B = [
      { opts: ['evaporates', 'evaporating', 'evaporate'], ans: 2 },
      { opts: ['at', 'in', 'on'], ans: 1 },
      { opts: ['provides', 'providing', 'to provide'], ans: 0 },
      { opts: ['near', 'nearly', 'neatly'], ans: 1 },
      { opts: ['controlling', 'control', 'controls'], ans: 0 },
      { opts: ['reason', 'reasons', 'reasoning'], ans: 1 }
    ];
    const bar = h('div', { class: 'optbar fixed' });
    const bc = Lab.blankChoice(ctx, P, B, bar);
    bc.el.insertBefore(h('div', { class: 'ptitle', text: 'Transpiration' }), bc.el.firstChild);
    root.appendChild(h('div', { class: 'grow readgrow stagger' }, [bc.el]));
    root.appendChild(bar);
    const row = ctx.buttons({ check: () => bc.check(), show: () => bc.show(), reset: () => bc.reset() });
    row.appendChild(Lab.pager(ctx, bc.el));
    root.appendChild(row);
  }
});
