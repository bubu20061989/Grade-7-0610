Engine.register({
  id: 'rearrange', section: "Let's practice", title: 'Rearrange the words', mech: 'order',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Rearrange the words' }));
    /* tiles: thẻ từ (giữ đúng thẻ của PPT gốc); ok: các thứ tự đúng (theo chỉ số thẻ) */
    const S = [
      { lead: 'Plants', tiles: ['the soil', 'roots.', 'water', 'absorb', 'in', 'by', 'Water', 'leaves', 'stems', 'travels up', 'to'],
        ok: [[3, 2, 4, 0, 5, 1, 6, 9, 8, 10, 7]] },
      { lead: 'Water', tiles: ['roots', 'nutrients', 'and', 'back and forth', 'carries', 'between', 'leaves'],
        ok: [[4, 1, 3, 5, 0, 2, 6], [4, 1, 3, 5, 6, 2, 0]] },
      { lead: 'During photosynthesis,', tiles: ['need', 'leaves', 'water,', 'their', 'to', 'make', 'nutrients,', 'own', 'and sunlight', 'food'],
        ok: [[1, 0, 2, 6, 8, 4, 5, 3, 7, 9], [1, 0, 6, 2, 8, 4, 5, 3, 7, 9]] }
    ];
    const ctxl = h('div', { class: 'ctxline fixed' });
    const tabs = h('div', { class: 'stabs fixed' });
    const line = h('div', { class: 'buildline' });
    const pool = h('div', { class: 'tilepool' });
    root.append(ctxl, tabs);
    root.appendChild(h('div', { class: 'grow center-col stagger', style: 'gap:clamp(10px,2.4vh,30px)' }, [line, pool]));
    const st = S.map(() => ({ seq: [], res: null }));
    let cur = 0;
    const text = (k) => st[k].seq.map(j => S[k].tiles[j]).join(' ');
    const paintCtx = () => {
      ctxl.innerHTML = '';
      const brk = (k) => {
        const s = h('span', { class: 'brk' + (k === cur ? ' cur' : '') + (st[k].res === true ? ' done' : '') });
        s.textContent = '[ ' + (st[k].seq.length ? text(k) : '  ' + (k + 1) + '  ') + ' ]';
        return s;
      };
      ctxl.append('Like all living things, plants need water. Plants ', brk(0), '. Water ', brk(1), '. During photosynthesis, ', brk(2), '. Water also helps plants stay cool.');
    };
    const paint = () => {
      tabs.innerHTML = '';
      S.forEach((_, k) => {
        const b = h('button', { class: 'btn' + (k === cur ? ' on' : ''), text: 'Sentence ' + (k + 1) + (st[k].res === true ? ' ✓' : '') });
        ctx.on(b, 'click', () => { cur = k; paint(); });
        tabs.appendChild(b);
      });
      line.innerHTML = ''; pool.innerHTML = '';
      ctx.clearResult(line); line.classList.remove('is-ok', 'is-bad');
      if (st[cur].res != null) ctx.markResult(line, st[cur].res, { shake: false });
      line.appendChild(h('span', { class: 'tile', style: '--chip-c:#94A3B8;cursor:default', text: S[cur].lead }));
      st[cur].seq.forEach((j, pos) => {
        const t = h('button', { class: 'tile', text: S[cur].tiles[j] });
        ctx.on(t, 'click', () => { st[cur].seq.splice(pos, 1); st[cur].res = null; Sound.playEffect('click'); paint(); });
        line.appendChild(t);
      });
      if (!st[cur].order) st[cur].order = ctx.shuffle(S[cur].tiles.map((_, j) => j));
      st[cur].order.forEach(j => {
        const t = h('button', { class: 'tile' + (st[cur].seq.indexOf(j) >= 0 ? ' used' : ''), text: S[cur].tiles[j] });
        ctx.on(t, 'click', () => { if (st[cur].seq.indexOf(j) >= 0) return; st[cur].seq.push(j); st[cur].res = null; Sound.playEffect('click'); paint(); });
        pool.appendChild(t);
      });
      paintCtx();
    };
    const row = ctx.buttons({
      check: () => {
        const ok = S[cur].ok.some(a => a.join(',') === st[cur].seq.join(','));
        st[cur].res = ok; paint();
        if (ok) Sound.speak(S[cur].lead + ' ' + text(cur));
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { st[cur].seq = S[cur].ok[0].slice(); st[cur].res = null; paint(); },
      reset: () => { st[cur].seq = []; st[cur].res = null; paint(); }
    });
    root.appendChild(row);
    paint();
  }
});
