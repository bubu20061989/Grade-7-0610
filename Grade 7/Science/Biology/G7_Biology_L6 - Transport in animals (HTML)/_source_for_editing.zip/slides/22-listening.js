Engine.register({
  id: 'listening', section: 'Practice', title: 'Listen: Blood circulation', mech: 'cloze', scene: 'maroon',
  render(root, ctx) {
    const head = h('div', { class: 'qhead fixed' }, [h('div', { class: 'pill', text: 'Listen and fill in the blanks' })]);
    root.appendChild(head);
    const A = ['small', 'large', 'heart', 'flows to the lungs', 'oxygen', 'all other organs and body parts', 'low level', 'nutrients'];
    const items = A.map((w, k) => ({ id: 'w' + (k + 1), label: w }));
    const zones = A.map((w, k) => ({ id: 'b' + (k + 1), accept: ['w' + (k + 1)], capacity: 1 }));
    this._dd = ctx.dragDrop({ items, zones, renderZone: (z) => h('div', { class: 'card cslot', 'data-n': '' }) });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/image86.png', { alt: 'The two circuits of blood in the human body (worksheet 3)', class: 'hero-img' })]);
    const grid = h('div', { class: 'cgrid' });
    A.forEach((w, k) => grid.appendChild(h('div', { class: 'crow' }, [h('span', { class: 'cnum', text: '(' + (k + 1) + ')' }), this._dd.zoneEls['b' + (k + 1)]])));
    const play = h('button', { class: 'btn btn-primary', text: '▶ Play Track 6' });
    ctx.on(play, 'click', () => Sound.playEffect('track6'));
    const stop = h('button', { class: 'btn', text: '■ Stop' });
    ctx.on(stop, 'click', () => Sound.stopAll());
    const tr = h('button', { class: 'btn', text: '📄 Transcript' });
    ctx.on(tr, 'click', () => Engine.lightbox('assets/img/image89.png', 'Track 6 transcript'));
    media.appendChild(ctx.zoomHint());
    head.append(play, stop, tr);
    const side = h('div', { class: 'listen-side' }, [grid]);
    root.appendChild(h('div', { class: 'split stagger lsplit' }, [media, side]));
    this._dd.tray.classList.add('smallchips');
    root.appendChild(this._dd.tray);
    const btns = ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() });
    root.appendChild(btns);
  }
});
