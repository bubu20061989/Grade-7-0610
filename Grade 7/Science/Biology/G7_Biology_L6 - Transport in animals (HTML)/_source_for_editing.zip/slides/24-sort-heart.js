Engine.register({
  id: 'sort-heart', section: "Let's produce", title: 'Habits and foods for your heart', mech: 'sort', scene: 'maroon',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Habits or foods?' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each card to the right group' }));
    const H = ['Have healthy diets', 'Do regular physical activity', 'Stop smoking', 'Reduce stress'];
    const F = ['Garlic', 'Dark green vegetables', 'Fish high in omega-3s', 'Healthy nuts and beans'];
    const items = H.map((w, k) => ({ id: 'h' + k, label: w })).concat(F.map((w, k) => ({ id: 'f' + k, label: w })));
    const zones = [
      { id: 'habits', label: 'Habits to protect your heart', accept: H.map((_, k) => 'h' + k) },
      { id: 'foods', label: 'Healthy foods for your heart', accept: F.map((_, k) => 'f' + k) }
    ];
    this._dd = ctx.dragDrop({ items, zones, renderZone: (z) => h('div', { class: 'card bin' }) });
    const col = (z, icon) => h('div', { class: 'colhalf' }, [h('div', { class: 'bin-label tag', style: 'font-size:var(--f-body)', text: icon + ' ' + z.label }), this._dd.zoneEls[z.id]]);
    const row = h('div', { class: 'rowwrap stagger' }, [col(zones[0], '🏃'), col(zones[1], '🥦')]);
    row.querySelectorAll('.bin').forEach(b => { b.style.flex = '1 1 auto'; b.style.width = '100%'; });
    root.appendChild(row);
    root.appendChild(this._dd.tray);
    const ws = h('button', { class: 'btn', text: '📄 Worksheet' });
    ctx.on(ws, 'click', () => Engine.lightbox('assets/img/image91.png', 'Worksheet 5: habits and foods for your heart'));
    const btns = ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() });
    btns.appendChild(ws);
    root.appendChild(btns);
  }
});
