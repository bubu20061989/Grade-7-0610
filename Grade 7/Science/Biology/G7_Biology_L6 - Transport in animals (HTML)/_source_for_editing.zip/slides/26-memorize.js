Engine.register({
  id: 'memorize', section: 'Wrap-up', title: "Let's memorize", mech: 'recall', scene: 'maroon',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: "Let's memorize" }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Say what you remember first — then tap a card to check' }));
    const C = [
      { hd: 'Circulatory System Role', img: 'image69.png', pts: ['Transports essential oxygen and vital nutrients throughout the body.'] },
      { hd: 'Cardiovascular Health', img: 'image63.png', pts: ['Healthy lifestyle habits and balanced nutrition prevent cardiovascular diseases.', 'Regular exercise and a diet rich in nutrients.'] }
    ];
    const box = h('div', { class: 'recall stagger' });
    C.forEach(c => {
      const card = h('div', { class: 'card rcard' }, [h('div', { class: 'hd', text: '➤ ' + c.hd }),
        ctx.img('assets/img/' + c.img, { alt: c.hd, zoom: false, class: 'fitimg rimg' }),
        h('div', { class: 'tap', text: '👆 Tap to reveal' }), h('ul', {}, c.pts.map(p => h('li', { text: p })))]);
      ctx.on(card, 'click', () => { const was = card.classList.contains('open'); card.classList.add('open'); if (!was) { card.classList.add('pop-in'); Sound.speak(c.hd + '. ' + c.pts.join(' ')); } });
      box.appendChild(card);
    });
    root.appendChild(h('div', { class: 'grow' }, [box]));
    const all = h('button', { class: 'btn btn-show', text: '👁 Show all' });
    ctx.on(all, 'click', () => box.querySelectorAll('.rcard').forEach(c => c.classList.add('open')));
    const hide = h('button', { class: 'btn btn-reset', text: '↺ Hide all' });
    ctx.on(hide, 'click', () => box.querySelectorAll('.rcard').forEach(c => c.classList.remove('open', 'pop-in')));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [all, hide]));
  }
});
