Engine.register({
  id: 'cover', section: 'Welcome', title: 'Transport in animals', mech: 'cover', scene: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media bare' });
    const body = ctx.img('assets/img/image1.png', { alt: 'The human body: heart, lungs and blood vessels', zoom: false, class: 'hero-img float-anim' });
    body.style.cursor = 'pointer';
    ctx.on(body, 'click', () => { body.classList.remove('nudge'); void body.offsetWidth; body.classList.add('nudge'); Sound.speak('Transport in animals'); });
    media.appendChild(body);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7 · Biology' }), h('span', { class: 'tag', text: 'Lesson 6' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Transport<br><em>in animals</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "▶ Let's start" });
    ctx.on(go, 'click', () => { Engine.confetti('star'); Engine.next(); });
    txt.append(t, h('div', { class: 'hero-sub', text: '👆 Tap the body to hear the title' }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
