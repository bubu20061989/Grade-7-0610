Engine.register({
  id: 't4', section: "Let's review", title: 'Turtle · Question 4', mech: 'name', scene: 'cloud',
  q: {"team": "t", "num": 4, "kind": "name", "answer": "nose", "img": "assets/img/image55.png"},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
