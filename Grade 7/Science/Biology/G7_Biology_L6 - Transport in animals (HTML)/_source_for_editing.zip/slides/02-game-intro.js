Engine.register({
  id: 'game-intro', section: "Let's review", title: 'Turtle & Hare: The Element Race', mech: 'rules', scene: 'sky',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media wide' });
    media.appendChild(ctx.img('assets/img/image11.png', { alt: 'Turtle & Hare: The Element Race', zoom: false, class: 'hero-img' }));
    const txt = h('div', { class: 'cover-text stagecard', style: 'align-items:flex-start' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: "Let's review" }), h('span', { class: 'tag', text: 'Team game' })]));
    const t = h('div', { class: 'hero-title', style: 'font-size:var(--f-h1)' }); t.innerHTML = '<em>Game rules</em>';
    const rules = h('ul', { class: 'rules' });
    [['Divide the class into 2 teams.'],
     ['Teams will take turns choosing a question. Correct answer → move up 1 step. Incorrect answer → lose a turn.'],
     ['The team that reaches the highest position first will be the winner.']].forEach(r => rules.appendChild(h('li', { text: r[0] })));
    const play = h('button', { class: 'btn btn-primary pulse', text: '▶ PLAY!' });
    ctx.on(play, 'click', () => { Engine.confetti('star'); Lab.goTo('board'); });
    const read = ctx.speakBtn('Divide the class into 2 teams. Teams will take turns choosing a question. Correct answer, move up 1 step. Incorrect answer, lose a turn. The team that reaches the highest position first will be the winner.', ' Listen');
    txt.append(t, rules, h('div', { class: 'btnrow' }, [read, play]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
