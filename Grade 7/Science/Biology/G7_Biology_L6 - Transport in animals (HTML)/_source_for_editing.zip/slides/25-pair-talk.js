Engine.register({
  id: 'pair-talk', section: "Let's produce", title: 'Work in pairs', mech: 'speak', scene: 'maroon',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: "Let's produce" }));
    const vid = h('video', { class: 'vid', src: 'assets/video/media7.mp4', poster: 'assets/img/image92.png', controls: '', playsinline: '', preload: 'metadata' });
    const media = h('div', { class: 'media' }, [vid]);
    const T = ['Have healthy diets', 'Do regular physical activity', 'Stop smoking', 'Keep a healthy weight', 'Limit alcohol use', 'Reduce stress',
      'Manage your cholesterol', 'Manage your blood pressure', 'Manage your blood sugar', 'Garlic', 'Dark green vegetables (spinach, broccoli, etc.)',
      'Red and orange fruits / vegetables', 'Healthy nuts and beans', 'Fish high in omega-3s, such as salmon and tuna', 'Dark chocolate with at least 70% cocoa'];
    const topic = h('div', { class: 'topic', text: 'Pick a topic to talk about!' });
    const pick = h('button', { class: 'btn btn-primary', text: '🎲 Pick a topic' });
    let last = -1;
    ctx.on(pick, 'click', () => {
      let k; do { k = Math.floor(Math.random() * T.length); } while (k === last && T.length > 1);
      last = k; topic.textContent = T[k]; topic.classList.remove('pop-in'); void topic.offsetWidth; topic.classList.add('pop-in');
      Sound.speak(T[k]);
    });
    const timer = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(timer, 'click', () => Engine.timer(60));
    const ws = h('button', { class: 'btn', text: '📄 Worksheet' });
    ctx.on(ws, 'click', () => Engine.lightbox('assets/img/image91.png', 'Worksheet 5: habits and foods for your heart'));
    const side = h('div', {}, [h('div', { class: 'task', text: '5. Work in pairs. Talk about healthy habits and foods to prevent cardiovascular diseases in humans.' }),
      topic, h('div', { class: 'btnrow' }, [pick, timer, ws])]);
    root.appendChild(h('div', { class: 'split stagger' }, [media, side]));
  }
});
