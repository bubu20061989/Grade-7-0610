Engine.register({
  id: 'r6', section: "Let's review", title: 'Hare · Question 6', mech: 'mcq', scene: 'cloud',
  q: {"team": "r", "num": 6, "kind": "mcq", "answer": "stomach", "img": "assets/img/image59.png", "options": ["A. heart", "B. stomach", "C. brain", "D. lungs"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
