Engine.register({
  id: 't1', section: "Let's review", title: 'Turtle · Question 1', mech: 'mcq', scene: 'cloud',
  q: {"team": "t", "num": 1, "kind": "mcq", "answer": "stomach", "img": "assets/img/image61.png", "options": ["A. brain", "B. stomach", "C. lungs", "D. intestine"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
