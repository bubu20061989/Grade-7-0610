Engine.register({
  id: 'vocab-match', section: 'New words', title: 'Match the words', mech: 'match', scene: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Match the new words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its meaning' }));
    const W = [
      { id: 'cs', label: 'circulatory system', vi: 'Hệ tuần hoàn', img: 'image69.png' },
      { id: 'heart', label: 'heart', vi: 'Trái tim', img: 'image63.png' },
      { id: 'bv', label: 'blood vessels', vi: 'Mạch máu', img: 'image73.png' },
      { id: 'circ', label: 'circulation', vi: 'Sự lưu thông / tuần hoàn', img: 'image78.gif' }
    ];
    const zones = W.map(w => ({ id: 'z' + w.id, accept: [w.id], capacity: 1 }));
    this._dd = ctx.dragDrop({ items: W.map(w => ({ id: w.id, label: w.label })), zones,
      renderZone: () => h('div', { class: 'card' }) });
    const grid = h('div', { class: 'imgrid vm stagger', style: 'grid-template-columns:repeat(4,minmax(0,1fr))' });
    W.forEach(w => grid.appendChild(h('div', { class: 'cell' }, [
      ctx.img('assets/img/' + w.img, { alt: w.vi, zoom: false }), h('div', { class: 'vi', text: w.vi }), this._dd.zoneEls['z' + w.id]])));
    root.appendChild(h('div', { class: 'grow' }, [grid]));
    root.appendChild(this._dd.tray);
    root.appendChild(ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() }));
  }
});
