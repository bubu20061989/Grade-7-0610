Engine.register({
  id: 'r2', section: "Let's review", title: 'Hare · Question 2', mech: 'name', scene: 'cloud',
  q: {"team": "r", "num": 2, "kind": "name", "answer": "intestine", "video": "assets/video/media3.mp4", "poster": "assets/img/image53.jpeg"},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
