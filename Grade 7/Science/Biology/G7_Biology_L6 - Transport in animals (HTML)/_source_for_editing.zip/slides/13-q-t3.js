Engine.register({
  id: 't3', section: "Let's review", title: 'Turtle · Question 3', mech: 'mcq', scene: 'cloud',
  q: {"team": "t", "num": 3, "kind": "mcq", "answer": "mouth", "img": "assets/img/image57.png", "options": ["A. nose", "B. ears", "C. eyes", "D. mouth"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
