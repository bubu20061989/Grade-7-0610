Engine.register({
  id: 'vocab', section: 'New words', title: "Let's learn: 4 words", mech: 'flashcard', scene: 'blue',
  render(root, ctx) {
    const W = [
      { w: 'circulatory system', pos: '(n)', ipa: '/ˌsɜːkjəleɪtəri ˈsɪstəm/', img: 'image69.png', def: 'The system that circulates blood and lymph through the body.', vi: 'Hệ tuần hoàn' },
      { w: 'heart', pos: '(n)', ipa: '/hɑːrt/', img: 'image71.png', def: '', vi: 'Trái tim', beat: true },
      { w: 'blood vessels', pos: '(n)', ipa: '/ˈblʌd veslz/', img: 'image73.png', def: '', vi: 'Mạch máu' },
      { w: 'circulation', pos: '(n)', ipa: '/ˌsɜːkjəˈleɪʃn/', img: 'image78.gif', def: 'The movement of blood through the body.', vi: 'Sự lưu thông / tuần hoàn' }
    ];
    let i = 0;
    const seen = {};
    root.appendChild(h('div', { class: 'pill fixed', text: "Let's learn" }));
    const wrap = h('div', { class: 'fc-wrap' });
    const card = h('div', { class: 'fc vfc' });
    const front = h('div', { class: 'face front' });
    const back = h('div', { class: 'face back' });
    card.append(front, back);
    wrap.appendChild(card);
    const dots = h('div', { class: 'dots fixed' });
    root.appendChild(h('div', { class: 'grow center-col' }, [wrap]));
    root.appendChild(dots);

    const paint = () => {
      const v = W[i];
      seen[i] = 1;
      card.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      const pic = h('div', {}, [ctx.img('assets/img/' + v.img, { alt: v.w, class: 'hero-img pop-in' }), ctx.zoomHint()]);
      const txt = h('div', {}, [h('div', { class: 'vword', text: v.w }), h('div', { class: 'vpos', text: v.pos }), h('div', { class: 'ipa', text: v.ipa }),
        h('div', { class: 'vhint', text: 'Tap the card to see the meaning' })]);
      front.append(pic, txt);
      back.append(h('div', { class: 'vword', text: v.w }));
      if (v.def) back.appendChild(h('div', { class: 'vdef', text: v.def }));
      back.appendChild(h('div', { class: 'vvi', text: v.vi }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : seen[k] ? 'done' : '' })));
      beat.style.display = v.beat ? '' : 'none';
      Sound.speak(v.w);
    };
    ctx.on(card, 'click', (e) => {
      if (e.target.tagName === 'IMG' || e.target.classList.contains('zoomhint')) return;
      card.classList.toggle('flipped');
      if (card.classList.contains('flipped')) Sound.speak(W[i].def || W[i].w);
    });
    const prev = h('button', { class: 'btn', text: '◀ Back' });
    const next = h('button', { class: 'btn btn-primary', text: 'Next ▶' });
    const listen = h('button', { class: 'btn', text: '🔊 Listen' });
    const x3 = h('button', { class: 'btn', text: '🔁 x3' });
    const beat = h('button', { class: 'btn', text: '♥ Heartbeat' });
    ctx.on(prev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(next, 'click', () => { i = (i + 1) % W.length; paint(); if (Object.keys(seen).length === W.length && i === 0) Engine.confetti('star'); });
    ctx.on(listen, 'click', () => Sound.speak(W[i].w));
    ctx.on(x3, 'click', () => Sound.repeat(W[i].w, 3));
    ctx.on(beat, 'click', () => Sound.playEffect('heartbeat'));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [prev, listen, x3, beat, next]));
    paint();
  }
});
