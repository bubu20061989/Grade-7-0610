Engine.register({
  id: 'reading', section: 'Practice', title: 'Read: Transport inside the body', mech: 'read', scene: 'maroon',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: "Let's practice: Read the text" }));
    const P = [
      ['How do animals transport oxygen, water, and nutrients around their body?', 'The answer is circulation.',
       'Animals do not only use this process to send necessary substances through the body but also to collect unnecessary things and take them to the right organs to remove them.'],
      ['The body surface of a few species of invertebrates is thin enough for gases and nutrients to go through.',
       'However, in most animals, they need the circulatory system for circulation.',
       'The system includes the heart, the blood, and tubes for the blood to pass through (or blood vessels).',
       'When the heart beats, the blood flows to carry gases and substances around the body.',
       'Insects do not use circulation to carry gases.',
       'There are two types of circulatory systems: the closed circulatory system and the open circulatory system.']
    ];
    /* Văn bản gốc giữ NGUYÊN VĂN, chia 2 trang theo 2 đoạn để chữ đủ to và không tràn trên máy chiếu 720p */
    const steps = h('div', { class: 'steps fixed' }, [h('span', { class: 'note', text: 'Paragraph' })]);
    root.appendChild(steps);
    const box = h('div', { class: 'reading stagger' });
    root.appendChild(h('div', { class: 'grow fitgrow' }, [box]));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap a sentence to listen' }));
    let cur = 0, spans = [];
    const sb = [];
    const paint = () => {
      box.innerHTML = ''; spans = [];
      const p = h('p');
      P[cur].forEach((s, k) => {
        const sp = h('span', { class: 'sent', text: s });
        ctx.on(sp, 'click', () => { spans.forEach(x => x.classList.remove('on')); sp.classList.add('on'); Sound.speak(s, { rate: .9 }); });
        spans.push(sp); p.appendChild(sp);
        if (k < P[cur].length - 1) p.appendChild(document.createTextNode(' '));
      });
      box.appendChild(p);
      sb.forEach((b, k) => b.classList.toggle('on', k === cur));
      box.classList.remove('pop-in'); void box.offsetWidth; box.classList.add('pop-in');
      if (window.Lab) Lab.refit();
    };
    P.forEach((_, k) => {
      const b = h('button', { class: 'stepbtn', text: String(k + 1) });
      ctx.on(b, 'click', () => { Sound.stopAll(); cur = k; paint(); });
      sb.push(b); steps.appendChild(b);
    });
    const readAll = h('button', { class: 'btn btn-primary', text: '🔊 Read paragraph' });
    ctx.on(readAll, 'click', async () => {
      const mine = spans;
      for (const sp of mine) {
        if (!sp.isConnected) return;
        mine.forEach(x => x.classList.remove('on')); sp.classList.add('on');
        await Sound.speak(sp.textContent, { rate: .9 });
      }
    });
    const stop = h('button', { class: 'btn', text: '■ Stop' });
    ctx.on(stop, 'click', () => Sound.stopAll());
    const next = h('button', { class: 'btn', text: 'Next paragraph ▶' });
    ctx.on(next, 'click', () => { Sound.stopAll(); cur = (cur + 1) % P.length; paint(); });
    const ws = h('button', { class: 'btn', text: '📄 Worksheet' });
    ctx.on(ws, 'click', () => Engine.lightbox('assets/img/image81.png', 'Worksheet 2: reading text and True/False table'));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [readAll, stop, next, ws]));
    paint();
  }
});
