Engine.register({
  id: 'leadin', section: 'Lead-in', title: 'Body parts', mech: 'explore', scene: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const ORG = [['image63', 'heart'], ['image62', 'brain'], null, ['image57', 'mouth'], ['image64', 'intestine'],
                 ['image65', 'lungs'], ['image69', 'circulatory system'], null, ['image55', 'nose'], ['image61', 'stomach']];
    const grid = h('div', { class: 'imgrid organs stagger' });
    ORG.forEach((o, i) => {
      if (!o) {
        if (i === 2) {
          const kid = h('div', { class: 'cell kid' }, [
            ctx.img('assets/img/image68.png', { alt: 'Brain', zoom: false, class: 'fitimg head' }),
            ctx.img('assets/img/image66.png', { alt: 'Body with organs inside', zoom: false, class: 'fitimg body float-anim' })]);
          ctx.on(kid, 'click', () => Sound.speak('Our body'));
          grid.appendChild(kid);
        }
        return;
      }
      const chip = h('div', { class: 'chip tapme', text: 'Tap me' });
      const cell = h('div', { class: 'cell' }, [ctx.img('assets/img/' + o[0] + '.png', { alt: o[1], zoom: false }), chip]);
      ctx.on(cell, 'click', () => { chip.classList.remove('tapme'); chip.textContent = o[1]; cell.classList.remove('nudge'); void cell.offsetWidth; cell.classList.add('nudge'); Sound.speak(o[1]); });
      grid.appendChild(cell);
    });
    root.appendChild(h('div', { class: 'grow' }, [grid]));
    root.appendChild(h('div', { class: 'askq fixed', text: 'Do these body parts work alone, or do they work together to perform specific tasks in our body?' }));
    const vote = (label, msg) => {
      const b = h('button', { class: 'btn', text: label });
      ctx.on(b, 'click', () => { Engine.toast(msg); b.classList.add('nudge'); });
      return b;
    };
    root.appendChild(h('div', { class: 'btnrow fixed' }, [
      ctx.speakBtn('Do these body parts work alone, or do they work together to perform specific tasks in our body?', ' Listen'),
      vote('🙋 They work alone', 'Interesting! Let’s find out in this lesson.'),
      vote('🤝 They work together', 'Good guess! Let’s find out in this lesson.')
    ]));
  }
});
