Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'quiz', scene: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const ORG = [['image63', 'heart'], ['image62', 'brain'], null, ['image57', 'mouth'], ['image64', 'intestine'],
                 ['image65', 'lungs'], ['image69', 'circulatory system'], null, ['image55', 'nose'], ['image61', 'stomach']];
    const grid = h('div', { class: 'imgrid organs stagger' });
    ORG.forEach((o, i) => {
      if (!o) {
        if (i === 2) grid.appendChild(h('div', { class: 'cell kid' }, [
          ctx.img('assets/img/image68.png', { alt: 'Brain', zoom: false, class: 'fitimg head' }),
          ctx.img('assets/img/image66.png', { alt: 'Body with organs inside', zoom: false, class: 'fitimg body float-anim' })]));
        return;
      }
      const cell = h('div', { class: 'cell' }, [ctx.img('assets/img/' + o[0] + '.png', { alt: o[1], zoom: false }), h('div', { class: 'chip', text: o[1] })]);
      ctx.on(cell, 'click', () => Sound.speak(o[1]));
      grid.appendChild(cell);
    });
    root.appendChild(h('div', { class: 'grow' }, [grid]));
    const ANS = 'They work together as a system. For example, our heart, blood vessels, and blood work together to transport oxygen and nutrients to every part of the body.';
    const q = h('div', { class: 'askq fixed', text: 'Do these body parts work alone, or do they work together?' });
    root.appendChild(q);
    const bA = h('button', { class: 'opt', text: 'They work alone' });
    const bT = h('button', { class: 'opt', text: 'They work together' });
    let done = false;
    const pick = (b, ok) => {
      if (done) return;
      done = true;
      ctx.markResult(b, ok);
      Engine.score(ok ? 1 : 0, 1);
      ctx.timeout(() => { if (!ok) ctx.markResult(bT, true, { shake: false }); q.className = 'answerbox fixed pop-in'; q.textContent = ANS; Sound.speak(ANS); }, 600);
    };
    ctx.on(bA, 'click', () => pick(bA, false));
    ctx.on(bT, 'click', () => pick(bT, true));
    const again = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(again, 'click', () => { done = false; [bA, bT].forEach(b => ctx.clearResult(b)); q.className = 'askq fixed'; q.textContent = 'Do these body parts work alone, or do they work together?'; });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bA, bT, again]));
  }
});
