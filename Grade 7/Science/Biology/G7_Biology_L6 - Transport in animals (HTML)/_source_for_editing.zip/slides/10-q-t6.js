Engine.register({
  id: 't6', section: "Let's review", title: 'Turtle · Question 6', mech: 'name', scene: 'cloud',
  q: {"team": "t", "num": 6, "kind": "name", "answer": "brain", "img": "assets/img/image62.png"},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
