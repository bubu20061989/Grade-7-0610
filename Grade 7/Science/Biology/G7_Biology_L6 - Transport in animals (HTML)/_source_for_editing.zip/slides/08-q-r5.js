Engine.register({
  id: 'r5', section: "Let's review", title: 'Hare · Question 5', mech: 'mcq', scene: 'cloud',
  q: {"team": "r", "num": 5, "kind": "mcq", "answer": "lungs", "video": "assets/video/media4.mp4", "poster": "assets/img/image58.jpeg", "options": ["A. stomach", "B. lungs", "C. heart", "D. brain"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
