Engine.register({
  id: 'truefalse', section: 'Practice', title: 'True or False', mech: 'tf', scene: 'gingham',
  render(root, ctx) {
    const S = [
      { k: 'a', s: 'Circulation helps animals take oxygen and nutrients for living.', a: true,
        e: 'How do animals transport oxygen, water, and nutrients around their body? The answer is circulation.' },
      { k: 'b', s: 'Animals only use circulation to collect and remove unnecessary substances.', a: false,
        e: 'Animals do not only use this process to send necessary substances through the body but also to collect unnecessary things…' },
      { k: 'c', s: 'All species of animals transport gases and substances through the blood.', a: false,
        e: 'The body surface of a few species of invertebrates is thin enough for gases and nutrients to go through.' },
      { k: 'd', s: 'The circulatory system does not help transport gases in insects.', a: true,
        e: 'Insects do not use circulation to carry gases.' },
      { k: 'e', s: 'To make the circulatory system, a body only needs a heart and blood vessels.', a: false,
        e: 'The system includes the heart, the blood, and tubes for the blood to pass through (or blood vessels).' },
      { k: 'f', s: 'The two types of circulatory systems are the closed circulatory system and the open one.', a: true,
        e: 'There are two types of circulatory systems: the closed circulatory system and the open circulatory system.' }
    ];
    const res = {};
    let i = 0;
    root.appendChild(h('div', { class: 'pill fixed', text: 'True or False?' }));
    const dots = h('div', { class: 'tfdots fixed' });
    const letter = h('div', { class: 'tfletter' });
    const state = h('div', { class: 'tfstate' });
    const ev = h('div', { class: 'evidence', style: 'visibility:hidden', text: '…' });
    const bT = h('button', { class: 'btn tfbtn t', text: 'TRUE' });
    const bF = h('button', { class: 'btn tfbtn f', text: 'FALSE' });
    const card = h('div', { class: 'stagecard tfcard' }, [letter, state, h('div', { class: 'tfbtns' }, [bT, bF]), ev]);
    root.appendChild(dots);
    root.appendChild(h('div', { class: 'grow center-col stagger' }, [card]));

    const paint = () => {
      const q = S[i];
      letter.textContent = q.k; state.textContent = q.s;
      [bT, bF].forEach(b => ctx.clearResult(b));
      ev.style.visibility = 'hidden'; ev.textContent = '📖 ' + q.e;
      if (res[i] != null) { show(res[i] === (q.a ? 't' : 'f')); }
      dots.innerHTML = '';
      S.forEach((x, k) => {
        const d = h('button', { class: 'tfdot' + (k === i ? ' now' : res[k] != null ? (res[k] === (x.a ? 't' : 'f') ? ' ok' : ' bad') : ''), text: x.k });
        ctx.on(d, 'click', () => { i = k; paint(); });
        dots.appendChild(d);
      });
      card.classList.remove('pop-in'); void card.offsetWidth; card.classList.add('pop-in');
    };
    const show = (ok) => {
      const q = S[i];
      ctx.markResult(res[i] === 't' ? bT : bF, ok, { shake: false });
      if (!ok) ctx.markResult(q.a ? bT : bF, true, { shake: false });
      ev.style.visibility = 'visible';
    };
    const pick = (v) => {
      if (res[i] != null) return;
      res[i] = v;
      const ok = v === (S[i].a ? 't' : 'f');
      ctx.markResult(v === 't' ? bT : bF, ok);
      Engine.score(ok ? 1 : 0, 1);
      ctx.timeout(() => { show(ok); dots.children[i].className = 'tfdot now'; }, 500);
    };
    ctx.on(bT, 'click', () => pick('t'));
    ctx.on(bF, 'click', () => pick('f'));
    const prev = h('button', { class: 'btn', text: '◀ Back' });
    const next = h('button', { class: 'btn btn-primary', text: 'Next ▶' });
    const listen = h('button', { class: 'btn', text: '🔊 Listen' });
    const timer = h('button', { class: 'btn', text: '⏱ 20s' });
    const again = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(prev, 'click', () => { i = (i + S.length - 1) % S.length; paint(); });
    ctx.on(next, 'click', () => {
      i = (i + 1) % S.length; paint();
      if (Object.keys(res).length === S.length && i === 0) {
        const n = S.filter((x, k) => res[k] === (x.a ? 't' : 'f')).length;
        Engine.toast(n + ' / 6 correct!');
      }
    });
    ctx.on(listen, 'click', () => Sound.speak(S[i].s));
    ctx.on(timer, 'click', () => Engine.timer(20));
    ctx.on(again, 'click', () => { Object.keys(res).forEach(k => delete res[k]); i = 0; paint(); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [prev, listen, timer, again, next]));
    paint();
  }
});
