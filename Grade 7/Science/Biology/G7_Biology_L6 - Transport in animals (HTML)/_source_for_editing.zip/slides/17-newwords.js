Engine.register({
  id: 'newwords', section: 'New words', title: 'New words', mech: 'cover', scene: 'crimson',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media bare' });
    const kid = ctx.img('assets/img/image7.png', { alt: 'A child with the heart and blood vessels', zoom: false, class: 'hero-img float-anim' });
    kid.style.cursor = 'pointer';
    ctx.on(kid, 'click', () => { kid.classList.remove('nudge'); void kid.offsetWidth; kid.classList.add('nudge'); Sound.playEffect('heartbeat'); });
    media.appendChild(kid);
    const torn = h('div', { class: 'torn' });
    const t = h('div', { class: 'hero-title', text: 'New words' });
    const go = h('button', { class: 'btn btn-primary pulse', text: "▶ Let's learn" });
    ctx.on(go, 'click', () => Engine.next());
    torn.append(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: '4 words' }), h('span', { class: 'tag', text: 'Circulation' })]),
      t, h('div', { class: 'hero-sub', text: '👆 Tap the child to hear a heartbeat' }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, h('div', { class: 'cover-text' }, [torn]));
    root.appendChild(cov);
  }
});
