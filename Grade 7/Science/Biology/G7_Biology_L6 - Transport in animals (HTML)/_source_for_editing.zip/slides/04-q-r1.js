Engine.register({
  id: 'r1', section: "Let's review", title: 'Hare · Question 1', mech: 'name', scene: 'cloud',
  q: {"team": "r", "num": 1, "kind": "name", "answer": "heart", "img": "assets/img/image52.gif"},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
