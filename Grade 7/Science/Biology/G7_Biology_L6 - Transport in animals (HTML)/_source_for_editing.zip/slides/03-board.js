Engine.register({
  id: 'board', section: "Let's review", title: 'Game board', mech: 'hub', scene: 'sky',
  render(root, ctx) {
    const s = Lab.race.get();
    root.appendChild(h('div', { class: 'pill fixed', text: 'Choose a number!' }));
    const race = h('div', { class: 'race stagger' });

    const team = (k) => {
      const T = Lab.RACE[k];
      const box = h('div', { class: 'team ' + k });
      const who = h('div', { class: 'who' }, [ctx.img(T.who, { alt: T.name, zoom: false, class: 'float-anim' }),
        h('div', {}, [document.createTextNode(T.name), h('span', { class: 'stepc', text: 'Step ' + s[k].step + ' / 6' })])]);
      const nums = h('div', { class: 'nums' });
      for (let n = 1; n <= 6; n++) {
        const b = h('button', { class: 'numbtn', 'aria-label': T.name + ' question ' + n });
        b.appendChild(h('img', { src: Lab.numImg(k, n), alt: String(n) }));
        const res = s[k].res[n];
        if (res != null) { b.classList.add('used'); ctx.markResult(b, !!res, { shake: false }); }
        ctx.on(b, 'click', () => Lab.goTo(k + n));
        nums.appendChild(b);
      }
      box.append(who, nums);
      return box;
    };

    const track = h('div', { class: 'track' });
    const lands = ['image15', 'image18', 'image19', 'image20', 'image15', 'image19'];
    const goal = h('div', { class: 'goal' }, [h('img', { class: 'land', src: 'assets/img/image16.png', alt: 'Treasure island' })]);
    ['r', 't'].forEach(k => { if (s[k].step >= 6) goal.appendChild(h('img', { class: 'runner ' + k + ' pop-in', src: Lab.RACE[k].who, alt: '' })); });
    track.appendChild(goal);
    for (let row = 5; row >= 0; row--) {               // bậc 5 (cao) -> 0 (xuất phát)
      ['r', 't'].forEach((k, ci) => {
        const z = (row % 2 === 0) === (ci === 0) ? 'zl' : 'zr';
        const cell = h('div', { class: 'isl ' + z });
        cell.appendChild(h('img', { class: 'land', src: 'assets/img/' + lands[(row + ci * 3) % 6] + '.png', alt: '' }));
        if (s[k].step === row) cell.appendChild(h('img', { class: 'runner pop-in', src: Lab.RACE[k].who, alt: Lab.RACE[k].name }));
        track.appendChild(cell);
      });
    }
    race.append(team('r'), track, team('t'));
    root.appendChild(race);

    const w = Lab.race.winner(s);
    if (w) {
      root.appendChild(h('div', { class: 'winbanner fixed pop-in', text: w === 'tie' ? '🏆 It’s a tie — well done, both teams!' : '🏆 ' + Lab.RACE[w].name + ' wins!' }));
      ctx.timeout(() => Engine.confetti('star'), 300);
    }

    const rnd = h('button', { class: 'btn btn-primary', text: '🎲 Random question' });
    ctx.on(rnd, 'click', () => {
      const left = [];
      ['r', 't'].forEach(k => { for (let n = 1; n <= 6; n++) if (s[k].res[n] == null) left.push(k + n); });
      if (!left.length) { Engine.toast('All questions are done!'); return; }
      Lab.goTo(left[Math.floor(Math.random() * left.length)]);
    });
    const music = h('button', { class: 'btn', text: '♪ Music' });
    ctx.on(music, 'click', () => { Sound.playEffect('race'); });
    const stop = h('button', { class: 'btn', text: '■ Stop' });
    ctx.on(stop, 'click', () => Sound.stopAll());
    const newg = h('button', { class: 'btn btn-reset', text: '↺ New game' });
    ctx.on(newg, 'click', () => { Lab.race.reset(); Engine.go(Engine.idx, 'jump'); });
    const next = h('button', { class: 'btn', text: 'Next part ▶' });
    ctx.on(next, 'click', () => Lab.goTo('leadin'));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [rnd, music, stop, newg, next]));
  }
});
