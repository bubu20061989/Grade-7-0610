Engine.register({
  id: 'goodbye', section: 'Wrap-up', title: 'Goodbye', mech: 'cover', scene: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    media.appendChild(ctx.img('assets/img/image78.gif', { alt: 'Blood circulation in the human body', zoom: false, class: 'hero-img' }));
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Goodbye!</em>';
    const QUOTE = '“Every living organism is a masterpiece of adaptation.”';
    const quote = h('div', { class: 'quote', text: QUOTE });
    const n = Object.keys(Engine.done || {}).length;
    const s = Lab.race.get(); const w = Lab.race.winner(s);
    const lines = [];
    if (Engine.stars > 0) lines.push('You earned ⭐ ' + Engine.stars + ' today. Great work!');
    else if (n > 0) lines.push('Thanks for joining the activities today!');
    else lines.push('Thanks for learning with us today!');
    if (w && w !== 'tie') lines.push('🏆 Race winner: ' + Lab.RACE[w].name);
    const sum = h('div', { class: 'hero-sub', text: lines.join('  ·  ') });
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak('Goodbye! Every living organism is a masterpiece of adaptation.'));
    const cel = h('button', { class: 'btn', text: '🎉 Celebrate' });
    ctx.on(cel, 'click', () => Engine.confetti('star'));
    txt.append(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Lesson 6 · Transport in animals' })]), t, quote, sum, h('div', { class: 'btnrow' }, [say, cel]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
