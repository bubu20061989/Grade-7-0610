Engine.register({
  id: 'r3', section: "Let's review", title: 'Hare · Question 3', mech: 'mcq', scene: 'cloud',
  q: {"team": "r", "num": 3, "kind": "mcq", "answer": "nose", "img": "assets/img/image55.png", "options": ["A. nose", "B. mouth", "C. ear", "D. hand"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
