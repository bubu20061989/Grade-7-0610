Engine.register({
  id: 'r4', section: "Let's review", title: 'Hare · Question 4', mech: 'name', scene: 'cloud',
  q: {"team": "r", "num": 4, "kind": "name", "answer": "mouth", "img": "assets/img/image57.png"},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
