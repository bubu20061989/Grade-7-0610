Engine.register({
  id: 't5', section: "Let's review", title: 'Turtle · Question 5', mech: 'mcq', scene: 'cloud',
  q: {"team": "t", "num": 5, "kind": "mcq", "answer": "lungs", "video": "assets/video/media4.mp4", "poster": "assets/img/image58.jpeg", "options": ["A. brain", "B. lungs", "C. stomach", "D. intestine"]},
  render(root, ctx) { Lab.q(this.q, root, ctx); }
});
