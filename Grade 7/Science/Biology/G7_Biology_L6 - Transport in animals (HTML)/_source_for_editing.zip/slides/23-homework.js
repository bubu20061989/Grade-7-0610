Engine.register({
  id: 'homework', section: 'Practice', title: 'Homework: Rearrange the words', mech: 'order', scene: 'maroon',
  render(root, ctx) {
    const P = [
      { pre: 'In the small circuit of blood in the human body,', post: '.',
        words: ['the blood', 'with', 'less oxygen', 'flows', 'from', 'the heart', 'to', 'the lungs'],
        alt: ['the blood flows from the heart to the lungs with less oxygen'] },
      { pre: 'After the gas exchange in the lungs, the blood with more oxygen flows back to the heart. In the large circuit,', post: 'to all other organs and body parts …',
        words: ['the blood', 'with', 'a high level of', 'oxygen', 'flows', 'from', 'the heart'],
        alt: ['the blood flows from the heart with a high level of oxygen'] },
      { pre: '… to bring nutrients and oxygen to every cell before', post: '.',
        words: ['the blood flow', 'returns', 'to', 'the heart', 'with a lower level of', 'oxygen'],
        alt: ['the blood flow with a lower level of oxygen returns to the heart'] }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Homework: Rearrange the words' }));
    const steps = h('div', { class: 'steps fixed' }, [h('span', { class: 'note', text: 'Part' })]);
    root.appendChild(steps);
    const host = h('div', { class: 'grow' });
    root.appendChild(host);
    const dds = [], stages = [], sbtn = [];
    let cur = 0;
    P.forEach((p, k) => {
      const items = p.words.map((w, j) => ({ id: 'p' + k + 'w' + j, label: w }));
      const zones = p.words.map((w, j) => ({ id: 'p' + k + 's' + j, accept: ['p' + k + 'w' + j], capacity: 1 }));
      const dd = ctx.dragDrop({ items, zones, renderZone: (z) => h('div', { class: 'card oslot', 'data-n': String(zones.indexOf(z) + 1) }) });
      dd.tray.classList.remove('fixed');
      const c = h('div', { class: 'ctx' }); c.innerHTML = '';
      c.append(document.createTextNode(p.pre + ' '), h('span', { class: 'gap', text: '[ … ]' }), document.createTextNode(' ' + p.post));
      const st = h('div', { class: 'ostage stagger' }, [c, h('div', { class: 'oslots' }, zones.map(z => dd.zoneEls[z.id])), dd.tray]);
      if (k) st.hidden = true;
      host.appendChild(st);
      /* Chấp nhận cả trật tự khác cũng đúng ngữ pháp & đúng nghĩa (p.alt), không chỉ 1 chuỗi */
      const ok = [p.words.join(' ')].concat(p.alt || []);
      dd.flexCheck = () => {
        const nodes = zones.map(z => dd.zoneEls[z.id].querySelector('.drag-item'));
        const seq = nodes.map(n => n ? n.textContent.replace(/[✓✗]/g, '').trim() : '');
        if (nodes.every(Boolean) && ok.indexOf(seq.join(' ')) >= 0) {
          nodes.forEach(n => ctx.markResult(n, true));
          return { correct: nodes.length, total: nodes.length };
        }
        return dd.check();
      };
      dds.push(dd); stages.push(st);
      const b = h('button', { class: 'stepbtn' + (k ? '' : ' on'), text: String(k + 1) });
      ctx.on(b, 'click', () => { cur = k; stages.forEach((s, x) => { s.hidden = x !== k; }); sbtn.forEach((s, x) => s.classList.toggle('on', x === k)); });
      sbtn.push(b); steps.appendChild(b);
    });
    const ws = h('button', { class: 'btn', text: '📄 Worksheet' });
    ctx.on(ws, 'click', () => Engine.lightbox('assets/img/image90.png', 'Worksheet 4'));
    steps.appendChild(ws);
    root.appendChild(ctx.buttons({
      check: () => { const r = dds[cur].flexCheck(); if (r.correct === r.total) sbtn[cur].classList.add('ok'); return r; },
      show: () => dds[cur].show(),
      reset: () => { dds[cur].reset(); sbtn[cur].classList.remove('ok'); }
    }));
  }
});
