Engine.register({
  id: 'order', section: 'Task 4–5 · Writing & Speaking', title: 'Task 5 · Order & describe', mech: 'order', bg: 'task',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 5 · Put in Order' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the sentences from Task 4 in the right order (1 → 5). Then take turns describing the process.' }));
    const S = [
      { k: 'a', t: 'The zygote develops into an embryo and, later, a new plant.' },
      { k: 'b', t: 'The female reproductive organ produces embryo sacs while the male one produces pollen grains.' },
      { k: 'c', t: 'After the pollen grains produce sperms, the sperms move toward the sacs.' },
      { k: 'd', t: 'The pollen grains land on the female reproductive organ.' },
      { k: 'e', t: 'The fertilisation happens between a sperm and an egg inside the sac.' }
    ];
    const KEY = ['b', 'd', 'c', 'e', 'a'];
    let seq = [];
    const grow = h('div', { class: 'grow' });
    const row = h('div', { class: 'rowwrap stagger' });
    const kids = h('div', { class: 'kids' }, [ctx.img('assets/img/image71.jpeg', { alt: 'Two students talking', zoom: false })]);
    const list = h('div', { class: 'steps' });
    const ordl = h('div', { class: 'ordline' });
    const paintOrd = () => { ordl.innerHTML = 'Your order: <b>' + (seq.length ? seq.join(' – ') : '…') + '</b>'; };
    const els = S.map(s => {
      const no = h('span', { class: 'no', text: '' });
      const b = h('button', { class: 'step' }, [no, h('span', { class: 'lt', text: '(' + s.k + ')' }), h('span', { text: s.t })]);
      ctx.on(b, 'click', () => {
        ctx.clearResult(b);
        const at = seq.indexOf(s.k);
        if (at >= 0) seq = seq.slice(0, at); else seq.push(s.k);
        paint(); Sound.playEffect('click');
      });
      b._k = s.k; b._no = no; return b;
    });
    const paint = () => { els.forEach(b => { const n = seq.indexOf(b._k); b._no.textContent = n >= 0 ? n + 1 : ''; b.classList.toggle('numbered', n >= 0); }); paintOrd(); };
    els.forEach(b => list.appendChild(b));
    row.append(kids, h('div', { class: 'colhalf' }, [list, ordl]));
    grow.appendChild(row);
    root.appendChild(grow);
    const btns = ctx.buttons({
      check: () => {
        let c = 0;
        els.forEach(b => { const ok = seq.indexOf(b._k) === KEY.indexOf(b._k); if (ok) c++; ctx.markResult(b, ok); });
        return { correct: c, total: KEY.length };
      },
      show: () => { seq = KEY.slice(); paint(); els.forEach(b => ctx.markResult(b, true, { shake: false })); },
      reset: () => { seq = []; els.forEach(b => ctx.clearResult(b)); paint(); }
    });
    const bT = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(bT, 'click', () => Engine.timer(60));
    btns.appendChild(bT);
    root.appendChild(btns);
    paint();
  }
});
