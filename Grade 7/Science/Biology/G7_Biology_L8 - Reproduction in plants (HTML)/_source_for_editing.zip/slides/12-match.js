Engine.register({
  id: 'match-steps', section: 'Task 3 · Watch & Listen', title: 'Task 3 · Match steps & pictures', mech: 'match', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 3 · Match the Steps' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Listen to the passage. Drag each step under the suitable picture.' }));
    const items = [
      { id: 's1', label: '(1) Pollen grains and embryo sacs production' },
      { id: 's2', label: '(2) Pollination' },
      { id: 's3', label: '(3) Sperm production' },
      { id: 's4', label: '(4) Fertilisation and Zygote development' }
    ];
    const zones = [
      { id: 'a', accept: ['s2'], capacity: 1 },
      { id: 'b', accept: ['s3'], capacity: 1 },
      { id: 'c', accept: ['s1'], capacity: 1 },
      { id: 'd', accept: ['s4'], capacity: 1 }
    ];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'card mslot' }) });
    dd.tray.classList.add('mtray');
    const grow = h('div', { class: 'grow' });
    const hero = h('div', { class: 'heroimg' }, [ctx.img('assets/img/image67.png', { alt: 'Steps (1)–(4) and pictures a–d of the sexual reproduction of a flowering plant', class: 'fitimg', zoom: false })]);
    const side = h('div', { class: 'side' }, zones.map(z => h('div', { class: 'zl' }, [h('div', { class: 'mz' }, [h('div', { class: 'lt', text: z.id })]), dd.zoneEls[z.id]])));
    grow.appendChild(h('div', { class: 'm3 stagger' }, [hero, side]));
    root.appendChild(grow);
    root.appendChild(dd.tray);
    const btns = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    btns.insertBefore(Lab.player(ctx, 'assets/audio/media3.mp3', 'Track 8'), btns.firstChild);
    root.appendChild(btns);
  }
});
