Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Keywords flashcards', mech: 'flashcard', bg: 'keys',
  render(root, ctx) {
    const W = [
      { w: 'embryo – embryo sac', ipa: '/ˈem.bri.oʊ/ – /ˈem.bri.oʊ ˌsæk/', img: 'image58.jpeg', vi: 'phôi – túi phôi', c: 'c-yel' },
      { w: 'fertilisation', ipa: '/ˌfɝː.t̬əl.əˈzeɪ.ʃən/', img: 'image59.jpeg', vi: 'Sự thụ tinh', c: 'c-blu' },
      { w: 'individual', ipa: '/ˌɪn.dəˈvɪdʒ.u.əl/', img: 'image60.png', vi: 'Cá thể', c: 'c-pnk' },
      { w: 'pollen grain', ipa: '/ˈpɑː.lən ɡreɪn/', img: 'image61.png', vi: 'Hạt phấn', c: 'c-grn' },
      { w: 'pollination', ipa: '/ˌpɑː.ləˈneɪ.ʃən/', img: 'image62.png', vi: 'Sự thụ phấn', c: 'c-pur' },
      { w: 'zygote', ipa: '/ˈzaɪ.ɡoʊt/', img: 'image63.png', vi: 'Hợp tử', c: 'c-mint' },
      { w: 'gamete', ipa: '/ˈɡæm.iːt/', img: null, vi: 'Giao tử', c: 'c-org' },
      { w: 'sperm', ipa: '/spɝːm/', img: null, vi: 'Tinh tử', c: 'c-yel' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Keywords' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    const dots = h('div', { class: 'dots fixed' });
    grow.append(h('div', { class: 'fc-wrap' }, [box]));
    root.appendChild(grow);
    root.appendChild(dots);

    let i = 0; const seen = {}; let cheered = false;
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.classList.toggle('solo', !v.img);
      if (v.img) front.appendChild(h('div', { class: 'vimg' }, [ctx.img('assets/img/' + v.img, { alt: v.w, zoom: false })]));
      front.appendChild(h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vipa', text: v.ipa }), h('div', { class: 'vtap', text: (i + 1) + ' / ' + W.length })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vlabel', text: 'Meaning' }), h('div', { class: 'vmean', text: v.vi }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !cheered) { cheered = true; Engine.toast('🎉 All 8 keywords!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => Sound.speak(W[i].w.replace('–', ',')));
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w.replace('–', ','), 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
