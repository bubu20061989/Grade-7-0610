Engine.register({
  id: 'read-c', section: 'Task 2 · Reading', title: 'Task 2c · Label the pictures', mech: 'label', bg: 'task',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 2c · Label the Pictures' }));
    root.appendChild(h('div', { class: 'note fixed', text: '3 examples of asexual reproduction from the text. Drag each label under the right picture.' }));
    const items = [
      { id: 'k', label: 'The kalanchoes use their leaves for reproduction.' },
      { id: 's', label: 'Strawberries grow from stems on the ground.' },
      { id: 'o', label: 'Onions grow from bulbs.' }
    ];
    const zones = [
      { id: 'z1', accept: ['k'], capacity: 1, n: '(1)' },
      { id: 'z2', accept: ['s'], capacity: 1, n: '(2)' },
      { id: 'z3', accept: ['o'], capacity: 1, n: '(3)' }
    ];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'card lbslot' }) });
    dd.tray.classList.add('lbtray');
    const grow = h('div', { class: 'grow read-c stagger' });
    const hero = h('div', { class: 'heroimg' }, [ctx.img('assets/img/image64.png', { alt: '(1) a kalanchoe leaf with small plants, (2) a strawberry plant, (3) onions growing', class: 'fitimg', zoom: false })]);
    const row = h('div', { class: 'labelrow' }, zones.map(z => h('div', { class: 'mz' }, [h('div', { class: 'lbnum', text: z.n }), dd.zoneEls[z.id]])));
    grow.append(hero, row);
    root.appendChild(grow);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
