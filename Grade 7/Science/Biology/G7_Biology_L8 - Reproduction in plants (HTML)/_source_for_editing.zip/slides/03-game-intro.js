Engine.register({
  id: 'game-intro', section: 'Warm-up', title: 'Game: Stand up or sit down', mech: 'intro', bg: 'game',
  render(root, ctx) {
    root.classList.add('on-dark');
    const cov = h('div', { class: 'cover dark stagger' });
    const media = h('div', { class: 'cover-media' });
    media.appendChild(ctx.img('assets/img/image25.png', { alt: 'SpongeBob SquarePants — Stand Up Sit Down Game', zoom: false, class: 'hero-img' }));
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Warm-up game' }), h('span', { class: 'tag', text: '4 rounds · 10 s each' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Stand Up <em>Sit Down</em>';
    const rules = h('div', { class: 'rules' });
    const r1 = h('div', { class: 'r', text: 'You will see a sentence.' });
    const r2 = h('div', { class: 'r' }); r2.innerHTML = '<span><span class="up">Stand up</span> = True · <span class="dn">sit down</span> = False</span>';
    const r3 = h('div', { class: 'r', text: "When time is up, don't move!" });
    rules.append(r1, r2, r3);
    const jr = h('div', { class: 'jrow' }, [
      h('div', { class: 'jelly plus' }, [ctx.img('assets/img/image31.png', { alt: 'Pink jellyfish', zoom: false }), h('b', { text: 'Correct: +1 / +2' })]),
      h('div', { class: 'jelly minus' }, [ctx.img('assets/img/image28.png', { alt: 'Blue jellyfish', zoom: false }), h('b', { text: 'Wrong: −1 / −2' })])
    ]);
    const go = h('button', { class: 'btn btn-primary pulse', text: 'Start the game ▶' });
    ctx.on(go, 'click', () => Engine.next());
    const say = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak("You will see a sentence. Stand up or sit down to choose True or False. When time is up, don't move!"));
    txt.append(t, rules, jr, h('div', { class: 'btnrow' }, [say, go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
