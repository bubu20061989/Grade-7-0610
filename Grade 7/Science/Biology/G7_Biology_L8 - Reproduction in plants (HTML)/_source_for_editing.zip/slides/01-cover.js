Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Reproduction in Plants', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    media.appendChild(ctx.img('assets/img/image14.png', { alt: 'Scientist holding a flask', zoom: false, class: 'hero-img float-anim' }));
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(ctx.img('assets/img/image12.png', { alt: 'Biology', zoom: false, class: 'biologo' }));
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Biology · Lesson 8' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Reproduction<br>in <em>Plants</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    const say = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak('Lesson 8. Reproduction in plants.'));
    txt.append(t, h('div', { class: 'hero-sub', text: 'Tap Let\'s start to begin' }), h('div', { class: 'btnrow' }, [say, go]));
    cov.append(txt, media);
    root.appendChild(cov);
  }
});
