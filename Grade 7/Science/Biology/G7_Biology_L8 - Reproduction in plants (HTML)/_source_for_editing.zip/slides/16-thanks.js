Engine.register({
  id: 'thanks', section: 'Consolidation', title: 'Thanks!', mech: 'outro', bg: 'thanks',
  render(root, ctx) {
    const cov = h('div', { class: 'cover thanks stagger' });
    const media = h('div', { class: 'cover-media' });
    const st = Engine.stars;
    const card = h('div', { class: 'starbig' }, [h('div', { class: 'num', text: '⭐ ' + st }), h('div', { class: 'lbl', text: st > 0 ? 'stars collected today' : 'Collect stars next time!' })]);
    media.appendChild(card);
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Thanks!</em>';
    const q = h('div', { class: 'quote', text: '“Adapt like nature, evolve like life.”' });
    const bS = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(bS, 'click', () => Sound.speak('Thanks! Adapt like nature, evolve like life.'));
    const bC = h('button', { class: 'btn btn-primary', text: '🎉 Celebrate' });
    ctx.on(bC, 'click', () => Engine.confetti('star'));
    txt.append(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Lesson 8 · Reproduction in Plants' })]), t, q, h('div', { class: 'btnrow' }, [bS, bC]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
