Engine.register({
  id: 'vocab-match', section: 'Vocabulary', title: 'Match the keywords', mech: 'match', bg: 'keys',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Match the Keywords' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its picture' }));
    const P = [
      { id: 'sac', label: 'embryo sac', img: 'image58.jpeg' },
      { id: 'fert', label: 'fertilisation', img: 'image59.jpeg' },
      { id: 'ind', label: 'individual', img: 'image60.png' },
      { id: 'pg', label: 'pollen grain', img: 'image61.png' },
      { id: 'poll', label: 'pollination', img: 'image62.png' },
      { id: 'zyg', label: 'zygote', img: 'image63.png' }
    ];
    const items = P.map(p => ({ id: p.id, label: p.label }));
    const zones = P.map(p => ({ id: 'z-' + p.id, accept: [p.id], capacity: 1, img: p.img, label: p.label }));
    const order = ctx.shuffle(zones);
    const dd = ctx.dragDrop({
      items, zones,
      renderZone: z => {
        const c = h('div', { class: 'card matcell' });
        c.appendChild(ctx.img('assets/img/' + z.img, { alt: 'Picture for a keyword', zoom: false }));
        c.appendChild(h('div', { class: 'slotline', text: 'Drop the word here' }));
        return c;
      }
    });
    const grid = h('div', { class: 'vgrid' }, order.map(z => dd.zoneEls[z.id]));
    const grow = h('div', { class: 'grow stagger' }, [grid]);
    root.appendChild(grow);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
