Engine.register({
  id: 'unscramble', section: 'Task 4–5 · Writing & Speaking', title: 'Task 4 · Make sentences', mech: 'unscramble', bg: 'task',
  render(root, ctx) {
    /* Cụm từ giữ NGUYÊN VĂN và đúng thứ tự xáo trộn như PPT gốc */
    const R = [
      { k: 'a', p: ['into', 'an embryo', 'and, later,', 'a new plant.', 'develops', 'The zygote'], ans: 'The zygote develops into an embryo and, later, a new plant.' },
      { k: 'b', p: ['produces', 'while', 'produces', 'pollen grains.', 'The female reproductive organ', 'the male one', 'embryo sacs'], ans: 'The female reproductive organ produces embryo sacs while the male one produces pollen grains.' },
      { k: 'c', p: ['produce', 'After the pollen grains', 'sperm,', 'toward', 'move', 'the sperm', 'the sacs.'], ans: 'After the pollen grains produce sperm, the sperm move toward the sacs.' },
      { k: 'd', p: ['on', 'land', 'The pollen grains', 'the female reproductive organ.'], ans: 'The pollen grains land on the female reproductive organ.' },
      { k: 'e', p: ['The fertilisation', 'an egg', 'inside', 'between', 'a sperm', 'happens', 'and', 'the sac.'], ans: 'The fertilisation happens between a sperm and an egg inside the sac.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 4 · Make Sentences' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the words and phrases in order. Tap a phrase in the line to send it back.' }));
    const tabs = h('div', { class: 'rtabs fixed' });
    const grow = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'stagecard unsc' });
    const head = h('div', { class: 'q' });
    const line = h('div', { class: 'uline' });
    const bank = h('div', { class: 'ubank' });
    card.append(head, line, bank);
    grow.appendChild(card);
    root.append(tabs, grow);
    let i = 0; const doneR = {};
    const norm = s => s.replace(/\s+/g, ' ').trim().toLowerCase();
    const paintTabs = () => { tabs.innerHTML = ''; R.forEach((r, k) => { const b = h('button', { class: 'rtab' + (k === i ? ' now' : '') + (doneR[k] ? ' done' : ''), text: r.k }); ctx.on(b, 'click', () => { i = k; paint(); }); tabs.appendChild(b); }); };
    const sync = () => line.classList.toggle('has', !!line.children.length);
    const paint = () => {
      paintTabs(); ctx.clearResult(line); line.innerHTML = ''; bank.innerHTML = ''; sync();
      head.innerHTML = ''; head.append(h('span', { class: 'ulabel', text: R[i].k }), 'Rearrange the words and phrases to make a sentence.');
      R[i].p.forEach(ph => {
        const c = h('button', { class: 'uchip', text: ph });
        ctx.on(c, 'click', () => {
          if (c.classList.contains('used')) return;
          c.classList.add('used'); Sound.playEffect('click'); ctx.clearResult(line);
          const m = h('button', { class: 'uchip', text: ph });
          ctx.on(m, 'click', () => { m.remove(); c.classList.remove('used'); ctx.clearResult(line); sync(); });
          line.appendChild(m); sync();
        });
        bank.appendChild(c);
      });
      card.classList.remove('pop-in'); void card.offsetWidth; card.classList.add('pop-in');
    };
    const built = () => Array.from(line.children).filter(n => n.classList.contains('uchip')).map(n => n.textContent).join(' ');
    root.appendChild(ctx.buttons({
      check: () => {
        const ok = norm(built()) === norm(R[i].ans);
        ctx.markResult(line, ok);
        if (ok) { doneR[i] = 1; paintTabs(); Sound.speak(R[i].ans); }
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => {
        /* xếp lại đúng các cụm theo câu đáp án (khớp tham lam từ trái sang phải) */
        line.querySelectorAll('.uchip').forEach(m => m.click());
        ctx.clearResult(line);
        let rest = norm(R[i].ans), guard = 0;
        while (rest && guard++ < 20) {
          const c = Array.from(bank.querySelectorAll('.uchip:not(.used)')).find(c => rest.startsWith(norm(c.textContent)));
          if (!c) break;
          c.click(); rest = rest.slice(norm(c.textContent).length).trim();
        }
      },
      reset: () => paint()
    }));
    paint();
  }
});
