Engine.register({
  id: 'read-d', section: 'Task 2 · Reading', title: 'Task 2d · Asexual or sexual?', mech: 'sort', bg: 'task',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 2d · Asexual or Sexual?' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'd. What are the differences? Sort the ideas from the text.' }));
    const items = [
      { id: 'a1', label: 'New plants grow from parts of a single mother plant' },
      { id: 'a2', label: 'Uses leaves, roots, stems or bulbs — except flowers' },
      { id: 'a3', label: 'Ginger, potatoes, strawberries, onions' },
      { id: 's1', label: 'Production and union of male and female gametes' },
      { id: 's2', label: 'Females produce embryo sacs with eggs' },
      { id: 's3', label: 'Males produce pollen grains; sperm appear from them' }
    ];
    const zones = [
      { id: 'asx', label: 'Asexual reproduction', accept: ['a1', 'a2', 'a3'], cls: 'asx' },
      { id: 'sx', label: 'Sexual reproduction', accept: ['s1', 's2', 's3'], cls: 'sx' }
    ];
    const dd = ctx.dragDrop({ items, zones, renderZone: z => h('div', { class: 'card bin sortbin ' + z.cls }, [h('div', { class: 'bin-label', text: z.label })]) });
    dd.tray.classList.add('sorttray');
    const model = h('div', { class: 'panel tight model ans reserve' });
    model.innerHTML = '<b class="a">Asexual:</b> new plants grow from various parts of a single mother plant, except flowers. <b class="s">Sexual:</b> involves the production and union of male and female gametes.';
    const grow = h('div', { class: 'grow stagger' }, [h('div', { class: 'bins-row' }, [dd.zoneEls.asx, dd.zoneEls.sx]), model]);
    root.appendChild(grow);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => { const r = dd.check(); if (r.correct === r.total) model.classList.add('shown'); return r; },
      show: () => { dd.show(); model.classList.add('shown'); },
      reset: () => { dd.reset(); model.classList.remove('shown'); }
    }));
  }
});
