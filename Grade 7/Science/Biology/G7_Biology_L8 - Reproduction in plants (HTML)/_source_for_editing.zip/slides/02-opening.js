Engine.register({
  id: 'opening', section: 'Warm-up', title: 'Task 1 · Opening problem', mech: 'tf-table', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 1 · Opening Problem' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Watch the video. Work in groups: True or False?' }));
    const S = [
      { t: 'a. Reproduction is to produce new individuals.', a: 'T' },
      { t: 'b. Two primary forms are asexual and sexual reproduction.', a: 'T' },
      { t: 'c. People can only find reproductive process in plants and animals.', a: 'F' },
      { t: 'd. Plants use only flowers for reproduction.', a: 'F' }
    ];
    const split = h('div', { class: 'split tf stagger' });
    const media = h('div', { class: 'media' }, [h('div', { class: 'vidbox' }, [Lab.video(ctx, 'assets/video/media1.mp4', 'assets/img/image23.png')])]);
    const tbl = h('table', { class: 'tftable' });
    tbl.appendChild(h('tr', {}, [h('th', { text: 'Statements' }), h('th', { text: 'True' }), h('th', { text: 'False' })]));
    const pick = {};
    const rows = S.map((s, i) => {
      const bt = h('button', { class: 'tfbtn t', text: 'T' });
      const bf = h('button', { class: 'tfbtn f', text: 'F' });
      const set = (v, quiet) => { pick[i] = v; bt.classList.toggle('on', v === 'T'); bf.classList.toggle('on', v === 'F'); ctx.clearResult(tr.firstChild); if (!quiet) Sound.playEffect('click'); };
      ctx.on(bt, 'click', () => set('T')); ctx.on(bf, 'click', () => set('F'));
      const tr = h('tr', {}, [h('td', { text: s.t }), h('td', { class: 'pick' }, [bt]), h('td', { class: 'pick' }, [bf])]);
      tr._set = set; tbl.appendChild(tr); return tr;
    });
    const side = h('div', {}, [h('div', { class: 'panel tight' }, [tbl])]);
    split.append(media, side);
    root.appendChild(split);
    const lastCell = (tr) => tr.firstChild;   /* huy hiệu ✓/✗ đặt ở ô câu, không đè nút T/F */
    root.appendChild(ctx.buttons({
      check: () => {
        let c = 0;
        rows.forEach((tr, i) => { const ok = pick[i] === S[i].a; if (ok) c++; ctx.markResult(lastCell(tr), ok); });
        return { correct: c, total: S.length };
      },
      show: () => rows.forEach((tr, i) => { tr._set(S[i].a, true); ctx.markResult(lastCell(tr), true, { shake: false }); }),
      reset: () => rows.forEach((tr, i) => { delete pick[i]; tr.querySelectorAll('.tfbtn').forEach(b => b.classList.remove('on')); ctx.clearResult(lastCell(tr)); })
    }));
  }
});
