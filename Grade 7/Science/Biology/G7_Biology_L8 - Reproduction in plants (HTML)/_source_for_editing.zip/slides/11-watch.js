Engine.register({
  id: 'watch', section: 'Task 3 · Watch & Listen', title: 'Task 3 · Watch the video', mech: 'checklist', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 3 · Pollination in a Minute' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Watch. Tick each step when you see it in the video.' }));
    const S = ['(1) Pollen grains and embryo sacs production', '(2) Pollination', '(3) Sperm production', '(4) Fertilisation and Zygote development'];
    const split = h('div', { class: 'split vw stagger' });
    const media = h('div', { class: 'media' }, [h('div', { class: 'vidbox' }, [Lab.video(ctx, 'assets/video/media2.mp4', 'assets/img/image68.png')])]);
    const items = S.map(s => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '' }), h('span', { text: s })]);
      ctx.on(b, 'click', () => { const on = b.classList.toggle('on'); b.querySelector('.box').textContent = on ? '✓' : ''; Sound.playEffect('click');
        if (items.every(x => x.classList.contains('on'))) { Engine.toast('🎉 You saw all 4 steps!'); Engine.confetti(); } });
      return b;
    });
    const side = h('div', {}, [h('div', { class: 'q', text: 'The 4 steps of sexual reproduction:' }), ...items]);
    split.append(media, side);
    root.appendChild(split);
    const bT = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(bT, 'click', () => Engine.timer(60));
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bR, 'click', () => items.forEach(b => { b.classList.remove('on'); b.querySelector('.box').textContent = ''; }));
    const bN = h('button', { class: 'btn btn-primary', text: 'Now match the steps ▶' });
    ctx.on(bN, 'click', () => Engine.next());
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bT, bR, bN]));
  }
});
