Engine.register({
  id: 'read-a', section: 'Task 2 · Reading', title: 'Task 2a · How many forms?', mech: 'highlight', bg: 'task',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 2 · Read the Text' }));
    const tt = Lab.tapText(Lab.TEXT);
    const grow = h('div', { class: 'grow center-col stagger' });
    grow.appendChild(h('div', { class: 'stagecard wide' }, [tt.el]));
    root.appendChild(grow);
    const q = h('div', { class: 'q fixed' }); q.innerHTML = 'a. How many forms of reproduction can a plant use? <b>Tap the names of the forms in the text.</b>';
    const ans = h('div', { class: 'ans reserve fixed', text: 'A plant can use either of 2 forms of reproduction: asexual or sexual, or both.' });
    root.append(q, ans);
    tt.words.forEach(s => ctx.on(s, 'click', () => { s.classList.toggle('on'); ctx.clearResult(s); s.classList.remove('is-ok', 'is-bad'); Sound.playEffect('click'); }));
    const target = s => s.dataset.w === 'asexual' || s.dataset.w === 'sexual';
    root.appendChild(ctx.buttons({
      check: () => {
        const on = tt.words.filter(s => s.classList.contains('on'));
        on.forEach(s => { s.classList.remove('is-ok', 'is-bad'); s.classList.add(target(s) ? 'is-ok' : 'is-bad'); });
        const hasA = on.some(s => s.dataset.w === 'asexual'), hasS = on.some(s => s.dataset.w === 'sexual');
        const extra = on.filter(s => !target(s)).length;
        const c = (hasA ? 1 : 0) + (hasS ? 1 : 0);
        if (c === 2 && !extra) ans.classList.add('shown');
        return { correct: extra ? 0 : c, total: 2 };
      },
      show: () => {
        tt.words.forEach(s => s.classList.remove('on', 'is-ok', 'is-bad'));
        tt.words.slice(0, 14).filter(target).forEach(s => s.classList.add('on', 'is-ok'));
        ans.classList.add('shown');
      },
      reset: () => { tt.words.forEach(s => s.classList.remove('on', 'is-ok', 'is-bad')); ans.classList.remove('shown'); }
    }));
  }
});
