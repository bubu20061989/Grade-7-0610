Engine.register({
  id: 'game', section: 'Warm-up', title: 'Game: True or False?', mech: 'game-tf', bg: 'game',
  render(root, ctx) {
    root.classList.add('on-dark');
    const R = [
      { s: 'Plants use only flowers for reproduction.', a: 'F' },
      { s: 'Reproduction is to produce new individuals.', a: 'T' },
      { s: 'Two primary forms are asexual and sexual reproduction.', a: 'T' },
      { s: 'People can only find reproductive processes in plants and animals.', a: 'F' }
    ];
    root.appendChild(h('div', { class: 'note fixed', text: 'Read · 10 seconds · Stand up for True, sit down for False' }));
    const wrap = h('div', { class: 'gamewrap stagger' });
    const cL = h('div', { class: 'char' }, [ctx.img('assets/img/image35.png', { alt: 'SpongeBob', zoom: false, class: 'float-anim' })]);
    const cR = h('div', { class: 'char' }, [ctx.img('assets/img/image37.png', { alt: 'Patrick Star', zoom: false })]);
    const core = h('div', { class: 'gamecore' });
    const count = h('div', { class: 'gcount', text: '10' });
    const pts = h('div', { class: 'jelly plus', style: 'visibility:hidden' });
    const state = h('div', { class: 'gstate' }, [count, pts]);
    const stmt = h('div', { class: 'gstmt' });
    const bT = h('button', { class: 'gside t' }, ['True', h('small', { text: 'STAND UP' })]);
    const bF = h('button', { class: 'gside f' }, ['False', h('small', { text: 'SIT DOWN' })]);
    const mid = h('div', { class: 'gmid' }, [h('span', { class: 'up', text: 'STAND UP' }), h('span', { class: 'or', text: 'OR' }), h('span', { class: 'dn', text: 'SIT DOWN' })]);
    const choice = h('div', { class: 'gchoice' }, [bT, mid, bF]);
    const dots = h('div', { class: 'gdots' });
    core.append(state, stmt, choice, dots);
    wrap.append(cL, core, cR);
    root.appendChild(wrap);

    let i = 0, left = 10, run = null, revealed = false;
    const stop = () => { if (run) { clearInterval(run); run = null; } };
    ctx._timers.push(stop);
    const paint = () => {
      stop(); revealed = false; left = 10;
      stmt.textContent = R[i].s; count.textContent = '10';
      [bT, bF].forEach(b => { b.classList.remove('dim', 'win'); ctx.clearResult(b); });
      pts.style.visibility = 'hidden';
      dots.innerHTML = ''; R.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (k < i ? 'done' : '') })));
      stmt.classList.remove('pop-in'); void stmt.offsetWidth; stmt.classList.add('pop-in');
      bStart.textContent = '⏱ Start 10s';
    };
    const reveal = () => {
      if (revealed) return; revealed = true; stop();
      const win = R[i].a === 'T' ? bT : bF, lose = win === bT ? bF : bT;
      win.classList.add('win'); lose.classList.add('dim');
      ctx.markResult(win, true, { sound: true });
      const n = Math.random() < .5 ? 1 : 2;
      pts.innerHTML = '';
      pts.append(ctx.img('assets/img/image31.png', { alt: 'Pink jellyfish', zoom: false }), h('b', { text: (R[i].a === 'T' ? 'Stand-up' : 'Sit-down') + ' team +' + n }));
      pts.style.visibility = 'visible'; pts.classList.remove('pop-in'); void pts.offsetWidth; pts.classList.add('pop-in');
      Engine.confetti();
    };
    const start = () => {
      stop(); revealed = false; left = 10; count.textContent = left;
      run = setInterval(() => {
        left--; count.textContent = left; count.classList.remove('tick'); void count.offsetWidth; count.classList.add('tick');
        if (left <= 0) { stop(); count.textContent = "Time's up!"; Sound.playEffect('bad'); }
      }, 1000);
    };
    const bStart = h('button', { class: 'btn btn-primary', text: '⏱ Start 10s' });
    const bShow = h('button', { class: 'btn btn-show', text: '👁 Show answer' });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn', text: 'Next round ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(bStart, 'click', () => { start(); Sound.speak(R[i].s); });
    ctx.on(bShow, 'click', reveal);
    ctx.on(bT, 'click', reveal); ctx.on(bF, 'click', reveal);
    ctx.on(bSay, 'click', () => Sound.speak(R[i].s));
    ctx.on(bPrev, 'click', () => { i = (i + R.length - 1) % R.length; paint(); });
    ctx.on(bNext, 'click', () => { if (i === R.length - 1) { Engine.toast('🎉 Game over! Well done!'); Engine.confetti('star'); } i = (i + 1) % R.length; paint(); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bStart, bShow, bNext]));
    paint();
  }
});
