Engine.register({
  id: 'consolidation', section: 'Consolidation', title: 'Consolidation', mech: 'review', bg: 'keys',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap each word to hear it. Tick what you can say.' }));
    const V = ['embryo – embryo sac', 'fertilization', 'individual', 'pollen grain', 'pollination', 'zygote', 'sperm', 'gamete'];
    const C = ['c-yel', 'c-blu', 'c-pnk', 'c-grn', 'c-pur', 'c-mint', 'c-org', 'c-yel'];
    const grow = h('div', { class: 'grow center-col stagger' });
    const vocab = h('div', { class: 'panel' }, [h('div', { class: 'qtitle', text: 'Vocabulary' }),
      h('div', { class: 'vchips' }, V.map((w, k) => { const b = h('button', { class: 'vchip ' + C[k], text: w }); ctx.on(b, 'click', () => Sound.speak(w.replace('–', ','))); return b; }))]);
    const sentTxt = 'There are two forms of reproduction in plants: asexual and sexual.';
    const sent = h('div', { class: 'panel' }, [h('div', { class: 'qtitle', text: 'Sentence' }), h('div', { class: 'keysent', text: sentTxt })]);
    ctx.on(sent, 'click', () => Sound.speak(sentTxt));
    const CK = ['I can say the 8 keywords.', 'I can describe the 2 forms of reproduction.', 'I will prepare the new lesson.'];
    const checks = h('div', { class: 'checkrow' }, CK.map(t => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => { const on = b.classList.toggle('on'); b.querySelector('.box').textContent = on ? '✓' : ''; Sound.playEffect('click'); });
      return b;
    }));
    const st = Engine.stars, done = Object.keys(Engine.done || {}).length;
    const msg = st > 0 ? '⭐ ' + st + ' stars today — great work!' : (done ? 'Keep practising — try the tasks again!' : 'Try the tasks to collect stars!');
    grow.append(vocab, sent, checks, h('div', { class: 'note', text: msg }));
    root.appendChild(grow);
    const bS = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(bS, 'click', () => Sound.speak(sentTxt));
    const bN = h('button', { class: 'btn btn-primary', text: 'Finish ▶' });
    ctx.on(bN, 'click', () => Engine.next());
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bS, bN]));
  }
});
