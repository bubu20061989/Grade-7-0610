Engine.register({
  id: 'read-b', section: 'Task 2 · Reading', title: 'Task 2b · Which part is not useful?', mech: 'mcq', bg: 'task',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 2b · Plant Parts' }));
    const sent = 'During asexual reproduction, new plants grow from various parts of a single mother plant such as leaves, roots, stems or bulbs, except flowers.';
    const q = h('div', { class: 'q fixed' }); q.innerHTML = 'b. According to the text, which part of plant is <b>not useful</b> for asexual reproduction?';
    root.appendChild(q);
    const grow = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'panel' }, [Lab.markText(sent, ['leaves', 'roots', 'stems', 'bulbs', 'flowers'])]);
    const P = ['leaves', 'roots', 'stems', 'bulbs', 'flowers'];
    let picked = null;
    const tiles = P.map((w, k) => {
      const b = h('button', { class: 'part p' + (k + 1) }, [h('span', { class: 'w', text: w })]);
      ctx.on(b, 'click', () => { picked = w; tiles.forEach(t => { t.classList.remove('picked'); ctx.clearResult(t); }); b.classList.add('picked'); Sound.speak(w); });
      return b;
    });
    const grid = h('div', { class: 'parts' }, tiles);
    const ans = h('div', { class: 'ans reserve', text: 'Flower is not useful for asexual reproduction.' });
    grow.append(card, grid, ans);
    root.appendChild(grow);
    root.appendChild(ctx.buttons({
      check: () => {
        tiles.forEach(t => ctx.clearResult(t));
        const ok = picked === 'flowers';
        if (picked) ctx.markResult(tiles[P.indexOf(picked)], ok);
        if (ok) ans.classList.add('shown');
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { tiles.forEach(t => { t.classList.remove('picked'); ctx.clearResult(t); }); ctx.markResult(tiles[4], true, { shake: false }); ans.classList.add('shown'); },
      reset: () => { picked = null; tiles.forEach(t => { t.classList.remove('picked'); ctx.clearResult(t); }); ans.classList.remove('shown'); }
    }));
  }
});
