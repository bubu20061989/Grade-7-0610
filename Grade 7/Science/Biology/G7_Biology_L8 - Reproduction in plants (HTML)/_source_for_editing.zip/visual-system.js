(function (global) {
  'use strict';
  if (global.Lab) return;
  var NS = 'http://www.w3.org/2000/svg';
  var Lab = {};
  global.Lab = Lab;

  function sv(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  Lab.sv = sv;
  function dv(cls, txt) { var d = document.createElement('div'); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  Lab.dv = dv;

  /* ===== 1. TẦNG NỀN THEO PHẦN HỌC (nằm ngoài .slide) ===== */
  /* Mỗi SECTION tự nhận 1 bảng màu theo thứ tự xuất hiện -> đổi bài không phải sửa gì.
     Chỉ định tay: Lab.PAL = { 'Tên section': ['#..','#..','#..'] }. */
  var POOL = [
    ['#5EEAD4', '#93C5FD', '#A7F3D0'],
    ['#7DD3FC', '#BAE6FD', '#5EEAD4'],
    ['#34D399', '#A3E635', '#A7F3D0'],
    ['#2DD4BF', '#34D399', '#93C5FD'],
    ['#A5B4FC', '#93C5FD', '#C7D2FE'],
    ['#FCD34D', '#A3E635', '#FDE68A']
  ];
  var palMap = null;
  function palFor(key) {
    if (!palMap) {
      palMap = {};
      var seen = [];
      Engine.slides.forEach(function (s) { var k = s.section || '-'; if (seen.indexOf(k) < 0) seen.push(k); });
      seen.forEach(function (k, i) { palMap[k] = POOL[i % POOL.length]; });
    }
    return (Lab.PAL && Lab.PAL[key]) || palMap[key] || POOL[0];
  }
  function rgba(hex, a) {
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.slice(0,2),16) + ',' + parseInt(h.slice(2,4),16) + ',' + parseInt(h.slice(4,6),16) + ',' + a + ')';
  }

  /* Khung gần trung tính, màu CHỈ ở 2 góc, giữa màn hình sạch tuyệt đối:
     không có gì nằm sau vùng chữ -> mắt không bị nhiễu. */
  function sceneD(c) {
    var sc = dv('scene');
    sc.style.background = 'linear-gradient(180deg,#FFFFFF 0%,#F7FBF9 56%,#EEF6F2 100%)';
    var tr = dv('deco');
    tr.style.right = '-16vw'; tr.style.top = '-34vh'; tr.style.width = '62vw'; tr.style.height = '62vw';
    tr.style.borderRadius = '50%'; tr.style.opacity = '1';
    tr.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[0], .26) + ' 0%,' + rgba(c[0], 0) + ' 66%)';
    sc.appendChild(tr);
    var bl = dv('deco');
    bl.style.left = '-20vw'; bl.style.bottom = '-32vh'; bl.style.width = '56vw'; bl.style.height = '56vw';
    bl.style.borderRadius = '50%'; bl.style.opacity = '1';
    bl.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[2], .22) + ' 0%,' + rgba(c[2], 0) + ' 66%)';
    sc.appendChild(bl);
    return sc;
  }

  var STYLES = { D: sceneD };
  Lab.bgStyle = 'P';   /* bài này: giữ hình nền gốc của PPT (scenePaper, cuối file) */
  function buildScene(key) { if (Lab.bgStyle === 'P') return scenePaper(key); return (STYLES[Lab.bgStyle] || sceneD)(palFor(key)); }

  var bgHost = null, curScene = null, curKey = null;
  function applyScene() {
    if (!bgHost) {
      bgHost = document.getElementById('bgLayer');
      if (!bgHost) { bgHost = dv(''); bgHost.id = 'bgLayer'; document.body.insertBefore(bgHost, document.body.firstChild); }
    }
    var def = Engine.slides[Engine.idx];
    var key = Lab.bgStyle === 'P' ? ((def && def.bg) || 'page') : ((def && def.section) || '-');
    if (key === curKey && !Lab.__force) return;
    Lab.__force = false;
    curKey = key;
    var next = buildScene(key);
    bgHost.appendChild(next);
    void next.offsetWidth;
    next.classList.add('on');
    var old = curScene;
    curScene = next;
    if (old) setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 700);
  }

  /* ===== 2. fitStage() — lưới an toàn chống vỡ =====
     Dùng biến CSS, KHÔNG transform:scale() lên .slide: tổ tiên có transform
     sẽ phá position:fixed của #dragLayer. */
  var fitRaf = 0, fitTries = 0;
  function curSlide() { return document.querySelector('.stage > .slide'); }
  function minFit() {
    var fs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--fs-scale')) || 1;
    return Math.min(1, 0.72 / fs);
  }
  /* Sàn CHÍNH XÁC cho từng slide: đo cỡ chữ NHỎ NHẤT đang hiện ở --fit = 1, rồi cho co
     đúng tới lúc cỡ đó chạm ngưỡng đọc được từ cuối lớp (1/40 chiều cao màn hình, tối
     thiểu 22px). Bỏ qua chữ trong <svg> vì nó co theo khung hình, không theo --fit. */
  function textFloor(slide) {
    var th = Math.max(22, global.innerHeight / 40);
    var min = Infinity;
    var nodes = slide.querySelectorAll('*');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.ownerSVGElement || n.tagName.toLowerCase() === 'svg') continue;
      var hasText = false;
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3 && c.nodeValue.trim()) { hasText = true; break; }
      }
      if (!hasText) continue;
      var r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      var fsz = parseFloat(getComputedStyle(n).fontSize);
      if (fsz && fsz < min) min = fsz;
    }
    if (!isFinite(min) || !th) return 0.45;
    /* co hệ số f => chữ nhỏ nhất thành min*f; cần min*f >= th => f >= th/min */
    return Math.max(0.45, Math.min(1, (th * 1.06) / min));   // +6% biên an toàn
  }
  /* Bài này: khối con (.grow/.split/thẻ) tràn nội dung nhưng .slide không cuộn (overflow:hidden)
     -> scrollHeight của .slide không đổi. Đo thêm từng khối để fitStage vẫn co chữ. */
  function innerOverflow(slide) {
    /* so khung LAYOUT (offset*, không bị transform của hiệu ứng .stagger làm lệch) của con trực tiếp
       với khung cha — scrollHeight báo nhầm khi có ảnh co giãn, getBoundingClientRect nhầm khi đang animate */
    var bx = slide.querySelectorAll('.grow, .split > *, .stagecard, .pcard, .card, .clozelist, .clozegrid, .rowwrap > *, .fc-wrap');
    for (var i = 0; i < bx.length; i++) {
      var box = bx[i]; if (!box.offsetHeight) continue;
      var kids = box.children;
      for (var j = 0; j < kids.length; j++) {
        var k = kids[j]; if (!k.offsetHeight) continue;
        var top, bot;
        if (k.offsetParent === box) { top = k.offsetTop; bot = top + k.offsetHeight; if (bot > box.clientHeight + 3 || top < -3) return true; }
        else if (k.offsetParent === box.offsetParent) { top = k.offsetTop; bot = top + k.offsetHeight; if (bot > box.offsetTop + box.offsetHeight + 3 || top < box.offsetTop - 3) return true; }
      }
    }
    return false;
  }
  function fitNow() {
    fitRaf = 0;
    var slide = curSlide();
    if (!slide) return;
    var lo = slide.__floor != null ? slide.__floor : minFit();
    var cur = parseFloat(slide.style.getPropertyValue('--fit'));
    if (!(cur > 0)) cur = 1;
    var guard = 0;
    /* Vòng lặp ĐỒNG BỘ: đọc scrollHeight ép trình duyệt tính lại layout ngay, nên slide
       vừa vào là đã vừa khung — không nhấp nháy 1-2 khung hình. */
    while ((slide.scrollHeight > slide.clientHeight + 1 || innerOverflow(slide)) && cur > lo + 0.001 && guard++ < 16) {
      cur = Math.max(lo, cur - 0.05);
      slide.style.setProperty('--fit', cur.toFixed(3));
    }
    fitTries = guard;
  }
  function scheduleFit() {
    if (fitRaf) return;
    fitRaf = global.requestAnimationFrame ? requestAnimationFrame(fitNow) : setTimeout(fitNow, 16);
  }
  function resetFit() {
    var slide = curSlide();
    if (slide) {
      slide.style.setProperty('--fit', '1');
      slide.__floor = textFloor(slide);
    }
    fitTries = 0;
    fitNow();
    scheduleFit();
  }
  Lab.setBgStyle = function (k) { Lab.bgStyle = k; Lab.__force = true; applyScene(); };
  Lab.fit = scheduleFit;
  Lab.refit = resetFit;

  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };

  /* ===== 3. NÚT LỚP HỌC: Tập trung / Giảm chuyển động ===== */
  function addNavButtons() {
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#focusBtn')) return;
    var anchor = nav.querySelector('#fullscreenBtn') || nav.querySelector('#tlockBtn');
    var mk = function (id, icon, title, cls) {
      var b = document.createElement('button');
      b.className = 'iconbtn'; b.id = id; b.textContent = icon; b.title = title;
      b.addEventListener('click', function () {
        var on = document.body.classList.toggle(cls);
        b.classList.toggle('on', on);
        try { sessionStorage.setItem('pref:' + cls, on ? '1' : '0'); } catch (e) { }
        Engine.toast(title + (on ? ' — ON' : ' — OFF'));
        resetFit();
      });
      try { if (sessionStorage.getItem('pref:' + cls) === '1') { document.body.classList.add(cls); b.classList.add('on'); } } catch (e) { }
      if (anchor) nav.insertBefore(b, anchor); else nav.appendChild(b);
      return b;
    };
    mk('focusBtn', '🎯', 'Focus mode', 'focus');
    mk('motionBtn', '🌀', 'Reduce motion', 'nomotion');
  }

  /* ===== 4. NỐI VÀO ENGINE ===== */
  var origGo = Engine.go;
  Engine.go = function (i, dir) {
    origGo.call(Engine, i, dir);
    applyScene();
    resetFit();
    setTimeout(scheduleFit, 140);
    setTimeout(scheduleFit, 620);
  };
  var origFs = Engine._applyFontScale;
  Engine._applyFontScale = function (v) { origFs.call(Engine, v); resetFit(); };

  var origStart = Engine.start;
  Engine.start = function (cfg) {
    origStart.call(Engine, cfg);
    applyScene();
    addNavButtons();
    resetFit();
    var stage = document.querySelector('.stage');
    if (stage) {
      if (global.ResizeObserver) new ResizeObserver(resetFit).observe(stage);
      else global.addEventListener('resize', resetFit);
      new MutationObserver(scheduleFit).observe(stage, { childList: true, subtree: true, characterData: true });
      stage.addEventListener('load', scheduleFit, true);   // ảnh tải xong -> đo lại
    }
    global.addEventListener('resize', resetFit);
    document.addEventListener('fullscreenchange', resetFit);
  };

  /* ===== 5. LỚP THẨM MỸ: icon SVG, thanh công cụ gọn, nhãn phần =====
     Chạy SAU engine dựng navbar, không sửa engine.js. Tắt từng phần nếu cần:
     Lab.tidyNav = false · Lab.svgIcons = false · Lab.autoEyebrow = false (đặt trong slide đầu). */
  var IC = {
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2.1 1.2M17.7 15.3l2.1 1.2M4.2 16.5l2.1-1.2M17.7 8.7l2.1-1.2"/><circle cx="12" cy="12" r="7"/>',
    check: '<path d="M4.5 12.5l4.8 4.8L19.5 7"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/>',
    sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 2.5h5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    star: '<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12"/>'
  };
  /* Icon vẽ bằng CSS mask (thẻ <i>), KHÔNG chèn <svg> vào DOM: qa.py mục 5 coi mọi <svg> là
     widget và báo "QUÁ NHỎ" oan cho icon trong nút. Màu icon = currentColor của nút. */
  Lab.icon = function (name) {
    var i = document.createElement('i');
    i.className = 'ic'; i.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (IC[name] || '') + '</svg>';
    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    i.style.webkitMaskImage = url; i.style.maskImage = url;
    return i;
  };
  function setIcon(btn, name) { if (!btn) return; btn.textContent = ''; btn.appendChild(Lab.icon(name)); }

  /* Emoji đầu nhãn nút -> icon SVG cùng nghĩa. Emoji không có trong bảng thì để nguyên. */
  var LEAD = [
    [/^\s*(✅|✔️?)\s*/, 'check'], [/^\s*👁️?\s*/, 'eye'], [/^\s*(↺|🔄)\s*/, 'reset'],
    [/^\s*(🔊|🔈)\s*/, 'sound'], [/^\s*(⏱️?)\s*/, 'timer'], [/^\s*(▶️?)\s*/, 'play'], [/^\s*(↩️?)\s*/, 'undo']
  ];
  function iconizeButtons(scope) {
    if (Lab.svgIcons === false || !scope) return;
    scope.querySelectorAll('.btn').forEach(function (b) {
      if (b.querySelector('.ic') || b.children.length) return;
      var t = b.textContent;
      for (var i = 0; i < LEAD.length; i++) {
        if (LEAD[i][0].test(t)) { b.textContent = t.replace(LEAD[i][0], ''); b.insertBefore(Lab.icon(LEAD[i][1]), b.firstChild); return; }
      }
    });
  }
  Lab.iconize = iconizeButtons;

  function tidyNav() {
    if (Lab.tidyNav === false) return;
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#tdrawerBtn')) return;
    var byTitle = function (p) { var r = null; nav.querySelectorAll('.iconbtn').forEach(function (b) { if (!r && (b.title || '').indexOf(p) === 0) r = b; }); return r; };
    var prev = byTitle('Previous'), next = byTitle('Next'), full = nav.querySelector('#fullscreenBtn');
    var drawer = dv(''); drawer.id = 'tdrawer';
    var row = function (label, els) {
      els = els.filter(Boolean); if (!els.length) return;
      var r = dv('row'); r.appendChild(dv('lbl', label)); els.forEach(function (e) { r.appendChild(e); }); drawer.appendChild(r);
    };
    row('Text size', [nav.querySelector('.fs-group')]);
    row('Sound', [byTitle('Mute'), nav.querySelector('#voiceBtn')]);
    row('Teams', [nav.querySelector('.teams')]);
    row('Class tools', [byTitle('Timer'), byTitle('Spotlight'), byTitle('Slides')]);
    row('Display', [nav.querySelector('#focusBtn'), nav.querySelector('#motionBtn')]);
    row('Lock', [nav.querySelector('#tlockBtn')]);
    document.body.appendChild(drawer);

    var tb = document.createElement('button');
    tb.id = 'tdrawerBtn'; tb.className = 'iconbtn tbtn'; tb.title = 'Teacher tools';
    tb.appendChild(Lab.icon('gear')); tb.appendChild(document.createTextNode('Teacher'));
    tb.addEventListener('click', function (e) { e.stopPropagation(); drawer.classList.toggle('on'); });
    document.addEventListener('pointerdown', function (e) {
      if (drawer.classList.contains('on') && !drawer.contains(e.target) && !tb.contains(e.target)) drawer.classList.remove('on');
    });
    var anchor = full || prev;
    if (anchor) nav.insertBefore(tb, anchor); else nav.appendChild(tb);

    if (Lab.svgIcons !== false) {
      if (prev) { setIcon(prev, 'prev'); prev.classList.add('nav-arrow'); }
      if (next) { setIcon(next, 'next'); next.classList.add('nav-arrow'); }
      if (full) {
        var sync = function () { setIcon(full, document.fullscreenElement ? 'shrink' : 'expand'); };
        sync(); document.addEventListener('fullscreenchange', function () { setTimeout(sync, 0); });
      }
    }
  }

  /* Nhãn phần (section) nhỏ phía trên tiêu đề — người xem luôn biết đang ở phần nào của bài */
  function addEyebrow() {
    if (Lab.autoEyebrow === false) return;
    var slide = curSlide(); var def = Engine.slides[Engine.idx];
    if (!slide || !def || !def.section || slide.querySelector('.eyebrow, .cover')) return;
    var pill = slide.querySelector(':scope > .pill');
    if (!pill || pill.textContent.toLowerCase().indexOf(def.section.toLowerCase()) >= 0) return;
    var eb = dv('eyebrow fixed', def.section);
    slide.insertBefore(eb, pill);
    /* Nhãn phần là trang trí: slide chật (font 150%, màn dọc) thì bỏ nhãn TRƯỚC khi fitStage phải co chữ */
    var f0 = slide.style.getPropertyValue('--fit');
    slide.style.setProperty('--fit', '1');
    var tight = slide.scrollHeight > slide.clientHeight + 1;
    if (f0) slide.style.setProperty('--fit', f0);
    if (tight || global.innerHeight < 560) eb.remove();
    resetFit();
  }

  var goAes = Engine.go;
  Engine.go = function (i, dir) {
    goAes.call(Engine, i, dir);
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
  };
  var startAes = Engine.start;
  Engine.start = function (cfg) {
    startAes.call(Engine, cfg);
    tidyNav();
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
    var st = document.querySelector('.stage');
    if (st) new MutationObserver(function () { iconizeButtons(st); }).observe(st, { childList: true, subtree: true });
  };

  /* ===================== 6. RIÊNG BÀI G7 · BIOLOGY L8 ===================== */
  /* Nền: hình minh hoạ nền GỐC của PPT (chỉ lớp trang trí, đã bỏ chữ/nội dung), mỗi slide chọn qua def.bg:
     cover · page · game · keys · task · thanks. Nằm trong #bgLayer (luật 13), Focus mode tắt về nền phẳng. */
  function scenePaper(key) {
    var sc = dv('scene paper bg-' + key);
    sc.style.backgroundImage = 'url("assets/img/bg-' + key + '.jpg")';
    return sc;
  }

  /* Văn bản đọc Task 2 — giữ NGUYÊN VĂN PPT gốc (bản slide 20: "strawberry plants") */
  Lab.TEXT = 'There are two forms of reproduction in plants: asexual and sexual. Although sexual reproduction is the most common form, many plants can use both. During asexual reproduction, new plants grow from various parts of a single mother plant such as leaves, roots, stems or bulbs, except flowers. For examples, ginger and potatoes reproduce by underground stems while new strawberry plants grow from stems on the ground. Onions grows from bulbs, sweet potatoes grows from roots and kalanchoes use its leaves. Sexual reproduction involves the production and union of male and female gametes - the special types of cells - to carry the information of males and females. A large number of females produce embryo sacs to contain female gametes (eggs) while males produce pollen grains. The male gametes (sperm) appear from the pollen grains during the process.';
  /* Đoạn văn thành từng từ chạm được: trả về {el, words:[span]} ; span.dataset.w = từ chuẩn hoá */
  Lab.tapText = function (text, cls) {
    var p = dv(cls || 'passage'); var words = [];
    text.split(/(\s+)/).forEach(function (tok) {
      if (!tok) return;
      if (/^\s+$/.test(tok)) { p.appendChild(document.createTextNode(' ')); return; }
      var s = document.createElement('span'); s.className = 'tw'; s.textContent = tok;
      s.dataset.w = tok.toLowerCase().replace(/[^a-z\-]/g, '');
      p.appendChild(s); words.push(s);
    });
    return { el: p, words: words };
  };
  /* Đoạn văn tô sáng sẵn các cụm trong marks[] */
  Lab.markText = function (text, marks, cls) {
    var p = dv(cls || 'passage'); var html = text.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    (marks || []).forEach(function (m) { html = html.split(m).join('<span class="hl">' + m + '</span>'); });
    p.innerHTML = html; return p;
  };

  /* Giữ nguyên chiều cao khay trong lúc kéo: nhấc thẻ ra khỏi khay làm khay co lại -> các ô thả phía
     trên bị dời chỗ NGAY DƯỚI ngón tay học sinh (đã đo thật bằng Playwright: thả trượt ô). Khoá min-height
     của khay từ lúc chạm tới khi thả xong, rồi nhả ra. */
  document.addEventListener('pointerdown', function (e) {
    var it = e.target && e.target.closest ? e.target.closest('.dd-tray > .drag-item') : null;
    if (!it) return;
    var tray = it.parentNode;
    tray.style.minHeight = tray.getBoundingClientRect().height + 'px';
    var rel = function () {
      document.removeEventListener('pointerup', rel, true); document.removeEventListener('pointercancel', rel, true);
      setTimeout(function () { tray.style.minHeight = ''; }, 60);
    };
    document.addEventListener('pointerup', rel, true); document.addEventListener('pointercancel', rel, true);
  }, true);

  /* Trình phát audio gốc (track thu sẵn) — đi qua Sound.playEffect? Không: audio dài cần tua/dừng,
     nên dùng 1 thẻ <audio> do slide quản lý + dừng khi rời slide (ctx.on cleanup). */
  Lab.player = function (ctx, src, label) {
    var a = document.createElement('audio'); a.src = src; a.preload = 'metadata';
    var b = document.createElement('button'); b.className = 'btn btn-primary'; b.textContent = '▶ ' + (label || 'Play');
    var bar = dv('bar'); var fill = document.createElement('i'); bar.appendChild(fill);
    var wrap = dv('player'); wrap.append(b, bar);   /* <audio> không gắn vào DOM: vẫn phát được, không bị tính là phần tử ẩn */
    ctx.on(b, 'click', function () {
      if (a.paused) { Sound.stopAll(); a.play().catch(function () { Engine.toast('Audio could not play'); }); }
      else a.pause();
    });
    var paint = function () { b.textContent = (a.paused ? '▶ ' : '⏸ ') + (label || 'Play'); Lab.iconize(wrap); };
    ctx.on(a, 'play', paint); ctx.on(a, 'pause', paint); ctx.on(a, 'ended', paint);
    ctx.on(a, 'timeupdate', function () { if (a.duration) fill.style.transform = 'scaleX(' + (a.currentTime / a.duration) + ')'; });
    ctx._timers.push(function () { try { a.pause(); } catch (e) { } });
    return wrap;
  };
  /* Video gốc: <video controls> + poster; tự dừng khi rời slide */
  Lab.video = function (ctx, src, poster) {
    var v = document.createElement('video');
    v.className = 'vid'; v.src = src; v.controls = true; v.preload = 'metadata'; v.setAttribute('playsinline', '');
    if (poster) v.poster = poster;
    ctx.on(v, 'play', function () { Sound.stopAll(); });
    ctx._timers.push(function () { try { v.pause(); } catch (e) { } });
    return v;
  };
})(window);
