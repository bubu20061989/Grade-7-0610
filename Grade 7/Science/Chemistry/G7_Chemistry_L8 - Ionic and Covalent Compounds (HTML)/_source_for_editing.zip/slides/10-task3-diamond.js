/* Task 3 tách 2 slide (Diamond / Graphite): cả đoạn văn gốc không vừa 1 màn ở cỡ chữ đọc được từ cuối lớp.
   Khay vẫn đủ 8 từ như sách -> chấm theo Ô ĐÍCH (từ của nửa kia là thẻ nhiễu). */
Engine.register({
  id: 'task3-diamond', section: 'Practice', title: 'Task 3: Listen and fill (Diamond)', mech: 'cloze',
  render(root, ctx) {
    Lab.cloze(root, ctx, {
      title: 'Task 3 · p.19 · Diamond', cls: 'dia', head: 'Diamond', nums: [1, 2, 3, 4],
      parts: ['Diamond is one of the forms of carbon. It is an expensive gemstone for ', 1, '. We use diamond to make the tips of drills and the ', 2,
        ' edges of other tools. This is because of its unique ', 3, ' and very high melting and boiling points. Diamond does not conduct electricity. Inside diamonds, carbon atoms form a three-dimensional structure. Each atom connects to ', 4, ' other ones.']
    });
  }
});
