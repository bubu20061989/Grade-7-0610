Engine.register({
  id: 'mission', section: 'Detective Game', title: 'Mission: salt, sugar, water', mech: 'quiz',
  render(root, ctx) {
    const M = [
      { n: 'Water', photo: 'p-water.jpeg', f: 'f-water.png', a: 1, why: 'Hydrogen and oxygen are both non-metals → covalent!' },
      { n: 'Sugar', photo: 'p-sugar.jpeg', f: 'f-sugar.png', a: 1, why: 'Carbon, hydrogen and oxygen are all non-metals → covalent!' },
      { n: 'Salt', photo: 'p-salt.jpeg', f: 'f-salt.png', a: 0, why: 'Sodium (metal) + chlorine (non-metal) → ionic!' }
    ];
    const ans = M.map(() => null);
    let i = 0;
    root.appendChild(h('div', { class: 'pill fixed', text: 'Ionic or covalent?' }));
    const sp = h('div', { class: 'split grow stagger mission' });
    const left = h('div', { class: 'media' });
    const right = h('div', {});
    sp.append(left, right);
    root.appendChild(sp);
    const bI = h('button', { class: 'opt ion', text: 'Ionic compound' });
    const bC = h('button', { class: 'opt cov', text: 'Covalent compound' });
    const pick = h('div', { class: 'bondpick' }, [bI, bC]);
    const name = h('div', { class: 'mname' });
    const result = h('div', { style: 'display:flex;flex-direction:column;gap:clamp(4px,1vh,12px);flex:0 1 auto;min-height:0' });
    const bTimer = h('button', { class: 'btn', text: '⏱ 30s' });
    ctx.on(bTimer, 'click', () => Engine.timer(30));
    right.append(name, h('div', { class: 'note', text: 'Discuss with your elbow partner, then choose.' }), pick, result);

    const dots = h('div', { class: 'dots' }, M.map(() => h('i')));
    const bPrev = h('button', { class: 'btn', text: '◀' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next ▶' });
    root.appendChild(h('div', { class: 'stepnav fixed' }, [bPrev, bTimer, dots, bNext]));

    const paint = () => {
      const m = M[i];
      left.innerHTML = '';
      left.appendChild(ctx.img('assets/img/' + m.photo, { alt: m.n, class: 'photo pop-in' }));
      name.textContent = m.n;
      [bI, bC].forEach(b => { b.classList.remove('picked'); ctx.clearResult(b); });
      result.innerHTML = '';
      if (ans[i] !== null) {
        const b = ans[i] === 0 ? bI : bC;
        b.classList.add('picked');
        ctx.markResult(b, ans[i] === m.a);
        result.append(
          ctx.img('assets/img/' + m.f, { alt: m.n + ' formula', zoom: false, class: 'formula pop-in' }),
          h('div', { class: 'mbanner' }, [ctx.img('assets/img/detective.png', { alt: 'Detective', zoom: false }), h('div', { class: 'verdict', text: m.a === 0 ? 'ionic compound' : 'covalent compound' })]),
          h('div', { class: 'why', text: m.why }));
      }
      Array.from(dots.children).forEach((d, k) => { d.className = k === i ? 'now' : (ans[k] !== null ? 'done' : ''); });
      bPrev.disabled = i === 0;
      bNext.textContent = i === M.length - 1 ? 'Finish ✓' : 'Next ▶';
    };
    const choose = v => {
      if (ans[i] !== null) return;
      ans[i] = v;
      const ok = v === M[i].a;
      Engine.score(ok ? 1 : 0, 1);
      paint();
      if (ok) Engine.confetti('burst');
    };
    ctx.on(bI, 'click', () => choose(0));
    ctx.on(bC, 'click', () => choose(1));
    ctx.on(bPrev, 'click', () => { if (i > 0) { i--; paint(); } });
    ctx.on(bNext, 'click', () => { if (i < M.length - 1) { i++; paint(); } else Engine.next(); });
    paint();
  }
});
