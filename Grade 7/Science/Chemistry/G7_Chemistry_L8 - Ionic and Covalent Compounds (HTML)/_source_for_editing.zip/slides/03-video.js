Engine.register({
  id: 'video', section: 'Warm-up', title: 'Video: Ionic vs. Covalent Bonds', mech: 'video',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in · Watch' }));
    const g = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'stagecard', style: 'flex:1 1 auto;min-height:0' });
    const v = h('video', { class: 'vid', src: 'assets/video/media1.mp4', poster: 'assets/img/video1-poster.png', controls: '', preload: 'metadata', playsinline: '' });
    const box = h('div', { class: 'vidbox' }, [v]);
    card.append(box, h('div', { class: 'note', text: 'Ionic vs. Covalent Bonds: What’s the Difference? — tap ▶ to watch' }));
    g.appendChild(card);
    root.appendChild(g);
  }
});
