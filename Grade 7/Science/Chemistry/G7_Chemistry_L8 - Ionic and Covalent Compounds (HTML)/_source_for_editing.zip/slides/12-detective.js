Engine.register({
  id: 'detective', section: 'Detective Game', title: 'Chemistry Detective!', mech: 'transition',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' }, [ctx.img('assets/img/detective-cover.jpg', { alt: 'Chemistry Detective!', zoom: false, class: 'hero-img' })]);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Game' }), h('span', { class: 'tag', text: 'Salt · Sugar · Water' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Chemistry <em>Detective</em>!';
    const things = [['p-sugar.jpeg', 'sugar'], ['p-water.jpeg', 'water'], ['p-salt.jpeg', 'salt']];
    const thumbs = h('div', { class: 'thumbs' }, things.map(([f, n]) => {
      const im = ctx.img('assets/img/' + f, { alt: n, zoom: false });
      ctx.on(im, 'click', () => { im.classList.remove('nudge'); void im.offsetWidth; im.classList.add('nudge'); Sound.speak(n); });
      return im;
    }));
    const go = h('button', { class: 'btn btn-primary pulse', text: 'Start the mission ▶' });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: 'Is each one an ionic compound or a covalent compound?' }), thumbs, h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
