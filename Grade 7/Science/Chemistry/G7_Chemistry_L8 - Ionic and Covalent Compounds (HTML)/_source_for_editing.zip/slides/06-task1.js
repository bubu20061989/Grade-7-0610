Engine.register({
  id: 'task1', section: 'Practice', title: 'Task 1: What type of bond?', mech: 'classify',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 1 · p.18' }));
    root.appendChild(h('div', { class: 'note lead fixed', text: 'Work in pairs. What type of bond is in each compound?' }));
    const sp = h('div', { class: 'split vidsplit grow stagger' });
    const v = h('video', { class: 'vid', src: 'assets/video/media2.mp4', poster: 'assets/img/video2-poster.png', controls: '', preload: 'metadata', playsinline: '' });
    const media = h('div', { class: 'media' }, [h('div', { class: 'vidbox' }, [v]), h('div', { class: 'note', text: '20-second video' })]);
    const cs = [
      { img: 'assets/img/c-sodium-chloride.png', alt: 'Sodium chloride', a: 0 },
      { img: 'assets/img/c-water.png', alt: 'Water', a: 1 },
      { img: 'assets/img/c-hydrogen-chloride.png', alt: 'Hydrogen chloride', a: 1 },
      { img: 'assets/img/c-magnesium-oxide.png', alt: 'Magnesium oxide', a: 0 }
    ];
    const picks = [];
    const grid = h('div', { class: 'cgrid' }, cs.map(c => {
      const p = Lab.pick(ctx, [{ label: 'Ionic', cls: 'ion' }, { label: 'Covalent', cls: 'cov' }], c.a);
      picks.push(p);
      return h('div', { class: 'cell' }, [ctx.img(c.img, { alt: c.alt }), p]);
    }));
    sp.append(media, h('div', {}, [grid]));
    root.appendChild(sp);
    const grp = Lab.group(picks);
    root.appendChild(ctx.buttons({
      check: () => { const r = grp.check(); if (r.correct === r.total) Engine.confetti('burst'); return r; },
      show: () => grp.show(), reset: () => grp.reset()
    }));
  }
});
