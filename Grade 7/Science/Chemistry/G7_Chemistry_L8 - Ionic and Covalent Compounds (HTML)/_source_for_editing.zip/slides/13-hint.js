Engine.register({
  id: 'hint', section: 'Detective Game', title: 'Hint: metal or non-metal?', mech: 'reveal',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '💡 Hint' }));
    root.appendChild(h('div', { class: 'note lead fixed', text: 'Look at the elements! Tap ? to reveal.' }));
    const chips = [];
    const q = (word) => {
      const b = h('button', { class: 'qchip', text: '?' });
      ctx.on(b, 'click', () => {
        if (b.classList.contains('on')) return;
        b.classList.add('on'); b.textContent = word; Sound.speak(word);
      });
      chips.push([b, word]);
      return b;
    };
    const panel = (cls, title, a, b, picA, picB, w1, w2) => h('div', { class: 'hcell ' + cls }, [
      h('div', { class: 'bt', text: title }),
      h('div', { class: 'pics' }, [ctx.img(picA, { alt: title }), ctx.img(picB, { alt: title, zoom: false })]),
      h('div', { class: 'eqrow' }, [q(w1), h('span', { class: 'plus', text: '+' }), q(w2)])
    ]);
    const g = h('div', { class: 'grow' });
    g.appendChild(h('div', { class: 'hintgrid stagger' }, [
      panel('ion', 'IONIC BOND · tug-of-war', 0, 0, 'assets/img/hint-ionic.png', 'assets/img/kids-tug.png', 'metal', 'non-metal'),
      panel('cov', 'COVALENT BOND · sharing', 0, 0, 'assets/img/hint-covalent.png', 'assets/img/kids-share.png', 'non-metal', 'non-metal')
    ]));
    root.appendChild(g);
    const bAll = h('button', { class: 'btn btn-show', text: '👁 Reveal all' });
    const bHide = h('button', { class: 'btn btn-reset', text: '↺ Hide' });
    ctx.on(bAll, 'click', () => chips.forEach(([b, w]) => { b.classList.add('on'); b.textContent = w; }));
    ctx.on(bHide, 'click', () => chips.forEach(([b]) => { b.classList.remove('on'); b.textContent = '?'; }));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bAll, bHide]));
  }
});
