Engine.register({
  id: 'task3-graphite', section: 'Practice', title: 'Task 3: Listen and fill (Graphite)', mech: 'cloze',
  render(root, ctx) {
    Lab.cloze(root, ctx, {
      title: 'Task 3 · p.19 · Graphite', cls: 'gra', head: 'Graphite', nums: [5, 6, 7, 8],
      parts: ['Graphite is another form of carbon. It is ', 5, ', slippery. It is a good ', 6,
        ' of electricity. We use graphite in dry lubricants, electrodes, and pencil ', 7, '. Inside graphite, carbon atoms form a continuous layer of hexagons. Each atom connects to ', 8, ' other ones.']
    });
  }
});
