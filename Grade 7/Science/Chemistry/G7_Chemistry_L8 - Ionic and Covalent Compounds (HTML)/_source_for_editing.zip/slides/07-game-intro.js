Engine.register({
  id: 'game-intro', section: 'Practice', title: "Task 2: Let's play True or False", mech: 'transition',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' }, [h('div', { class: 'duo' }, [
      ctx.img('assets/img/signpost.png', { alt: 'True / False signpost', zoom: false, class: 'float-anim' }),
      ctx.img('assets/img/detective.png', { alt: 'Detective with a magnifying glass', zoom: false })
    ])]);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Task 2 · p.18' }), h('span', { class: 'tag', text: "Let's play game" })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>True</em> or <em>False</em>?';
    const bRead = h('button', { class: 'btn', text: '📖 Read the passage' });
    ctx.on(bRead, 'click', () => Engine.lightbox('assets/img/passage.png', 'Reading passage: ionic compounds and covalent substances'));
    const go = h('button', { class: 'btn btn-primary pulse', text: 'Start ▶' });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: 'Read the passage and decide whether the statements are True or False.' }), h('div', { class: 'btnrow' }, [bRead, go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
