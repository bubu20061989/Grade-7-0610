Engine.register({
  id: 'goodbye', section: 'Wrap-up', title: 'Goodbye', mech: 'outro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const pic = ctx.img('assets/img/goodbye.png', { alt: 'Goodbye', zoom: false, class: 'hero-img float-anim' });
    ctx.on(pic, 'click', () => { Engine.confetti('burst'); Sound.speak('Goodbye! See you next lesson.'); });
    const media = h('div', { class: 'cover-media' }, [pic]);
    const txt = h('div', { class: 'cover-text' });
    const done = Object.keys(Engine.done || {}).length;
    const msg = Engine.stars > 0 ? '⭐ ' + Engine.stars + ' stars today — great detective work!' : (done > 3 ? 'Well done today, scientists!' : 'Thank you for exploring with us!');
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Lesson 8 · Done' })]));
    const q = h('div', { class: 'quote' }); q.innerHTML = '“We are all <em>scientists</em> when we dare to ask and explore.”';
    txt.append(q, h('div', { class: 'hero-sub', text: msg }),
      h('div', { class: 'btnrow' }, [ctx.speakBtn('We are all scientists when we dare to ask and explore.', ' Listen')]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
