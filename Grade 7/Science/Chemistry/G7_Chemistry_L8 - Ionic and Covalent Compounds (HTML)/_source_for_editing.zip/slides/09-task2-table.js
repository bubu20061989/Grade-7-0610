Engine.register({
  id: 'task2-table', section: 'Practice', title: 'Task 2: Complete the table', mech: 'table',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 2 · p.18' }));
    root.appendChild(h('div', { class: 'note lead fixed', text: 'Tick True or False for each statement.' }));
    const S = [
      ['a', 'An ionic compound has a high melting point, so it is usually a solid at room temperature and pressure.', 0],
      ['b', 'An ionic compound can dissolve in water.', 0],
      ['c', 'Most simple molecular substances can conduct electricity.', 1],
      ['d', 'Methane has low melting and boiling points.', 0],
      ['e', 'All substances with giant molecular structures have high melting points and conduct electricity.', 1]
    ];
    const g = h('div', { class: 'grow center-col' });
    const card = h('div', { class: 'stagecard' });
    const tb = h('div', { class: 'tftable stagger' });
    tb.append(h('div', { class: 'hd', text: 'Statements' }), h('div', { class: 'hd', text: 'True / False' }));
    const picks = [];
    S.forEach(r => {
      const st = h('div', { class: 'st' }); st.append(h('b', { text: r[0] + '. ' }), document.createTextNode(r[1]));
      const p = Lab.pick(ctx, [{ label: 'True' }, { label: 'False' }], r[2], 'tfpick');
      picks.push(p);
      tb.append(st, p);
    });
    card.appendChild(tb);
    g.appendChild(card);
    root.appendChild(g);
    const grp = Lab.group(picks);
    root.appendChild(ctx.buttons({
      check: () => { const r = grp.check(); if (r.correct === r.total) Engine.confetti('star'); return r; },
      show: () => grp.show(), reset: () => grp.reset()
    }));
  }
});
