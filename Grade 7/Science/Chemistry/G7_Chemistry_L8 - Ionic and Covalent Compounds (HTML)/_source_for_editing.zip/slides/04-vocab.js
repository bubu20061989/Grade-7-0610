Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'New vocabulary (flashcards)', mech: 'flashcard',
  render(root, ctx) {
    const words = [
      { w: 'ionic compounds', pos: '(n phr)', ipa: '/ˌaɪˈɑːnɪk ˈkɑːmpaʊndz/', img: 'assets/img/v-ionic.png',
        def: 'chemical compounds composed of positively charged ions (cations) and negatively charged ions (anions) held together by electrostatic attraction. These compounds are formed through the transfer of electrons from one atom to another.' },
      { w: 'covalent substances', pos: '(n phr)', ipa: '/koʊˈveɪ.lənt ˈsʌb.stən.sɪz/', img: 'assets/img/v-covalent.jpeg',
        def: 'chemical compounds formed by the sharing of electron pairs between atoms.' },
      { w: 'properties', pos: '(n)', ipa: '/ˈprɑː.pɚ.tiz/', img: 'assets/img/v-properties.png',
        def: 'the characteristics that enable us to differentiate one material from another' }
    ];
    let i = 0;
    const seen = new Set();
    root.appendChild(h('div', { class: 'pill fixed', text: 'New vocabulary' }));
    const g = h('div', { class: 'grow center-col stagger' });
    const wrap = h('div', { class: 'vfc-wrap' });
    const card = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face front' });
    const back = h('div', { class: 'face back' });
    card.append(front, back);
    wrap.appendChild(card);
    const dots = h('div', { class: 'dots' }, words.map(() => h('i')));
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const paint = () => {
      const it = words[i];
      card.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      const im = ctx.img(it.img, { alt: it.w, zoom: false, class: 'fitimg pop-in' });
      front.append(im, h('div', { class: 'word', text: it.w }), h('div', { class: 'tapflip', text: '👆 Tap the card to see the meaning' }));
      back.append(h('div', { class: 'word', text: it.w }), h('div', { class: 'pron', text: it.pos + ' ' + it.ipa }), h('div', { class: 'defn', text: it.def }));
      seen.add(i);
      Array.from(dots.children).forEach((d, k) => { d.className = k === i ? 'now' : (seen.has(k) ? 'done' : ''); });
      bPrev.disabled = i === 0;
      bNext.textContent = i === words.length - 1 ? 'Finish ✓' : 'Next word ▶';
    };
    ctx.on(card, 'click', () => { card.classList.toggle('flipped'); Sound.playEffect('click'); });
    ctx.on(bPrev, 'click', () => { if (i > 0) { i--; paint(); } });
    ctx.on(bNext, 'click', () => {
      if (i < words.length - 1) { i++; paint(); }
      else { Engine.confetti('star'); Engine.toast('Great! 3 new words.'); }
    });
    ctx.on(bSay, 'click', () => { const it = words[i]; Sound.speak(card.classList.contains('flipped') ? it.w + '. ' + it.def : it.w); });
    g.append(wrap, dots);
    root.appendChild(g);
    const rep = h('button', { class: 'btn', text: '🔁 x3' });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, rep, bNext]));
    ctx.on(rep, 'click', () => Sound.repeat(words[i].w, 3));
    paint();
  }
});
