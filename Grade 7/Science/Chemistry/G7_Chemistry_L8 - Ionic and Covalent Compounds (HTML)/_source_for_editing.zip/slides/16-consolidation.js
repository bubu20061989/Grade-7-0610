Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'review',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const g = h('div', { class: 'grow center-col' });
    const card = h('div', { class: 'stagecard stagger' });
    const W = [
      ['covalent substances', 'formed by sharing electron pairs'],
      ['ionic compounds', 'formed by the transfer of electrons'],
      ['properties', 'characteristics that tell materials apart']
    ];
    const words = h('div', { class: 'revwords' }, W.map(([w, m]) => {
      const b = h('button', { class: 'revword', text: w });
      ctx.on(b, 'click', () => {
        if (!b.querySelector('.m')) b.appendChild(h('span', { class: 'm', text: m }));
        Sound.speak(w);
      });
      return b;
    }));
    const sent = h('div', { class: 'revsent' }); sent.innerHTML = 'Sentence: <em>An ionic compound can dissolve in water.</em>';
    card.append(h('div', { class: 'evid-h', text: 'Review words — tap to hear' }), words, sent,
      h('div', { class: 'btnrow' }, [ctx.speakBtn('An ionic compound can dissolve in water.', ' Sentence')]),
      h('div', { class: 'note lead', text: '📚 Prepare the next lesson.' }));
    g.appendChild(card);
    root.appendChild(g);
  }
});
