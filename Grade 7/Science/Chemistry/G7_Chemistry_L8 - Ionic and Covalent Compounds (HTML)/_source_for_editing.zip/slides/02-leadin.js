Engine.register({
  id: 'leadin', section: 'Warm-up', title: 'Lead-in: Tug-of-war or sharing?', mech: 'predict',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const sp = h('div', { class: 'split grow stagger' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/tug-of-war.png', { alt: 'Ionic bond: the electron tug-of-war between Na and Cl', class: 'hero-img' })]);
    const right = h('div', {});
    const note = h('div', { class: 'note lead', text: 'Look at the atoms. What will they do? Vote!' });
    const qs = [
      { k: 'A', text: 'Will these atoms fight and transfer an electron like a tug-of-war?', ok: true },
      { k: 'B', text: 'Will they hold hands and share?', ok: false }
    ];
    const rev = h('div', { class: 'reveal-box', text: '🤔 Choose A or B' });
    const bs = qs.map(q => {
      const b = h('button', { class: 'bubble' });
      b.append(h('span', { class: 'k', text: q.k }), document.createTextNode(q.text));
      ctx.on(b, 'click', () => {
        bs.forEach(x => { x.classList.remove('picked'); ctx.clearResult(x); });
        b.classList.add('picked');
        ctx.markResult(b, q.ok, { sound: true });
        rev.textContent = q.ok ? 'Yes! A tug-of-war: the electron moves from Na to Cl.' : 'Look again: Na⁺ is pulling the electron away from Cl⁻.';
        if (q.ok) Engine.confetti('star');
      });
      return b;
    });
    right.append(note, ...bs, rev, h('div', { class: 'note', text: 'Today: Tug-of-war (ionic) and Sharing (covalent)!' }));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
