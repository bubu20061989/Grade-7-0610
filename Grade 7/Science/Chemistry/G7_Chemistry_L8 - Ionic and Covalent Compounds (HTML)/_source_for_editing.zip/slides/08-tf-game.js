Engine.register({
  id: 'tf-game', section: 'Practice', title: 'True or False game (a–e)', mech: 'truefalse',
  render(root, ctx) {
    const Q = [
      { k: 'a', s: 'An ionic compound has a high melting point, so it is usually a solid at room temperature and pressure.', a: true,
        e: 'Most ionic compounds have <mark>high melting and high boiling points, so they are solids at room temperature and pressure</mark>.' },
      { k: 'b', s: 'An ionic compound can dissolve in water.', a: true,
        e: 'Ionic compounds … <mark>are usually soluble in water</mark> and insoluble in organic solvents.' },
      { k: 'c', s: 'Most simple molecular substances can conduct electricity.', a: false,
        e: 'Simple molecular substances … <mark>Most of them do not conduct electricity</mark> whether in solid, liquid, or gaseous states.' },
      { k: 'd', s: 'Methane has low melting and boiling points.', a: true,
        e: 'Simple molecular substances like chlorine, and/or <mark>methane have low melting and boiling points</mark>.' },
      { k: 'e', s: 'All substances with giant molecular structures have high melting points and conduct electricity.', a: false,
        e: 'Substances with giant molecular structures … have very high melting and boiling points. <mark>They do not conduct electricity (except graphite)</mark>.' }
    ];
    const ans = Q.map(() => null);
    let i = 0;
    root.appendChild(h('div', { class: 'pill fixed', text: 'True or False?' }));
    const sp = h('div', { class: 'split grow stagger' });
    const left = h('div', { class: 'media tfcard' });
    const stmt = h('div', { class: 'tfstmt' });
    const bT = h('button', { class: 'opt t', text: 'TRUE' });
    const bF = h('button', { class: 'opt f', text: 'FALSE' });
    const tf = h('div', { class: 'tfbtns' }, [bT, bF]);
    left.append(stmt, tf);
    const right = h('div', { class: 'card' });
    const evH = h('div', { class: 'evid-h', text: 'Evidence in the passage' });
    const ev = h('div', { class: 'evid' });
    const bRead = h('button', { class: 'btn', text: '📖 Passage' });
    ctx.on(bRead, 'click', () => Engine.lightbox('assets/img/passage.png', 'Reading passage'));
    right.append(evH, ev);
    sp.append(left, right);
    root.appendChild(sp);

    const dots = h('div', { class: 'dots' }, Q.map(() => h('i')));
    const bPrev = h('button', { class: 'btn', text: '◀' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next ▶' });
    root.appendChild(h('div', { class: 'stepnav fixed' }, [bPrev, bRead, dots, bNext]));

    const paint = () => {
      const q = Q[i];
      stmt.innerHTML = '';
      stmt.append(h('span', { class: 'lt', text: q.k + '. ' }), document.createTextNode(q.s));
      [bT, bF].forEach(b => { b.classList.remove('picked'); ctx.clearResult(b); });
      if (ans[i] === null) {
        ev.innerHTML = '';
        ev.append(document.createTextNode('🔍 Decide first — then find the proof in the passage.'));
        right.querySelectorAll('.evthumb').forEach(n => n.remove());
        if (innerWidth > innerHeight) right.appendChild(ctx.img('assets/img/passage.png', { alt: 'Reading passage', class: 'evthumb' }));
      } else {
        const b = ans[i] ? bT : bF;
        b.classList.add('picked');
        ctx.markResult(b, ans[i] === q.a);
        right.querySelectorAll('.evthumb').forEach(n => n.remove());
        ev.innerHTML = '<b>' + (q.a ? 'TRUE' : 'FALSE') + '.</b> ' + q.e;
      }
      Array.from(dots.children).forEach((d, k) => { d.className = k === i ? 'now' : (ans[k] !== null ? 'done' : ''); });
      bPrev.disabled = i === 0;
      bNext.textContent = i === Q.length - 1 ? 'Finish ✓' : 'Next ▶';
      ctx.timeout(() => Lab.refit && Lab.refit(), 30);
    };
    const choose = v => {
      if (ans[i] !== null) { paint(); return; }
      ans[i] = v;
      const ok = v === Q[i].a;
      Engine.score(ok ? 1 : 0, 1);
      paint();
      if (ok) Engine.confetti(i % 2 ? 'star' : 'burst');
    };
    ctx.on(bT, 'click', () => choose(true));
    ctx.on(bF, 'click', () => choose(false));
    ctx.on(bPrev, 'click', () => { if (i > 0) { i--; paint(); } });
    ctx.on(bNext, 'click', () => { if (i < Q.length - 1) { i++; paint(); } else Engine.next(); });
    paint();
  }
});
