Engine.register({
  id: 'vocab-match', section: 'Vocabulary', title: 'Match the words to the pictures', mech: 'match',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Match the words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word under the right picture.' }));
    const pics = [
      { id: 'ion', img: 'assets/img/v-ionic.png', alt: 'Magnesium chloride: electrons move from Mg to Cl' },
      { id: 'cov', img: 'assets/img/v-covalent.jpeg', alt: 'Two atoms sharing a pair of electrons' },
      { id: 'prop', img: 'assets/img/v-properties.png', alt: 'Testing whether a substance conducts electricity' }
    ];
    const items = [
      { id: 'w-ion', label: 'ionic substances' },
      { id: 'w-cov', label: 'covalent substances' },
      { id: 'w-prop', label: 'properties' }
    ];
    const zones = pics.map(p => ({ id: p.id, accept: ['w-' + p.id], capacity: 1 }));
    const dd = ctx.dragDrop({
      items, zones,
      renderZone: z => {
        const p = pics.find(x => x.id === z.id);
        return h('div', { class: 'card matcell' }, [ctx.img(p.img, { alt: p.alt, zoom: false }), h('div', { class: 'slotline', text: 'Drop here' })]);
      }
    });
    const g = h('div', { class: 'grow stagger' });
    g.append(h('div', { class: 'matchgrid' }, pics.map(p => dd.zoneEls[p.id])), dd.tray);
    root.appendChild(g);
    root.appendChild(ctx.buttons({
      check: () => { const r = dd.check(); if (r.correct === r.total) Engine.confetti('burst'); return r; },
      show: () => dd.show(), reset: () => dd.reset()
    }));
  }
});
