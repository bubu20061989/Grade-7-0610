Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Ionic and Covalent Compounds', mech: 'intro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const pic = ctx.img('assets/img/cover.png', { alt: "Let's explore English in Sciences — Grade 7", zoom: false, class: 'hero-img float-anim' });
    ctx.on(pic, 'click', () => {
      pic.classList.remove('nudge'); void pic.offsetWidth; pic.classList.add('nudge');
      Sound.speak("Let's explore English in Sciences!");
    });
    media.appendChild(pic);

    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chemistry · Lesson 8' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Ionic</em> and <em>Covalent</em> Compounds';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => { Engine.confetti('star'); ctx.timeout(() => Engine.next(), 450); });
    txt.append(t, h('div', { class: 'hero-sub', text: '👆 Tap the picture to say hello' }),
      h('div', { class: 'btnrow' }, [ctx.speakBtn('Ionic and covalent compounds', ' Listen'), go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
