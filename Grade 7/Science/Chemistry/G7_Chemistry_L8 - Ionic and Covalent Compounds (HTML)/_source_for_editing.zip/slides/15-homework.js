Engine.register({
  id: 'homework', section: 'Homework', title: 'Task 4: Sort the information', mech: 'sort',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Task 4 · p.19' }));
    root.appendChild(h('div', { class: 'note lead fixed', text: 'Find the correct information for each compound.' }));
    const items = [
      { id: 'nacl', label: 'sodium chloride (NaCl)' },
      { id: 'i1', label: 'conduct electricity in aqueous solution' },
      { id: 'i2', label: 'a solid at room temperature' },
      { id: 'i3', label: 'soluble in water' },
      { id: 'i4', label: 'high boiling point (1 465 °C)' },
      { id: 'ch4', label: 'methane (CH₄)' },
      { id: 'c1', label: 'soluble in organic solvents' },
      { id: 'c2', label: 'a gas at room temperature' },
      { id: 'c3', label: 'low boiling point (–161.5 °C)' },
      { id: 'c4', label: 'cannot conduct electricity' }
    ];
    const zones = [
      { id: 'ion', label: 'an ionic compound', accept: ['nacl', 'i1', 'i2', 'i3', 'i4'] },
      { id: 'cov', label: 'a covalent compound', accept: ['ch4', 'c1', 'c2', 'c3', 'c4'] }
    ];
    const tray = h('div', { class: 'dd-tray hw-tray fixed' });
    const dd = ctx.dragDrop({ items, zones, tray, renderZone: z => h('div', { class: 'card bin ' + z.id }, [h('div', { class: 'bin-label', text: z.label })]) });
    const g = h('div', { class: 'grow stagger' });
    g.appendChild(h('div', { class: 'hwbins' }, [dd.zoneEls.ion, dd.zoneEls.cov]));
    root.appendChild(g);
    root.appendChild(tray);
    root.appendChild(ctx.buttons({
      check: () => { const r = dd.check(); if (r.correct === r.total) Engine.confetti('star'); return r; },
      show: () => dd.show(), reset: () => dd.reset()
    }));
  }
});
