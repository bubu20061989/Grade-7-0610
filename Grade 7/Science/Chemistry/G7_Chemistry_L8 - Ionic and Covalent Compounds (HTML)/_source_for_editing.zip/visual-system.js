(function (global) {
  'use strict';
  if (global.Lab) return;
  var NS = 'http://www.w3.org/2000/svg';
  var Lab = {};
  global.Lab = Lab;

  function sv(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  Lab.sv = sv;
  function dv(cls, txt) { var d = document.createElement('div'); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  Lab.dv = dv;

  /* ===== 1. TẦNG NỀN THEO PHẦN HỌC (nằm ngoài .slide) ===== */
  /* Mỗi SECTION tự nhận 1 bảng màu theo thứ tự xuất hiện -> đổi bài không phải sửa gì.
     Chỉ định tay: Lab.PAL = { 'Tên section': ['#..','#..','#..'] }. */
  var POOL = [
    ['#5EEAD4', '#93C5FD', '#A7F3D0'],
    ['#7DD3FC', '#BAE6FD', '#5EEAD4'],
    ['#34D399', '#A3E635', '#A7F3D0'],
    ['#2DD4BF', '#34D399', '#93C5FD'],
    ['#A5B4FC', '#93C5FD', '#C7D2FE'],
    ['#FCD34D', '#A3E635', '#FDE68A']
  ];
  var palMap = null;
  function palFor(key) {
    if (!palMap) {
      palMap = {};
      var seen = [];
      Engine.slides.forEach(function (s) { var k = s.section || '-'; if (seen.indexOf(k) < 0) seen.push(k); });
      seen.forEach(function (k, i) { palMap[k] = POOL[i % POOL.length]; });
    }
    return (Lab.PAL && Lab.PAL[key]) || palMap[key] || POOL[0];
  }
  function rgba(hex, a) {
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.slice(0,2),16) + ',' + parseInt(h.slice(2,4),16) + ',' + parseInt(h.slice(4,6),16) + ',' + a + ')';
  }

  /* Khung gần trung tính, màu CHỈ ở 2 góc, giữa màn hình sạch tuyệt đối:
     không có gì nằm sau vùng chữ -> mắt không bị nhiễu. */
  function sceneD(c) {
    var sc = dv('scene');
    sc.style.background = 'linear-gradient(180deg,#FFFFFF 0%,#F7FBF9 56%,#EEF6F2 100%)';
    var tr = dv('deco');
    tr.style.right = '-16vw'; tr.style.top = '-34vh'; tr.style.width = '62vw'; tr.style.height = '62vw';
    tr.style.borderRadius = '50%'; tr.style.opacity = '1';
    tr.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[0], .26) + ' 0%,' + rgba(c[0], 0) + ' 66%)';
    sc.appendChild(tr);
    var bl = dv('deco');
    bl.style.left = '-20vw'; bl.style.bottom = '-32vh'; bl.style.width = '56vw'; bl.style.height = '56vw';
    bl.style.borderRadius = '50%'; bl.style.opacity = '1';
    bl.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[2], .22) + ' 0%,' + rgba(c[2], 0) + ' 66%)';
    sc.appendChild(bl);
    return sc;
  }

  var STYLES = { D: sceneD };
  Lab.bgStyle = 'D';
  function buildScene(key) { return (STYLES[Lab.bgStyle] || sceneD)(palFor(key)); }

  var bgHost = null, curScene = null, curKey = null;
  function applyScene() {
    if (!bgHost) {
      bgHost = document.getElementById('bgLayer');
      if (!bgHost) { bgHost = dv(''); bgHost.id = 'bgLayer'; document.body.insertBefore(bgHost, document.body.firstChild); }
    }
    var def = Engine.slides[Engine.idx];
    var key = (def && def.section) || '-';
    if (key === curKey && !Lab.__force) return;
    Lab.__force = false;
    curKey = key;
    var next = buildScene(key);
    bgHost.appendChild(next);
    void next.offsetWidth;
    next.classList.add('on');
    var old = curScene;
    curScene = next;
    if (old) setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 700);
  }

  /* ===== 2. fitStage() — lưới an toàn chống vỡ =====
     Dùng biến CSS, KHÔNG transform:scale() lên .slide: tổ tiên có transform
     sẽ phá position:fixed của #dragLayer. */
  var fitRaf = 0, fitTries = 0;
  function curSlide() { return document.querySelector('.stage > .slide'); }
  function minFit() {
    var fs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--fs-scale')) || 1;
    return Math.min(1, 0.72 / fs);
  }
  /* Sàn CHÍNH XÁC cho từng slide: đo cỡ chữ NHỎ NHẤT đang hiện ở --fit = 1, rồi cho co
     đúng tới lúc cỡ đó chạm ngưỡng đọc được từ cuối lớp (1/40 chiều cao màn hình, tối
     thiểu 22px). Bỏ qua chữ trong <svg> vì nó co theo khung hình, không theo --fit. */
  function textFloor(slide) {
    var th = Math.max(22, global.innerHeight / 40);
    var min = Infinity;
    var nodes = slide.querySelectorAll('*');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.ownerSVGElement || n.tagName.toLowerCase() === 'svg') continue;
      var hasText = false;
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3 && c.nodeValue.trim()) { hasText = true; break; }
      }
      if (!hasText) continue;
      var r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      var fsz = parseFloat(getComputedStyle(n).fontSize);
      if (fsz && fsz < min) min = fsz;
    }
    if (!isFinite(min) || !th) return 0.45;
    /* co hệ số f => chữ nhỏ nhất thành min*f; cần min*f >= th => f >= th/min */
    return Math.max(0.45, Math.min(1, (th * 1.06) / min));   // +6% biên an toàn
  }
  /* RIÊNG BÀI: tràn bên TRONG khối .grow / .split (min-height:0) không làm tăng scrollHeight của .slide,
     nên fitStage gốc không thấy — chữ đè lên khối dưới. Đo thêm các khối nội dung chính. */
  function tooTall(slide) {
    if (slide.scrollHeight > slide.clientHeight + 1) return true;
    var bs = slide.querySelectorAll('.grow, .split > *, .stagecard, .vfc .face, .bin');
    for (var i = 0; i < bs.length; i++) {
      var b = bs[i];
      if (b.clientHeight && b.scrollHeight > b.clientHeight + 2) return true;
    }
    return false;
  }
  function fitNow() {
    fitRaf = 0;
    var slide = curSlide();
    if (!slide) return;
    var lo = slide.__floor != null ? slide.__floor : minFit();
    var cur = parseFloat(slide.style.getPropertyValue('--fit'));
    if (!(cur > 0)) cur = 1;
    var guard = 0;
    /* Vòng lặp ĐỒNG BỘ: đọc scrollHeight ép trình duyệt tính lại layout ngay, nên slide
       vừa vào là đã vừa khung — không nhấp nháy 1-2 khung hình. */
    while (tooTall(slide) && cur > lo + 0.001 && guard++ < 16) {
      cur = Math.max(lo, cur - 0.05);
      slide.style.setProperty('--fit', cur.toFixed(3));
    }
    fitTries = guard;
  }
  function scheduleFit() {
    if (fitRaf) return;
    fitRaf = global.requestAnimationFrame ? requestAnimationFrame(fitNow) : setTimeout(fitNow, 16);
  }
  function resetFit() {
    var slide = curSlide();
    if (slide) {
      slide.style.setProperty('--fit', '1');
      slide.__floor = textFloor(slide);
    }
    fitTries = 0;
    fitNow();
    scheduleFit();
  }
  Lab.setBgStyle = function (k) { Lab.bgStyle = k; Lab.__force = true; applyScene(); };
  Lab.fit = scheduleFit;
  Lab.refit = resetFit;

  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };

  /* ===== 3. NÚT LỚP HỌC: Tập trung / Giảm chuyển động ===== */
  function addNavButtons() {
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#focusBtn')) return;
    var anchor = nav.querySelector('#fullscreenBtn') || nav.querySelector('#tlockBtn');
    var mk = function (id, icon, title, cls) {
      var b = document.createElement('button');
      b.className = 'iconbtn'; b.id = id; b.textContent = icon; b.title = title;
      b.addEventListener('click', function () {
        var on = document.body.classList.toggle(cls);
        b.classList.toggle('on', on);
        try { sessionStorage.setItem('pref:' + cls, on ? '1' : '0'); } catch (e) { }
        Engine.toast(title + (on ? ' — ON' : ' — OFF'));
        resetFit();
      });
      try { if (sessionStorage.getItem('pref:' + cls) === '1') { document.body.classList.add(cls); b.classList.add('on'); } } catch (e) { }
      if (anchor) nav.insertBefore(b, anchor); else nav.appendChild(b);
      return b;
    };
    mk('focusBtn', '🎯', 'Focus mode', 'focus');
    mk('motionBtn', '🌀', 'Reduce motion', 'nomotion');
  }

  /* ===== 4. NỐI VÀO ENGINE ===== */
  var origGo = Engine.go;
  Engine.go = function (i, dir) {
    origGo.call(Engine, i, dir);
    applyScene();
    resetFit();
    setTimeout(scheduleFit, 140);
    setTimeout(scheduleFit, 620);
  };
  var origFs = Engine._applyFontScale;
  Engine._applyFontScale = function (v) { origFs.call(Engine, v); resetFit(); };

  var origStart = Engine.start;
  Engine.start = function (cfg) {
    origStart.call(Engine, cfg);
    applyScene();
    addNavButtons();
    resetFit();
    var stage = document.querySelector('.stage');
    if (stage) {
      if (global.ResizeObserver) new ResizeObserver(resetFit).observe(stage);
      else global.addEventListener('resize', resetFit);
      new MutationObserver(scheduleFit).observe(stage, { childList: true, subtree: true, characterData: true });
      stage.addEventListener('load', scheduleFit, true);   // ảnh tải xong -> đo lại
    }
    global.addEventListener('resize', resetFit);
    document.addEventListener('fullscreenchange', resetFit);
  };

  /* ===== 5. LỚP THẨM MỸ: icon SVG, thanh công cụ gọn, nhãn phần =====
     Chạy SAU engine dựng navbar, không sửa engine.js. Tắt từng phần nếu cần:
     Lab.tidyNav = false · Lab.svgIcons = false · Lab.autoEyebrow = false (đặt trong slide đầu). */
  var IC = {
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2.1 1.2M17.7 15.3l2.1 1.2M4.2 16.5l2.1-1.2M17.7 8.7l2.1-1.2"/><circle cx="12" cy="12" r="7"/>',
    check: '<path d="M4.5 12.5l4.8 4.8L19.5 7"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/>',
    sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 2.5h5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    star: '<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12"/>'
  };
  /* Icon vẽ bằng CSS mask (thẻ <i>), KHÔNG chèn <svg> vào DOM: qa.py mục 5 coi mọi <svg> là
     widget và báo "QUÁ NHỎ" oan cho icon trong nút. Màu icon = currentColor của nút. */
  Lab.icon = function (name) {
    var i = document.createElement('i');
    i.className = 'ic'; i.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (IC[name] || '') + '</svg>';
    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    i.style.webkitMaskImage = url; i.style.maskImage = url;
    return i;
  };
  function setIcon(btn, name) { if (!btn) return; btn.textContent = ''; btn.appendChild(Lab.icon(name)); }

  /* Emoji đầu nhãn nút -> icon SVG cùng nghĩa. Emoji không có trong bảng thì để nguyên. */
  var LEAD = [
    [/^\s*(✅|✔️?)\s*/, 'check'], [/^\s*👁️?\s*/, 'eye'], [/^\s*(↺|🔄)\s*/, 'reset'],
    [/^\s*(🔊|🔈)\s*/, 'sound'], [/^\s*(⏱️?)\s*/, 'timer'], [/^\s*(▶️?)\s*/, 'play'], [/^\s*(↩️?)\s*/, 'undo']
  ];
  function iconizeButtons(scope) {
    if (Lab.svgIcons === false || !scope) return;
    scope.querySelectorAll('.btn').forEach(function (b) {
      if (b.querySelector('.ic') || b.children.length) return;
      var t = b.textContent;
      for (var i = 0; i < LEAD.length; i++) {
        if (LEAD[i][0].test(t)) { b.textContent = t.replace(LEAD[i][0], ''); b.insertBefore(Lab.icon(LEAD[i][1]), b.firstChild); return; }
      }
    });
  }
  Lab.iconize = iconizeButtons;

  function tidyNav() {
    if (Lab.tidyNav === false) return;
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#tdrawerBtn')) return;
    var byTitle = function (p) { var r = null; nav.querySelectorAll('.iconbtn').forEach(function (b) { if (!r && (b.title || '').indexOf(p) === 0) r = b; }); return r; };
    var prev = byTitle('Previous'), next = byTitle('Next'), full = nav.querySelector('#fullscreenBtn');
    var drawer = dv(''); drawer.id = 'tdrawer';
    var row = function (label, els) {
      els = els.filter(Boolean); if (!els.length) return;
      var r = dv('row'); r.appendChild(dv('lbl', label)); els.forEach(function (e) { r.appendChild(e); }); drawer.appendChild(r);
    };
    row('Text size', [nav.querySelector('.fs-group')]);
    row('Sound', [byTitle('Mute'), nav.querySelector('#voiceBtn')]);
    row('Teams', [nav.querySelector('.teams')]);
    row('Class tools', [byTitle('Timer'), byTitle('Spotlight'), byTitle('Slides')]);
    row('Display', [nav.querySelector('#focusBtn'), nav.querySelector('#motionBtn')]);
    row('Lock', [nav.querySelector('#tlockBtn')]);
    document.body.appendChild(drawer);

    var tb = document.createElement('button');
    tb.id = 'tdrawerBtn'; tb.className = 'iconbtn tbtn'; tb.title = 'Teacher tools';
    tb.appendChild(Lab.icon('gear')); tb.appendChild(document.createTextNode('Teacher'));
    tb.addEventListener('click', function (e) { e.stopPropagation(); drawer.classList.toggle('on'); });
    document.addEventListener('pointerdown', function (e) {
      if (drawer.classList.contains('on') && !drawer.contains(e.target) && !tb.contains(e.target)) drawer.classList.remove('on');
    });
    var anchor = full || prev;
    if (anchor) nav.insertBefore(tb, anchor); else nav.appendChild(tb);

    if (Lab.svgIcons !== false) {
      if (prev) { setIcon(prev, 'prev'); prev.classList.add('nav-arrow'); }
      if (next) { setIcon(next, 'next'); next.classList.add('nav-arrow'); }
      if (full) {
        var sync = function () { setIcon(full, document.fullscreenElement ? 'shrink' : 'expand'); };
        sync(); document.addEventListener('fullscreenchange', function () { setTimeout(sync, 0); });
      }
    }
  }

  /* Nhãn phần (section) nhỏ phía trên tiêu đề — người xem luôn biết đang ở phần nào của bài */
  function addEyebrow() {
    if (Lab.autoEyebrow === false) return;
    var slide = curSlide(); var def = Engine.slides[Engine.idx];
    if (!slide || !def || !def.section || slide.querySelector('.eyebrow, .cover')) return;
    var pill = slide.querySelector(':scope > .pill');
    if (!pill || pill.textContent.toLowerCase().indexOf(def.section.toLowerCase()) >= 0) return;
    var eb = dv('eyebrow fixed', def.section);
    slide.insertBefore(eb, pill);
    /* Nhãn phần là trang trí: slide chật (font 150%, màn dọc) thì bỏ nhãn TRƯỚC khi fitStage phải co chữ */
    var f0 = slide.style.getPropertyValue('--fit');
    slide.style.setProperty('--fit', '1');
    var tight = tooTall(slide);
    if (f0) slide.style.setProperty('--fit', f0);
    if (tight || global.innerHeight < 560) eb.remove();
    resetFit();
  }

  var goAes = Engine.go;
  Engine.go = function (i, dir) {
    goAes.call(Engine, i, dir);
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
  };
  var startAes = Engine.start;
  Engine.start = function (cfg) {
    startAes.call(Engine, cfg);
    tidyNav();
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
    var st = document.querySelector('.stage');
    if (st) new MutationObserver(function () { iconizeButtons(st); }).observe(st, { childList: true, subtree: true });
  };

  /* ===================== 6. RIÊNG BÀI G7 · CHEMISTRY L8 ===================== */
  /* Nền: GIỮ hình minh hoạ gốc của PPT (nguyên tử, hạt nhân, chấm tròn pastel trên nền be).
     Chỉ đặt ở 4 góc, tràn một phần ra ngoài mép -> 1/3 giữa màn hình luôn sạch.
     Phần "Detective Game" dùng nền giấy nhăn gốc của trò chơi thám tử. */
  var IMG = 'assets/img/';
  var LAYOUTS = [
    [ ['deco-atom-teal', 'left:-4vh;top:calc(var(--navbar-h) + 1vh);height:24vh;width:22vh;opacity:.75', 'drift'],
      ['deco-bohr', 'right:-7vh;bottom:-8vh;height:32vh;width:32vh;opacity:.7', ''],
      ['deco-flower', 'left:-6vh;bottom:-7vh;height:26vh;width:26vh;opacity:.55', ''],
      ['#F2C4B0', 'right:3vw;top:calc(var(--navbar-h) + 2vh);width:6vh;height:6vh;opacity:.7', 'dot'],
      ['#C9E4D9', 'left:9vw;bottom:3vh;width:5vh;height:5vh;opacity:.8', 'dot'] ],
    [ ['deco-atom-pink', 'right:-4vh;top:calc(var(--navbar-h) + 1vh);height:24vh;width:22vh;opacity:.7', 'drift2'],
      ['deco-nucleus', 'left:-7vh;bottom:-7vh;height:24vh;width:24vh;opacity:.6', ''],
      ['deco-atom-yellow', 'right:-3vh;bottom:-6vh;height:22vh;width:20vh;opacity:.65', ''],
      ['#F9E3B4', 'left:2.5vw;top:calc(var(--navbar-h) + 3vh);width:7vh;height:7vh;opacity:.8', 'dot'],
      ['#1E9C8C', 'right:8vw;bottom:2.5vh;width:3.5vh;height:3.5vh;opacity:.45', 'dot'] ],
    [ ['deco-bohr', 'left:-8vh;top:calc(var(--navbar-h) - 2vh);height:28vh;width:28vh;opacity:.6', ''],
      ['deco-atom-teal', 'right:-4vh;bottom:-5vh;height:26vh;width:24vh;opacity:.7', 'drift'],
      ['deco-flower', 'right:-8vh;top:calc(var(--navbar-h) + 2vh);height:22vh;width:22vh;opacity:.45', ''],
      ['#F2C4B0', 'left:3vw;bottom:4vh;width:6vh;height:6vh;opacity:.7', 'dot'] ]
  ];
  var secIdx = null;
  function sceneAtoms() {
    var key = curKey || '-';
    if (key === 'Detective Game') { return dv('scene paper'); }
    if (!secIdx) { secIdx = {}; var n = 0; Engine.slides.forEach(function (s) { var k = s.section || '-'; if (secIdx[k] == null) secIdx[k] = n++; }); }
    var sc = dv('scene atoms');
    (LAYOUTS[(secIdx[key] || 0) % LAYOUTS.length]).forEach(function (d) {
      var e = dv('deco ' + (d[2] === 'dot' ? 'dot' : 'pic' + (d[2] ? ' ' + d[2] : '')));
      e.style.cssText += d[1];
      if (d[2] === 'dot') e.style.background = d[0];
      else e.style.backgroundImage = 'url("' + IMG + d[0] + '.png")';
      sc.appendChild(e);
    });
    return sc;
  }
  STYLES.atoms = sceneAtoms;
  Lab.bgStyle = 'atoms';

  /* Nút phát track audio gốc trong PPT (<audio> gắn vào body; Sound.stopAll() vẫn dừng được, ctx dọn khi rời slide) */
  Lab.player = function (ctx, src, label) {
    var wrap = document.createElement('span'); wrap.className = 'player';
    var a = document.createElement('audio'); a.src = src; a.preload = 'auto'; a.style.display = 'none';
    var b = document.createElement('button'); b.className = 'btn btn-primary'; b.textContent = '▶ ' + label;
    var bar = document.createElement('span'); bar.className = 'bar';
    var fill = document.createElement('i'); bar.appendChild(fill);
    function setLbl(playing) { b.textContent = (playing ? '❚❚ ' : '▶ ') + label; }
    ctx.on(b, 'click', function () {
      if (!a.paused) { a.pause(); return; }
      if (Sound.muted()) { Engine.toast('Sound is muted'); return; }
      Sound.stopAll();
      try { if (a.ended) a.currentTime = 0; } catch (e) { }
      var p = a.play(); if (p && p.catch) p.catch(function () { Engine.toast('Tap again to play'); });
    });
    ctx.on(a, 'play', function () { setLbl(true); });
    ctx.on(a, 'pause', function () { setLbl(false); });
    ctx.on(a, 'ended', function () { setLbl(false); fill.style.transform = 'scaleX(1)'; });
    ctx.on(a, 'timeupdate', function () { if (a.duration) fill.style.transform = 'scaleX(' + (a.currentTime / a.duration).toFixed(3) + ')'; });
    ctx.on(a, 'error', function () { b.disabled = true; b.textContent = 'Audio unavailable'; });
    document.body.appendChild(a);
    ctx._off.push(function () { try { a.pause(); } catch (e) { } a.remove(); });
    wrap.append(b, bar);
    return wrap;
  };

  /* Nhóm nút chọn 1 trong n (Ionic/Covalent, True/False). opts: [{label, cls}] -> el có __val/__check/__show/__reset */
  Lab.pick = function (ctx, opts, answer, cls) {
    var w = document.createElement('div'); w.className = cls || 'bondpick';
    w.__val = -1;
    var bs = opts.map(function (o, i) {
      var b = document.createElement('button'); b.className = 'opt ' + (o.cls || ''); b.textContent = o.label;
      ctx.on(b, 'click', function () {
        Sound.playEffect('click'); ctx.clearResult(w); w.__val = i;
        bs.forEach(function (x, j) { x.classList.toggle('picked', j === i); });
        if (w.__onpick) w.__onpick(i);
      });
      w.appendChild(b); return b;
    });
    w.__check = function () { var ok = w.__val === answer; ctx.markResult(w, ok); return ok; };
    w.__show = function () { ctx.clearResult(w); w.__val = answer; bs.forEach(function (x, j) { x.classList.toggle('picked', j === answer); }); };
    w.__reset = function () { ctx.clearResult(w); w.__val = -1; bs.forEach(function (x) { x.classList.remove('picked'); }); };
    return w;
  };
  Lab.group = function (list) {
    return {
      check: function () { var c = 0; list.forEach(function (w) { if (w.__check()) c++; }); return { correct: c, total: list.length }; },
      show: function () { list.forEach(function (w) { w.__show(); }); },
      reset: function () { list.forEach(function (w) { w.__reset(); }); }
    };
  };
  /* Task 3 tách 2 slide (Diamond / Graphite): cả đoạn văn gốc không vừa 1 màn ở cỡ chữ đọc được từ cuối lớp.
     Khay vẫn đủ 8 từ như sách -> chấm theo Ô ĐÍCH (từ của nửa kia là thẻ nhiễu). */
  Lab.cloze = function (root, ctx, o) {
  root.appendChild(h('div', { class: 'pill fixed', text: o.title }));
  root.appendChild(h('div', { class: 'btnrow fixed' }, [h('div', { class: 'note lead', text: 'Listen and fill in the blanks.' }), Lab.player(ctx, 'assets/audio/media3.mp3', 'Track 8')]));
  const W = ['jewellery', 'cutting', 'hardness', 'four', 'soft', 'conductor', 'lead', 'three'];
  const items = W.map((w, k) => ({ id: 'w' + (k + 1), label: w }));
  const zones = o.nums.map(k => ({ id: 'z' + k, accept: ['w' + k], capacity: 1 }));
  const tray = h('div', { class: 'dd-tray cloze-tray fixed' });
  const dd = ctx.dragDrop({ items, zones, tray, renderZone: z => h('span', { class: 'slot', 'data-n': '(' + z.id.slice(1) + ')' }) });
  const p = h('div', { class: 'ptext ' + o.cls });
  if (o.intro) p.appendChild(h('span', { class: 'pintro', text: o.intro }));
  p.appendChild(h('span', { class: 'ph', text: o.head }));
  o.parts.forEach(x => p.append(typeof x === 'number' ? dd.zoneEls['z' + x] : document.createTextNode(x)));
  const sp = h('div', { class: 'split clozesplit grow stagger' });
  sp.append(h('div', { class: 'media' }, [ctx.img('assets/img/cloze-page.png', { alt: 'Task 3 book page: diamond and graphite', class: 'hero-img' }), ctx.zoomHint()]), h('div', {}, [p]));
  root.appendChild(sp);
  root.appendChild(tray);
  const check = () => {
    let c = 0;
    tray.querySelectorAll('.drag-item').forEach(n => ctx.clearResult(n));
    zones.forEach(z => {
      const zn = dd.zoneEls[z.id];
      ctx.clearResult(zn);
      const it = zn.querySelector('.drag-item');
      if (!it) { ctx.markResult(zn, false, { badge: false }); return; }
      const ok = z.accept.indexOf(it.dataset.ddId) >= 0;
      if (ok) c++;
      ctx.markResult(it, ok);
    });
    if (c === zones.length) Engine.confetti('burst');
    return { correct: c, total: zones.length };
  };
  const clearZones = () => zones.forEach(z => ctx.clearResult(dd.zoneEls[z.id]));
  root.appendChild(ctx.buttons({
    check,
    show: () => { clearZones(); dd.reset(); dd.show(); },
    reset: () => { clearZones(); dd.reset(); }
  }));
};
})(window);
