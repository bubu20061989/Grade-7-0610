Engine.register({
  id: 'read-c', section: 'Practice', title: 'Reading c: count the atoms', mech: 'count', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 2 · Question c' }));
    const sp = h('div', { class: 'split stagger' });
    /* phân tử nước H2O (O đỏ, H xanh lá như ảnh bài 1) — chạm từng nguyên tử để đếm */
    const NS = 'http://www.w3.org/2000/svg';
    const svg = Lab.sv('svg', { viewBox: '0 0 600 430', role: 'img', 'aria-label': 'A water molecule: one oxygen atom and two hydrogen atoms' });
    svg.appendChild(Lab.sv('line', { x1: 300, y1: 150, x2: 140, y2: 310, stroke: '#9CA3AF', 'stroke-width': 22, 'stroke-linecap': 'round' }));
    svg.appendChild(Lab.sv('line', { x1: 300, y1: 150, x2: 460, y2: 310, stroke: '#9CA3AF', 'stroke-width': 22, 'stroke-linecap': 'round' }));
    const A = [{ x: 300, y: 150, r: 108, s: 'O', c: 'var(--atom-o)' }, { x: 140, y: 310, r: 78, s: 'H', c: 'var(--atom-h)' }, { x: 460, y: 310, r: 78, s: 'H', c: 'var(--atom-h)' }];
    let n = 0;
    const counter = h('div', { class: 'counter', text: '👆 Tap each atom to count' });
    const atoms = A.map(a => {
      const g = Lab.sv('g', { class: 'atom' });
      g.appendChild(Lab.sv('circle', { class: 'ball', cx: a.x, cy: a.y, r: a.r, fill: a.c }));
      g.appendChild(Lab.sv('circle', { cx: a.x - a.r * .35, cy: a.y - a.r * .4, r: a.r * .22, fill: '#fff', opacity: .35 }));
      const t = Lab.sv('text', { x: a.x, y: a.y + a.r * .3, 'text-anchor': 'middle', 'font-size': a.r * .95 }); t.textContent = a.s;
      const tag = Lab.sv('text', { class: 'tag', x: a.x, y: a.y - a.r - 12, 'text-anchor': 'middle', 'font-size': 52 }); tag.textContent = '';
      g.append(t, tag);
      ctx.on(g, 'click', () => {
        if (g.classList.contains('counted')) return;
        g.classList.add('counted'); n++;
        tag.textContent = String(n);
        Sound.speak(String(n));
        counter.textContent = n === 3 ? '1 oxygen + 2 hydrogen = 3 atoms' : n + ' …';
      });
      svg.appendChild(g);
      return { g, tag };
    });
    sp.appendChild(h('div', { class: 'media' }, [h('div', { class: 'molsvg' }, [svg]), counter]));
    const q = Lab.mcq(ctx, ['A. 3.', 'B. 2.', 'C. 1.'], 0);
    sp.appendChild(h('div', {}, [h('div', { class: 'qtitle', text: 'c. How many atoms are there in a water molecule?' }), q.el]));
    root.appendChild(sp);
    const reset = () => { q.reset(); n = 0; atoms.forEach(a => { a.g.classList.remove('counted'); a.tag.textContent = ''; }); counter.textContent = '👆 Tap each atom to count'; };
    root.appendChild(Lab.showReset(ctx, { show: q.show, reset }, [Lab.backBtn(ctx, 'reading', 'Text')]));
  }
});
