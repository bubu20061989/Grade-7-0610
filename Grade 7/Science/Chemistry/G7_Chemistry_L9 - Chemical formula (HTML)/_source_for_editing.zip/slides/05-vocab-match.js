Engine.register({
  id: 'vocab-match', section: 'New words', title: 'New words: match the meaning', mech: 'match', bg: 'blue',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'New words: match the meaning' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each Vietnamese meaning to the right word · tap a word to hear it' }));
    const R = [
      { id: 'cf', w: 'chemical formula', ipa: "/ˈkemɪkl ˈfɔːmjələ/", vi: 'Công thức hoá học' },
      { id: 'sub', w: 'subscript', ipa: '/ˈsʌb.skrɪpt/', vi: 'Chỉ số dưới' },
      { id: 'val', w: 'valency', ipa: '/ˈveɪlənsi/', vi: 'Hoá trị' }
    ];
    this._zones = R.map(r => ({ id: 'z-' + r.id, accept: [r.id], capacity: 1 }));
    const dd = ctx.dragDrop({
      items: R.map(r => ({ id: r.id, label: r.vi })),
      zones: this._zones,
      renderZone: () => h('div', { class: 'card' })
    });
    const grow = h('div', { class: 'grow center-col stagger' });
    const tb = h('div', { class: 'vtable' }, [h('div', { class: 'th', text: 'New words' }), h('div', { class: 'th', text: 'Pronunciation' }), h('div', { class: 'th', text: 'Meaning' })]);
    R.forEach((r, k) => {
      const w = h('button', { class: 'w', html: (k + 1) + '. ' + r.w + ' <small>(n)</small>' });
      ctx.on(w, 'click', () => Sound.speak(r.w));
      tb.append(w, h('div', { class: 'ipa', text: r.ipa }), dd.zoneEls['z-' + r.id]);
    });
    grow.appendChild(h('div', { class: 'fill-w' }, [tb]));
    root.appendChild(grow);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
