Engine.register({
  id: 'summary', section: 'Consolidation', title: 'What we learned', mech: 'checklist', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap each line you can do ✓' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'stagecard' });
    const list = h('div', { class: 'checklist' });
    const say = (w) => (e) => { e.stopPropagation(); Sound.speak(w); };
    const items = [
      () => { const s = h('span', {}); s.append('Vocabulary: '); ['valency', 'chemical formula'].forEach((w, i) => { const a = h('span', { class: 'lnk', text: w }); ctx.on(a, 'click', say(w)); s.append(a, i ? '.' : ', '); }); return s; },
      () => h('span', { text: 'Explain the relationship between valency and chemical formula.' }),
      () => h('span', { text: 'Write chemical formulas given the valencies of the constituent elements.' }),
      () => h('span', { text: 'Prepare the next lesson.' })
    ];
    items.forEach(mk => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '✓' }), mk()]);
      ctx.on(b, 'click', () => { b.classList.toggle('on'); Sound.playEffect('click'); if (list.querySelectorAll('.on').length === items.length) Engine.confetti('star'); });
      list.appendChild(b);
    });
    card.appendChild(list);
    grow.appendChild(card);
    root.appendChild(grow);
  }
});
