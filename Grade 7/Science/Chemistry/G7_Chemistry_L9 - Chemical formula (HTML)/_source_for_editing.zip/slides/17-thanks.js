Engine.register({
  id: 'thanks', section: 'Consolidation', title: 'Thank you!', mech: 'outro', bg: 'cover',
  render(root, ctx) {
    const c = h('div', { class: 'ccover stagger' });
    const stars = Engine.stars || 0;
    const done = Object.keys(Engine.done || {}).length;
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Thank <em>you!</em>';
    c.append(t, h('div', { class: 'quote', text: '“Life is interconnected; protect one, sustain all.”' }));
    c.appendChild(h('div', { class: 'stagecard starbig' }, [
      h('div', { class: 'num float-anim', text: '⭐ ' + stars }),
      h('div', { class: 'lbl', text: stars ? 'stars today — well done!' : (done > 2 ? 'Keep practising — you can do it!' : 'Ready to try the activities?') })
    ]));
    const wrong = (Engine.wrongList() || []).filter(id => Engine.slides.some(s => s.id === id));
    if (wrong.length) {
      c.appendChild(h('div', { class: 'hero-sub', text: "Let's review:" }));
      const row = h('div', { class: 'btnrow' });
      wrong.slice(0, 3).forEach(id => { const s = Engine.slides.find(x => x.id === id); const b = h('button', { class: 'btn', text: s.title }); ctx.on(b, 'click', () => Lab.goTo(id)); row.appendChild(b); });
      c.appendChild(row);
    }
    const again = h('button', { class: 'btn btn-primary', text: '↺ Start again' });
    ctx.on(again, 'click', () => Engine.go(0, 'jump'));
    c.appendChild(h('div', { class: 'btnrow' }, [again]));
    root.appendChild(c);
    if (stars) ctx.timeout(() => Engine.confetti('star'), 500);
  }
});
