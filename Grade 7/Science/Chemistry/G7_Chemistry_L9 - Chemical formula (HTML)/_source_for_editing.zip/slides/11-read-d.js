Engine.register({
  id: 'read-d', section: 'Practice', title: 'Reading d: the word “particular”', mech: 'mcq', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 2 · Question d' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    grow.appendChild(h('div', { class: 'qtitle', text: 'd. The word “particular” in line 6 is closest in meaning to' }));
    grow.appendChild(h('div', { class: 'quoteline', html: '“…a chemical formula tells scientists what elements they need to make a <b>particular</b> substance.”' }));
    const q = Lab.mcq(ctx, ['A. normal.', 'B. unusual.', 'C. specific.'], 2);
    grow.appendChild(q.el);
    root.appendChild(grow);
    root.appendChild(Lab.showReset(ctx, q, [Lab.backBtn(ctx, 'reading', 'Text')]));
  }
});
