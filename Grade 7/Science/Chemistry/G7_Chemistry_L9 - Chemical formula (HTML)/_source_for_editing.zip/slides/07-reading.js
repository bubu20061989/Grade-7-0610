Engine.register({
  id: 'reading', section: 'Practice', title: 'Exercise 2: Reading', mech: 'read', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 2 (P.20): Reading' }));
    const S = [
      'A chemical formula is like a secret code for chemists.',
      '<b>It</b> uses letters and numbers to tell us what elements are in a substance and how many atoms of each element there are.',
      'For example, the formula of water is H₂O.',
      'This means there are two hydrogen atoms and one oxygen atom in every water molecule.',
      'Just like a recipe tells you what ingredients you need to make a dish, a chemical formula tells scientists what elements they need to make a <b>particular</b> substance.'
    ];
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,2fr) minmax(0,1fr)' });
    const pas = h('div', { class: 'passage' });
    const sens = S.map(s => {
      const e = h('span', { class: 'sen', html: s });
      ctx.on(e, 'click', () => {
        sens.forEach(x => x.classList.remove('on')); e.classList.add('on');
        Sound.speak(e.textContent.replace('H₂O', 'H two O')).then(() => e.classList.remove('on'));
      });
      pas.append(e, ' ');
      return e;
    });
    sp.appendChild(h('div', {}, [pas, h('div', { class: 'note', text: 'Tap a sentence to listen' })]));
    const Q = [
      ['a', 'The word “it”', 'read-a'], ['b', 'Information not given', 'read-b'],
      ['c', 'Atoms in a water molecule', 'read-c'], ['d', 'The word “particular”', 'read-d']
    ];
    const hub = h('div', { class: 'hub' });
    Q.forEach(([k, q, id]) => {
      const b = h('button', { class: 'hubbtn' + (Engine.done && Engine.done[id] ? ' done' : '') }, [h('span', { class: 'k', text: Engine.done && Engine.done[id] ? '✓' : k }), h('span', { text: q })]);
      ctx.on(b, 'click', () => Lab.goTo(id));
      hub.appendChild(b);
    });
    sp.appendChild(h('div', {}, [h('div', { class: 'plabel', html: '<b>Read and answer</b> — tap a question' }), hub]));
    root.appendChild(sp);
    const all = h('button', { class: 'btn btn-primary', text: '🔊 Read aloud' });
    ctx.on(all, 'click', () => {
      all.disabled = true;
      let k = 0;
      const next = () => {
        sens.forEach(x => x.classList.remove('on'));
        if (k >= sens.length || !document.body.contains(all)) { all.disabled = false; return; }
        const e = sens[k++]; e.classList.add('on');
        Sound.speak(e.textContent.replace('H₂O', 'H two O')).then(next);
      };
      next();
    });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [all]));
  }
});
