Engine.register({
  id: 'vocab', section: 'New words', title: 'New words: flashcards', mech: 'flashcard', bg: 'blue',
  render(root, ctx) {
    const W = [
      { w: 'chemical formula', ipa: "/ˈkemɪkl ˈfɔːmjələ/", c: 'c-yel', vi: 'Công thức hoá học',
        def: 'A short combination of letters and numbers showing the types and number of atoms in a molecule.', ex: '(e.g., ' + Lab.chem('H2O') + ', ' + Lab.chem('CO2') + ')',
        pic: () => h('div', { class: 'formcard', html: '<div class="big">CO<sub>2</sub></div><div class="cap">Carbon dioxide</div>' }) },
      { w: 'subscript', ipa: '/ˈsʌb.skrɪpt/', c: 'c-blu', vi: 'Chỉ số dưới',
        def: 'A character, number, or symbol written slightly below and smaller than the normal line of text.', ex: '(e.g., the 2 in ' + Lab.chem('CO2') + ')',
        pic: () => h('div', { class: 'formcard', html: '<div class="big">CO<sub class="hl2">2</sub></div><div class="cap">Carbon dioxide</div>' }) },
      { w: 'valency', ipa: '/ˈveɪlənsi/', c: 'c-pnk', vi: 'Hoá trị',
        def: 'A property of an element that tells us how many other atoms it can combine with to form a compound.', ex: '',
        pic: () => ctx.img('assets/img/image11.png', { alt: 'Valency: a sulfur atom and the structure of H2SO4', zoom: false }) }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'New words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    const dots = h('div', { class: 'dots fixed' });
    grow.append(h('div', { class: 'fc-wrap' }, [box]));
    root.appendChild(grow);
    root.appendChild(dots);
    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.append(h('div', { class: 'vimg' }, [v.pic()]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: '(noun)' }), h('div', { class: 'vipa', text: v.ipa })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', html: v.def + (v.ex ? ' ' + v.ex : '') }), h('div', { class: 'vex', html: '🇻🇳 <b>' + v.vi + '</b>' }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; Engine.toast('🎉 All 3 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
