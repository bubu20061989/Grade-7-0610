Engine.register({
  id: 'produce', section: 'Production', title: "Let's produce: talk in pairs", mech: 'spin', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: "Let's produce" }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1fr) minmax(0,1.3fr)' });
    const v = h('video', { src: 'assets/video/media4.mp4', autoplay: '', muted: '', loop: '', playsinline: '', poster: 'assets/img/image29.png' });
    v.muted = true;
    sp.appendChild(h('div', { class: 'media' }, [h('div', { class: 'mediabox' }, [v])]));
    const C = [['Salt', 'Na (I) · Cl (I)'], ['Phosphine', 'P (III) · H (I)'], ['Quicklime', 'Ca (II) · O (II)'], ['Silica', 'Si (IV) · O (II)'], ['Aluminium carbide', 'Al (III) · C (IV)']];
    const pick = h('div', { class: 'pickbox', text: '🎲' });
    let left = [];
    const b = h('button', { class: 'btn btn-primary', text: '🎲 Pick a compound' });
    ctx.on(b, 'click', () => {
      if (!left.length) left = ctx.shuffle(C);
      const c = left.pop();
      Sound.playEffect('click');
      pick.innerHTML = '';
      pick.append(h('div', { class: 'pop-in', text: c[0] }), h('div', { class: 'els', text: c[1] }));
      Sound.speak(c[0]);
    });
    const ol = h('ol', { class: 'olist' });
    ['What elements are there in the compound?', 'What is the valency of each element in the compound?',
      'How can we make the total of the valencies of two elements equal?', 'What is the chemical formula of the compound?']
      .forEach(t => ol.appendChild(h('li', { text: t })));
    const t = h('button', { class: 'btn', text: '⏱ 2 min' });
    ctx.on(t, 'click', () => Engine.timer(120));
    sp.appendChild(h('div', { class: 'pcard' }, [h('div', { class: 'plabel', html: '<b>Work in pairs:</b> pick a compound, then ask and answer' }), pick, ol, h('div', { class: 'btnrow' }, [b, t])]));
    root.appendChild(sp);
  }
});
