Engine.register({
  id: 'ex1', section: 'Practice', title: 'Exercise 1: Label the pictures', mech: 'label', bg: 'cloud',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 1 (P.20)' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Label the pictures with suitable words from the box.' }));
    const words = [
      { id: 'val', label: 'Valency' }, { id: 'sym', label: 'Symbol' },
      { id: 'cf', label: 'Chemical formula' }, { id: 'sub', label: 'Subscript' }
    ];
    const rows = [
      { k: 'a.', id: 'za', ans: 'val', after: 'of oxygen is II' },
      { k: 'b.', id: 'zb', ans: 'sym', after: 'of hydrogen' },
      { k: 'c.', id: 'zc', ans: 'cf', after: 'of water' },
      { k: 'd.', id: 'zd', ans: 'sub', after: '← the 2 in H₂O' }
    ];
    const dd = ctx.dragDrop({
      items: words,
      zones: rows.map(r => ({ id: r.id, accept: [r.ans], capacity: 1 })),
      renderZone: () => h('div', { class: 'card' })
    });
    const row = h('div', { class: 'rowwrap stagger' });
    const left = h('div', { class: 'colhalf', style: 'flex:1.15 1 0' }, [
      ctx.img('assets/img/image21.png', { alt: 'Worksheet: a water molecule (O and two H atoms) and the formula H2O with four blanks a–d', class: 'hero-img' }),
      ctx.zoomHint()
    ]);
    const list = h('div', { class: 'lablist' });
    rows.forEach(r => list.append(h('span', { class: 'lt', text: r.k }), dd.zoneEls[r.id], h('span', { class: 't', text: r.after })));
    const right = h('div', { class: 'colhalf' }, [list]);
    row.append(left, right);
    root.appendChild(row);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
