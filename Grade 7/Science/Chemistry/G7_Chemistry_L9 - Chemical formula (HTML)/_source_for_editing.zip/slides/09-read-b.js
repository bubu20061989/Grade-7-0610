Engine.register({
  id: 'read-b', section: 'Practice', title: 'Reading b: what a formula does not tell us', mech: 'mcq', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 2 · Question b' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    grow.appendChild(h('div', { class: 'qtitle', text: 'b. What information does a chemical formula not give us?' }));
    
    const q = Lab.mcq(ctx, ['A. Elements in a substance.', 'B. Number of atoms of each element in a substance.', 'C. How to make a particular substance.'], 2);
    grow.appendChild(q.el);
    root.appendChild(grow);
    root.appendChild(Lab.showReset(ctx, q, [Lab.backBtn(ctx, 'reading', 'Text')]));
  }
});
