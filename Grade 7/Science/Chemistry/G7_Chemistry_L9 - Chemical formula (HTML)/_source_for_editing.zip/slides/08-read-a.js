Engine.register({
  id: 'read-a', section: 'Practice', title: 'Reading a: the word “it”', mech: 'mcq', bg: 'navy',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 2 · Question a' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    grow.appendChild(h('div', { class: 'qtitle', text: 'a. The word “it” in line 1 refers to' }));
    grow.appendChild(h('div', { class: 'quoteline', html: '“A chemical formula is like a secret code for chemists. <b>It</b> uses letters and numbers…”' }));
    const q = Lab.mcq(ctx, ['A. a chemist', 'B. chemical formula', 'C. a secret code'], 1);
    grow.appendChild(q.el);
    root.appendChild(grow);
    root.appendChild(Lab.showReset(ctx, q, [Lab.backBtn(ctx, 'reading', 'Text')]));
  }
});
