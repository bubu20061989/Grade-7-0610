Engine.register({
  id: 'game', section: 'Consolidation', title: 'Consolidation game', mech: 'link', bg: 'cloud',
  render(root, ctx) {
    const URL = 'https://www.baamboozle.com/game/1074747';
    const cov = h('div', { class: 'cover stagger' });
    const open = () => { Sound.playEffect('click'); try { window.open(URL, '_blank', 'noopener'); } catch (e) { Engine.toast('Open: ' + URL); } };
    const gb = h('button', { class: 'gamebtn', title: 'Play the game' }, [ctx.img('assets/img/image31.png', { alt: 'A hand pressing a big pink button', zoom: false, class: 'float-anim' })]);
    ctx.on(gb, 'click', open);
    cov.appendChild(h('div', { class: 'cover-media' }, [gb]));
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Consolidation' }), h('span', { class: 'tag', text: 'Baamboozle' })]));
    txt.appendChild(h('div', { class: 'bubble', text: 'Click here to play the game' }));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Chemical formula<br><em>Challenge</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: '▶ Play the game' });
    ctx.on(go, 'click', open);
    txt.append(t, h('div', { class: 'hero-sub', text: 'Play in 2 teams · opens in a new tab (internet needed)' }), h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [go]));
    cov.appendChild(txt);
    root.appendChild(cov);
  }
});
