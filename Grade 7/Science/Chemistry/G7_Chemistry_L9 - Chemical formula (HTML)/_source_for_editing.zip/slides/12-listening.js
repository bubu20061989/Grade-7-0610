Engine.register({
  id: 'listening', section: 'Listening', title: 'Exercise 3: Listen and fill in the blanks', mech: 'cloze', bg: 'cloud',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 3 (P.21): Listen and fill in the blanks' }));
    const W = ['compound', 'elements', 'must', 'valency', 'formula'];
    const dd = ctx.dragDrop({
      items: W.map(w => ({ id: w, label: w })),
      zones: W.map((w, i) => ({ id: 's' + (i + 1), accept: [w], capacity: 1 })),
      renderZone: () => h('span', { class: 'slot' })
    });
    const slots = {};
    W.forEach((w, i) => { const z = dd.zoneEls['s' + (i + 1)]; slots['s' + (i + 1)] = h('span', { style: 'white-space:nowrap' }, ['(' + (i + 1) + ') ', z]); });
    const text = 'A binary [[s1]] has only two different [[s2]]. To write the formula of a binary compound, we use the valencies of two elements because the atoms of both elements [[s3]] lose, gain, or share the same number of electrons to form a binary compound. We need to consider some points before writing a chemical formula:' +
      '<span class="bul">• Identify the [[s4]] of each element in the compound.</span>' +
      '<span class="bul">• Write the chemical formula such that the totals of the valencies of two elements are equal.</span>' +
      '<span class="bul">• Always put metals first in the [[s5]].</span>';
    const p = h('div', { class: 'lpara' });
    p.innerHTML = text.replace(/\[\[(\w+)\]\]/g, '<span data-slot="$1"></span>');
    p.querySelectorAll('[data-slot]').forEach(s => s.replaceWith(slots[s.dataset.slot]));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [h('div', { class: 'ltitle', text: 'How to write a chemical formula of a binary compound?' }), Lab.player(ctx, 'assets/audio/media3.mp3', 'Track 9')]));
    const grow = h('div', { class: 'grow center-col stagger' }, [h('div', { class: 'card fill-w lcard' }, [p])]);
    root.appendChild(grow);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
