Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Chemical Formula', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const c = h('div', { class: 'ccover stagger' });
    c.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Science · Chemistry' })]));
    c.appendChild(h('div', { class: 'lessontag', text: 'Lesson 9:' }));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Chemical<br><em>Formula</em>';
    c.appendChild(t);
    const name = h('span', { class: 'molname q', text: '?' });
    const mol = h('button', { class: 'molbtn float-anim', title: 'Tap the molecule' }, [
      ctx.img('assets/img/image4.jpeg', { alt: 'An oxygen molecule: two red balls joined together', zoom: false }), name
    ]);
    const sub = h('div', { class: 'hero-sub', text: '👆 Tap the molecule' });
    ctx.on(mol, 'click', () => {
      name.classList.remove('q', 'pop-in'); void name.offsetWidth; name.classList.add('pop-in');
      name.innerHTML = Lab.chem('O2');
      sub.textContent = 'Two oxygen atoms → O₂';
      Sound.speak('O two. Two oxygen atoms.');
    });
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    c.append(mol, sub, h('div', { class: 'btnrow' }, [go]));
    root.appendChild(c);
  }
});
