Engine.register({
  id: 'leadin', section: 'Warm-up', title: 'Lead-in: What substance is it?', mech: 'reveal', bg: 'cloud',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1fr) minmax(0,1.3fr)' });
    const v = h('video', { src: 'assets/video/media1.mp4', autoplay: '', muted: '', loop: '', playsinline: '', poster: 'assets/img/image4.jpeg' });
    v.muted = true;
    sp.appendChild(h('div', { class: 'media' }, [h('div', { class: 'mediabox' }, [v])]));
    const Q = [
      ['What substance is it?', 'It is oxygen gas.'],
      ['What atoms are these?', 'They are oxygen atoms.'],
      ['How many atoms are there in this molecule?', 'There are two atoms in this molecule.'],
      ['Call the name of each circle that contains the letter O?', 'They are oxygen atoms.'],
      ['Do you know the chemical formula of this molecule?', 'Yes, the chemical formula is O₂.']
    ];
    const list = h('div', { class: 'qlist' });
    const items = Q.map(([q, a], i) => {
      const b = h('button', { class: 'qitem' }, [
        h('div', { class: 'q' }, [h('span', { class: 'n', text: String(i + 1) }), h('span', { text: q })]),
        h('div', { class: 'a', text: '→ ' + a })
      ]);
      ctx.on(b, 'click', () => {
        const open = b.classList.toggle('open');
        Sound.playEffect('click');
        if (open) Sound.speak(a.replace('O₂', 'O two'));
        if (items.every(x => x.classList.contains('open'))) Engine.confetti('star');
      });
      list.appendChild(b);
      return b;
    });
    sp.appendChild(h('div', {}, [h('div', { class: 'note', text: 'Ask the class, then tap a question to check the answer' }), list]));
    root.appendChild(sp);
    const row = h('div', { class: 'btnrow fixed' });
    const bS = h('button', { class: 'btn btn-show', text: '👁 Show all' });
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bS, 'click', () => items.forEach(x => x.classList.add('open')));
    ctx.on(bR, 'click', () => items.forEach(x => x.classList.remove('open')));
    row.append(bS, bR);
    root.appendChild(row);
  }
});
