Engine.register({
  id: 'ex4', section: 'Production', title: 'Exercise 4: Write the chemical formulas', mech: 'build', bg: 'cloud',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Exercise 4 (P.21): Write the chemical formulas' }));
    const hint = h('div', { class: 'hintbox fixed', html:
      '<b>Hint:</b> What elements are there in a compound? · What is the valency of each element in the compound? · ' +
      'How can we make the total of the valencies of two elements equal? · What is the chemical formula of the compound?' });
    root.appendChild(h('div', { class: 'note fixed', text: 'Work in pairs. Tap ▲ ▼ to set the subscripts so that the totals of the valencies are equal (no subscript = 1).' }));
    root.appendChild(hint);
    /* Bảng gốc: hợp chất – nguyên tố – hoá trị. ans = chỉ số dưới tối giản (đáp án chuẩn, không in trong PPT gốc) */
    const R = { I: 1, II: 2, III: 3, IV: 4 };
    const C = [
      { nm: 'Salt', e: [['Na', 'I'], ['Cl', 'I']], ans: [1, 1] },
      { nm: 'Phosphine', e: [['P', 'III'], ['H', 'I']], ans: [1, 3] },
      { nm: 'Quicklime', e: [['Ca', 'II'], ['O', 'II']], ans: [1, 1] },
      { nm: 'Silica', e: [['Si', 'IV'], ['O', 'II']], ans: [1, 2] },
      { nm: 'Aluminium carbide', e: [['Al', 'III'], ['C', 'IV']], ans: [4, 3] }
    ];
    const grid = h('div', { class: 'cmpgrid' });
    const cards = C.map(c => {
      const card = h('div', { class: 'cmp' });
      const st = [0, 0];   /* 0 = chưa chọn: không ô nào "đúng sẵn" khi chưa làm */
      const syms = [], tots = [];
      const bal = h('div', { class: 'bal' });
      const paint = () => {
        c.e.forEach((e, k) => { syms[k].innerHTML = e[0] + (st[k] === 0 ? '<sub class="q">?</sub>' : st[k] > 1 ? '<sub>' + st[k] + '</sub>' : ''); tots[k].textContent = st[k] ? R[e[1]] * st[k] : '–'; });
        bal.classList.toggle('even', st[0] > 0 && st[1] > 0 && R[c.e[0][1]] * st[0] === R[c.e[1][1]] * st[1]);
        ctx.clearResult(card);
      };
      const els = h('div', { class: 'els' });
      c.e.forEach((e, k) => {
        const sym = h('div', { class: 'sym' }); syms.push(sym);
        const up = h('button', { text: '▲', 'aria-label': 'More ' + e[0] }), dn = h('button', { text: '▼', 'aria-label': 'Fewer ' + e[0] });
        ctx.on(up, 'click', () => { if (st[k] < 4) { st[k]++; Sound.playEffect('click'); paint(); } });
        ctx.on(dn, 'click', () => { if (st[k] > 1) { st[k]--; Sound.playEffect('click'); paint(); } });
        els.appendChild(h('div', { class: 'el' }, [h('div', { class: 'val', text: e[1] }), sym, h('div', { class: 'stp' }, [up, dn])]));
      });
      c.e.forEach((e, k) => { const t = h('span', { class: 'tot' }); tots.push(t); });
      bal.append(h('span', { text: 'Σ' }), tots[0], h('span', { class: 'eq', text: '=' }), tots[1]);
      card.append(h('div', { class: 'nm', text: c.nm }), els, bal);
      grid.appendChild(card);
      paint();
      return { c, st, paint, card };
    });
    const grow = h('div', { class: 'grow center-col stagger' }, [h('div', { class: 'fill-w' }, [grid])]);
    root.appendChild(grow);
    const btns = ctx.buttons({
      check: () => {
        let ok = 0;
        cards.forEach(x => { const r = x.st[0] === x.c.ans[0] && x.st[1] === x.c.ans[1]; if (r) ok++; ctx.markResult(x.card, r); });
        return { correct: ok, total: cards.length };
      },
      show: () => cards.forEach(x => { x.st[0] = x.c.ans[0]; x.st[1] = x.c.ans[1]; x.paint(); }),
      reset: () => cards.forEach(x => { x.st[0] = 0; x.st[1] = 0; x.paint(); })
    });
    const bH = h('button', { class: 'btn', text: '💡 Hint' });
    ctx.on(bH, 'click', () => hint.classList.toggle('on'));
    const bT = h('button', { class: 'btn', text: '⏱ 3 min' });
    ctx.on(bT, 'click', () => Engine.timer(180));
    btns.prepend(bH, bT);
    root.appendChild(btns);
  }
});
