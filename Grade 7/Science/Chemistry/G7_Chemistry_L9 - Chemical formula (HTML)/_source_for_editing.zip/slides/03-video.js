Engine.register({
  id: 'video', section: 'Warm-up', title: 'Lead-in: Watch the video', mech: 'video', bg: 'cloud',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in · Watch' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const v = h('video', { class: 'dark', src: 'assets/video/media2.mp4', controls: '', playsinline: '', preload: 'metadata', poster: 'assets/img/image7.png' });
    grow.appendChild(h('div', { class: 'mediabox fill-w' }, [v]));
    root.appendChild(grow);
    const play = h('button', { class: 'btn btn-primary', text: '▶ Play video' });
    ctx.on(play, 'click', () => {
      if (!v.paused) { v.pause(); return; }
      Sound.stopAll();
      const p = v.play(); if (p && p.catch) p.catch(() => Engine.toast('Tap the video to play'));
    });
    ctx.on(v, 'play', () => { play.textContent = '❚❚ Pause'; });
    ctx.on(v, 'pause', () => { play.textContent = '▶ Play video'; });
    ctx.on(v, 'error', () => { play.disabled = true; play.textContent = 'Video unavailable'; });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [play]));
  },
  destroy() { document.querySelectorAll('video').forEach(v => { try { v.pause(); } catch (e) { } }); }
});
