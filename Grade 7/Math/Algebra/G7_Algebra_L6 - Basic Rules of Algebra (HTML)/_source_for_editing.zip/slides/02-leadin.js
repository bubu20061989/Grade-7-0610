Engine.register({
  id: 'leadin', section: 'Warm-up', title: 'Lead-in: the water bottle', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const grow = h('div', { class: 'grow stagger' });
    const media = h('div', { class: 'grow center-col' }, [
      ctx.img('assets/img/image4.png', { alt: 'Opening problem: a 1-liter water bottle, two cups of 0.2 and 0.3 liters, and Lan\'s solution', class: 'hero-img' }),
      ctx.zoomHint()
    ]);
    const q = h('div', { class: 'qtitle fixed', text: "Is there any mistake in Lan's solution?" });
    const opts = h('div', { class: 'optgrid fixed', style: 'grid-template-columns:repeat(2,minmax(0,1fr))' });
    const ans = h('div', { class: 'rulebox fixed', style: 'display:none;text-align:center' });
    ans.appendChild(Lab.para('✔ The solution is correct.<br>A <b>negative sign</b> before the brackets → <b>change the signs</b> of the terms inside.', {}, 'para'));
    let first = true;
    const pick = (b, ok) => {
      opts.querySelectorAll('.opt').forEach(x => { ctx.clearResult(x); x.classList.remove('picked'); });
      b.classList.add('picked');
      ctx.markResult(b, ok, { sound: !first });
      if (first) { Engine.score(ok ? 1 : 0, 1); first = false; }
      if (ok) { ans.style.display = ''; }
    };
    const bYes = h('button', { class: 'opt', text: 'Yes, there is a mistake' });
    const bNo = h('button', { class: 'opt', text: 'No, it is correct' });
    ctx.on(bYes, 'click', () => pick(bYes, false));
    ctx.on(bNo, 'click', () => pick(bNo, true));
    opts.append(bYes, bNo);
    grow.append(media, q, opts, ans);
    root.appendChild(grow);
    const row = h('div', { class: 'btnrow fixed' });
    const bS = h('button', { class: 'btn btn-show', text: '👁 Show answer' });
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(bS, 'click', () => { ans.style.display = ''; opts.querySelectorAll('.opt').forEach(x => ctx.clearResult(x)); ctx.markResult(bNo, true); });
    ctx.on(bR, 'click', () => { ans.style.display = 'none'; opts.querySelectorAll('.opt').forEach(x => { ctx.clearResult(x); x.classList.remove('picked'); }); });
    row.append(bS, bR);
    root.appendChild(row);
  }
});
