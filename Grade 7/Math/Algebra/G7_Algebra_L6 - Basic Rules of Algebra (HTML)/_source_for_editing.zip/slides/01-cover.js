Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Basic Rules of Algebra', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const card = h('div', { class: 'covereq' });
    const hint = h('div', { class: 'note', text: '👆 Tap +3 — move it to the other side' });
    const res = h('div', { class: 'eqresult', text: '' });
    const eq = Lab.eq(ctx, { L: [{ t: '2x' }, { t: '+3', mv: 1 }], R: [{ t: '7' }] }, {
      onDone: () => { res.textContent = 'The sign changes!'; hint.textContent = 'Today: change sides & remove brackets'; Engine.confetti('star'); }
    });
    card.append(hint, eq.el, res);
    media.appendChild(card);

    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 1 · Rational Numbers' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Lesson 6:<br>Basic Rules of <em>Algebra</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths" }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
