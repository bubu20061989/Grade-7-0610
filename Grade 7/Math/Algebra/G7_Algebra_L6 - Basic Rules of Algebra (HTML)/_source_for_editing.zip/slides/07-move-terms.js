Engine.register({
  id: 'move-terms', section: 'Maths Corner', title: 'Try it: change sides', mech: 'sim',
  render(root, ctx) {
    const EQ = [
      { L: [{ t: '2x' }, { t: '+3', mv: 1 }], R: [{ t: '7' }] },
      { L: [{ t: '16x' }, { t: '−4', mv: 1 }], R: [{ t: '0' }] },
      { L: [{ t: '−3x' }, { t: '+2', mv: 1 }], R: [{ t: '3' }] },
      { L: [{ t: '5x' }, { t: '+3', mv: 1 }], R: [{ t: '4x', mv: 1 }, { t: '−7' }] }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Try it: change sides' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap a coloured term, then choose its new sign' }));
    const card = h('div', { class: 'stagecard' });
    const dots = h('div', { class: 'dots' });
    const host = h('div', { class: 'fill-w center-col' });
    const res = h('div', { class: 'eqresult' });
    const pickRow = h('div', { class: 'signpick' });
    card.append(dots, host, pickRow, res);
    root.appendChild(h('div', { class: 'grow center-col stagger' }, [card]));

    let k = 0, eq = null, clean = true;
    const load = () => {
      host.innerHTML = ''; res.textContent = ''; pickRow.innerHTML = ''; clean = true;
      dots.innerHTML = ''; EQ.forEach((_, j) => dots.appendChild(h('i', { class: j === k ? 'now' : (j < k ? 'done' : '') })));
      eq = Lab.eq(ctx, EQ[k], {
        predict: true,
        onPick: (tl) => {
          pickRow.innerHTML = '';
          const t = tl.__t.replace(/^[+\-−]/, '');
          const lbl = h('span', { class: 'lbl', text: 'It becomes:' });
          const bP = h('button', { class: 'opt' }); bP.innerHTML = '+ ' + Lab.m(t);
          const bM = h('button', { class: 'opt' }); bM.innerHTML = '− ' + Lab.m(t);
          ctx.on(bP, 'click', () => choose('+', bP));
          ctx.on(bM, 'click', () => choose('−', bM));
          pickRow.append(lbl, bP, bM);
        },
        onDone: () => {
          res.innerHTML = '✔ ' + Lab.m(eq.text());
          Engine.score(clean ? 1 : 0, 1);
        }
      });
      host.appendChild(eq.el);
    };
    const choose = (s, b) => {
      const ok = eq.answer(s);
      if (ok) { pickRow.innerHTML = ''; Sound.playEffect('ok'); }
      else { clean = false; ctx.markResult(b, false, { sound: true }); }
    };
    const bR = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    const bN = h('button', { class: 'btn btn-primary', text: 'Next equation ▶' });
    ctx.on(bR, 'click', load);
    ctx.on(bN, 'click', () => { k = (k + 1) % EQ.length; load(); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bR, bN]));
    load();
  }
});
