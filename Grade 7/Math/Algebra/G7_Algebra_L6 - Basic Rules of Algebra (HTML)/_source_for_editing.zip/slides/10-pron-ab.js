Engine.register({
  id: 'pron-ab', section: 'Pronunciation', title: 'B. Pronunciation: sign or side?', mech: 'listen',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'B. Pronunciation' }));
    const row = h('div', { class: 'rowwrap stagger' });
    /* a. nghe + chú ý chữ gạch chân */
    const wSign = h('button', { class: 'pword' }); wSign.innerHTML = 'si<u>gn</u>';
    const wSide = h('button', { class: 'pword' }); wSide.innerHTML = 'si<u>de</u>';
    ctx.on(wSign, 'click', () => Sound.speak('sign'));
    ctx.on(wSide, 'click', () => Sound.speak('side'));
    const ca = h('div', { class: 'pcard colhalf' }, [
      h('div', { class: 'plabel', html: '<b>a.</b> Listen and focus on the underlined letters' }),
      Lab.player(ctx, 'assets/audio/media1.mp3', 'Track 7'),
      h('div', { class: 'pwords' }, [wSign, wSide]),
      h('div', { class: 'note', text: 'Tap a word to hear it again' })
    ]);
    /* b. nghe + khoanh từ đúng */
    const q1 = Lab.ich(ctx, ['sign', 'side'], 1);
    const q2 = Lab.ich(ctx, ['sign', 'side'], 0);
    const cb = h('div', { class: 'pcard colhalf' }, [
      h('div', { class: 'plabel', html: '<b>b.</b> Listen and circle the correct words' }),
      Lab.player(ctx, 'assets/audio/media2.mp3', 'Track 8'),
      h('div', { class: 'crow' }, [h('span', { text: 'i)' }), q1]),
      h('div', { class: 'crow' }, [h('span', { text: 'ii)' }), q2])
    ]);
    row.append(ca, cb);
    root.appendChild(row);
    root.appendChild(ctx.buttons(Lab.ichGroup([q1, q2])));
  }
});
