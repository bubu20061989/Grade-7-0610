Engine.register({
  id: 'pron-c', section: 'Pronunciation', title: 'B. Pronunciation: listen and write', mech: 'listen',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'c. Listen and write' }));
    const P = [['Left-hand side', 'Right-hand side'], ['Negative sign', 'Positive sign'], ['Change side', 'Change sign']];
    const items = [], zones = [];
    P.forEach((pair, i) => pair.forEach((w, j) => { items.push({ id: w, label: w }); zones.push({ id: 'z' + i + j, accept: [w], capacity: 1 }); }));
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'slot' }) });
    const list = h('div', { class: 'pairlist stagger' });
    ['i)', 'ii)', 'iii)'].forEach((n, i) => list.appendChild(h('div', { class: 'pairrow' }, [h('span', { text: n }), dd.zoneEls['z' + i + '0'], h('span', { text: 'and' }), dd.zoneEls['z' + i + '1']])));
    root.appendChild(h('div', { class: 'grow center-col' }, [list]));
    root.appendChild(dd.tray);
    const btns = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    btns.insertBefore(Lab.player(ctx, 'assets/audio/media3.mp3', 'Track 9'), btns.firstChild);
    root.appendChild(btns);
  }
});
