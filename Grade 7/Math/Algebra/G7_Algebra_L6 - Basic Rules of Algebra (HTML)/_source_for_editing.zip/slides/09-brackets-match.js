Engine.register({
  id: 'remove-brackets', section: 'Maths Corner', title: 'Practice: remove the brackets', mech: 'match',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Remove the brackets' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag the correct result to each expression' }));
    const R = [
      { id: 'r1', ex: '3 + (x − 5)', res: '3 + x − 5' },
      { id: 'r2', ex: '6 − (2x + 3)', res: '6 − 2x − 3' },
      { id: 'r3', ex: '{2/3} − ({4/7} + {2/3})', res: '{2/3} − {4/7} − {2/3}' },
      { id: 'r4', ex: '({4/9} + 3) − (8 + {4/9})', res: '{4/9} + 3 − 8 − {4/9}' }
    ];
    const items = R.map(r => ({ id: r.id, res: r.res })).concat([{ id: 'x1', res: '3 + x + 5' }, { id: 'x2', res: '6 − 2x + 3' }]);
    const zones = R.map(r => ({ id: 'z' + r.id, accept: [r.id], capacity: 1 }));
    const dd = ctx.dragDrop({
      items, zones,
      renderItem: it => { const n = h('div', { class: 'chip' }); n.appendChild(Lab.mel(it.res)); return n; },
      renderZone: () => h('div', { class: 'slot' })
    });
    const list = h('div', { class: 'mapgrid stagger' });
    R.forEach(r => list.appendChild(h('div', { class: 'maprow' }, [Lab.mel(r.ex), h('span', { class: 'arr', text: '→' }), dd.zoneEls['z' + r.id]])));
    root.appendChild(h('div', { class: 'grow center-col' }, [list]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => { Lab.ddClear(ctx, dd); dd.reset(); dd.show(); },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
