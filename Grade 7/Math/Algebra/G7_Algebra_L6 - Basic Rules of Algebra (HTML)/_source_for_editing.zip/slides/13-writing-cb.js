Engine.register({
  id: 'writing-cb', section: 'Writing', title: 'C. Writing b) — choose the words', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the correct words to express the process' }));
    const a = Lab.ich(ctx, ['positive', 'negative'], 0);
    const b = Lab.ich(ctx, ['keep', 'change'], 0);
    const c = Lab.ich(ctx, ['$−{2/9}$', '${2/9}$'], 1);
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.62fr) minmax(0,1.38fr)' });
    const mc = h('div', { class: 'mathcard' });
    [['b)', '{6/13} + ({2/9} − {6/13})'], ['', '= {6/13} + {2/9} − {6/13}'], ['', '= {2/9}.']].forEach(([l, m]) => mc.appendChild(h('div', { class: 'mrow' }, [h('span', { class: 'mlbl', text: l }), Lab.mel(m)])));
    const words = Lab.para('Since there is a [[a]] sign before the brackets, we remove the brackets and [[b]] the sign of ${2/9}$ and ${6/13}$, we obtain ${2/9}$ and $−{6/13}$. Cancel ${6/13}$ and $−{6/13}$, the final result is [[c]].', { a, b, c });
    sp.append(h('div', {}, [mc]), h('div', {}, [h('div', { class: 'card' }, [words])]));
    root.appendChild(sp);
    root.appendChild(ctx.buttons(Lab.ichGroup([a, b, c])));
  }
});
