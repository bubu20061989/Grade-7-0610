Engine.register({
  id: 'writing-da', section: 'Writing', title: 'D. Writing a) — find x, in words', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Find the value of x — fill in the blanks' }));
    const items = [{ id: 'side1', label: 'side' }, { id: 'side2', label: 'side' }, { id: 'sign', label: 'sign' }, { id: 'signs', label: 'signs' }];
    const zones = [{ id: 's1', accept: ['side1', 'side2'], capacity: 1 }, { id: 's2', accept: ['side1', 'side2'], capacity: 1 }, { id: 's3', accept: ['sign'], capacity: 1 }];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'slot' }) });
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.55fr) minmax(0,1.45fr)' });
    const mc = h('div', { class: 'mathcard' });
    [['a)', '16x − 4 = 0'], ['', '16x = 4'], ['', 'x = {1/4}.']].forEach(([l, m]) => mc.appendChild(h('div', { class: 'mrow' }, [h('span', { class: 'mlbl', text: l }), Lab.mel(m)])));
    const words = Lab.para('Change $−4$ from the left-hand [[s1]] to the right-hand [[s2]] and change its [[s3]] to $+4$.<br>Divide both sides by $16$.<br>The result is $x = {1/4}$.', { s1: dd.zoneEls.s1, s2: dd.zoneEls.s2, s3: dd.zoneEls.s3 });
    sp.append(h('div', {}, [mc]), h('div', {}, [h('div', { class: 'card' }, [words])]));
    root.appendChild(sp);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => {
        Lab.ddClear(ctx, dd); dd.reset();
        [['side1', 's1'], ['side2', 's2'], ['sign', 's3']].forEach(([it, z]) => { const n = dd.tray.querySelector('[data-dd-id="' + it + '"]'); if (n) { dd.zoneEls[z].appendChild(n); dd.place[it] = z; } });
      },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
