Engine.register({
  id: 'rule-brackets', section: 'Maths Corner', title: 'Rule: removing brackets', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    root.appendChild(h('div', { class: 'qtitle fixed', text: 'What is the rule for removing brackets?' }));
    const RULE = 'In an expression, if there is a positive sign before a set of brackets, we can remove the brackets and keep all terms within the brackets the same. In an expression, if there is a negative sign before a set of brackets, we can remove the brackets and make sure to change the signs of all terms within the brackets.';
    root.appendChild(h('div', { class: 'grow center-col stagger' }, [
      ctx.img('assets/img/image8.png', { alt: 'Rules for removing brackets with a positive or a negative sign before them', class: 'hero-img' }),
      ctx.zoomHint()
    ]));
    const q1 = Lab.ich(ctx, ['stay the same', 'change signs'], 0);
    const q2 = Lab.ich(ctx, ['stay the same', 'change signs'], 1);
    root.appendChild(h('div', { class: 'rowwrap fixed', style: 'flex:0 0 auto' }, [
      h('div', { class: 'rulebox' }, [Lab.para('<b style="color:var(--pos)">+ ( … )</b> → terms inside [[a]]', { a: q1 })]),
      h('div', { class: 'rulebox' }, [Lab.para('<b style="color:var(--neg)">− ( … )</b> → terms inside [[b]]', { b: q2 })])
    ]));
    const btns = ctx.buttons(Lab.ichGroup([q1, q2]));
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(bSay, 'click', () => { bSay.disabled = true; Sound.speak(RULE).then(() => { bSay.disabled = false; }); });
    btns.appendChild(bSay);
    root.appendChild(btns);
  }
});
