Engine.register({
  id: 'writing-ca', section: 'Writing', title: 'C. Writing a) — in words', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to express the process in words' }));
    const items = ['sign', 'signs', 'side', 'sides'].map(w => ({ id: w, label: w }));
    const zones = [{ id: 's1', accept: ['sign'], capacity: 1 }, { id: 's2', accept: ['signs'], capacity: 1 }];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'slot' }) });
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.62fr) minmax(0,1.38fr)' });
    const mc = h('div', { class: 'mathcard' });
    [['a)', '{2/3} − ({4/7} + {2/3})'], ['', '= {2/3} − {4/7} − {2/3}'], ['', '= −{4/7}.']].forEach(([l, m]) => mc.appendChild(h('div', { class: 'mrow' }, [h('span', { class: 'mlbl', text: l }), Lab.mel(m)])));
    const words = Lab.para('Since there is a negative [[s1]] before the brackets, we remove the brackets and change the [[s2]] of ${4/7}$ and ${2/3}$, we obtain $−{4/7}$ and $−{2/3}$. Cancel ${2/3}$ and $−{2/3}$, the final result is $−{4/7}$.', { s1: dd.zoneEls.s1, s2: dd.zoneEls.s2 });
    sp.append(h('div', {}, [mc]), h('div', {}, [h('div', { class: 'card' }, [words])]));
    root.appendChild(sp);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => { Lab.ddClear(ctx, dd); dd.reset(); dd.show(); },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
