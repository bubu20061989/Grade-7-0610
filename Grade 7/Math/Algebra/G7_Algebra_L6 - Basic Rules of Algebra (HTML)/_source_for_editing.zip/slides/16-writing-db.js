Engine.register({
  id: 'writing-db', section: 'Writing', title: 'D. Writing b) — choose the words', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    const ml = h('div', { class: 'mathline fixed' });
    ['b)  −3x + 2 = 3', '−3x = 3 − 2', '−3x = 1', 'x = −{1/3}.'].forEach((m, i) => { if (i) ml.appendChild(h('span', { class: 'arr', text: '⟶' })); ml.appendChild(Lab.mel(m)); });
    root.appendChild(ml);
    const a = Lab.ich(ctx, ['left-hand', 'right-hand'], 0);
    const b = Lab.ich(ctx, ['left-hand', 'right-hand'], 1);
    const c = Lab.ich(ctx, ['$+2$', '$−2$'], 1);
    const d = Lab.ich(ctx, ['$3$', '$−3$'], 1);
    const e = Lab.ich(ctx, ['$−{1/3}$', '${1/3}$'], 0);
    const words = Lab.para('Change $+2$ from the [[a]] side to the [[b]] side and change its sign to [[c]].<br>Divide both sides by [[d]].<br>The result is $x =$ [[e]].', { a, b, c, d, e });
    root.appendChild(h('div', { class: 'grow center-col stagger' }, [h('div', { class: 'stagecard' }, [words])]));
    root.appendChild(ctx.buttons(Lab.ichGroup([a, b, c, d, e])));
  }
});
