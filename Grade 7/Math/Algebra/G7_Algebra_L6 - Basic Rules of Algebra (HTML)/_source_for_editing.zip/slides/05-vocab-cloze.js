Engine.register({
  id: 'vocab-a', section: 'Vocabulary', title: 'A. Vocabulary: fill in the blanks', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'A. Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks: left-hand, right-hand, negative, positive' }));
    const items = [{ id: 'left-hand', label: 'left-hand' }, { id: 'positive', label: 'positive' }, { id: 'right-hand', label: 'right-hand' }, { id: 'negative', label: 'negative' }];
    const rows = [
      { id: 'a', l: 'a) In the equation $2x − 3 = 5x − 6$, the term $2x$ is on the', r: 'side.', ans: 'left-hand' },
      { id: 'b', l: 'b) In the equation $8x − 1 = 3 − 4x$, the term $3x$ has the', r: 'sign.', ans: 'positive' },
      { id: 'c', l: 'c) In the equation $2x − 3 = 10x$, the term $10x$ is on the', r: 'side.', ans: 'right-hand' },
      { id: 'd', l: 'd) In the expression ${3/2}x = 6x$, the term $−6x$ has the', r: 'sign.', ans: 'negative' }
    ];
    const zones = rows.map(r => ({ id: r.id, accept: [r.ans], capacity: 1 }));
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'clozeslot' }) });
    const list = h('div', { class: 'clozegrid stagger' });
    rows.forEach(r => { list.append(Lab.para(r.l, {}, 't l'), dd.zoneEls[r.id], Lab.para(r.r, {}, 't r')); });
    root.appendChild(h('div', { class: 'grow center-col' }, [list]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
