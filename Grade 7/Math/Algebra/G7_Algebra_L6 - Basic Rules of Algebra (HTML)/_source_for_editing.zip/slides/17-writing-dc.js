Engine.register({
  id: 'writing-dc', section: 'Writing', title: 'D. Writing c) — put the steps in order', mech: 'order',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    const ml = h('div', { class: 'mathline fixed' });
    ['c)  5x + 3 = 4x − 7', '5x − 4x = −7 − 3', 'x = −10.'].forEach((m, i) => { if (i) ml.appendChild(h('span', { class: 'arr', text: '⟶' })); ml.appendChild(Lab.mel(m)); });
    root.appendChild(ml);
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the sentences in the correct order: 1 → 4' }));
    const st = Lab.steps(ctx, [
      'Change $+3$ from the left-hand side to the right-hand side and change its sign to $−3$.',
      'Change $+4x$ from the right-hand side to the left-hand side and change its sign to $−4x$.',
      'Subtract $4x$ from $5x$, we obtain $x$. Subtract $3$ from $−7$, we obtain $−10$.',
      'The result is $x = −10$.'
    ]);
    root.appendChild(h('div', { class: 'grow center-col' }, [st.el]));
    root.appendChild(ctx.buttons(st));
  }
});
