Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary flashcards', mech: 'flashcard',
  render(root, ctx) {
    const W = [
      { w: 'equation', ipa: '/ɪˈkweɪ.ʒən/', img: 'v-equation', c: 'c-yel', def: 'A mathematical statement that shows two expressions are equal.', ex: '<b>Example:</b> $2x + 3 = 9$ is an <b>equation</b>.' },
      { w: 'expression', ipa: '/ɪkˈspreʃ.ən/', img: 'v-expression', c: 'c-blu', def: 'A mathematical phrase made up of numbers, variables, and operations, without an equals sign.', ex: '<b>Example:</b> $3x − 5$ is an algebraic <b>expression</b>.' },
      { w: 'left-hand side', ipa: '/left hænd saɪd/', img: 'v-lhs', c: 'c-pnk', def: 'The expression to the left of the equals sign in an equation.', ex: '<b>Example:</b> In $2x + 3 = 9$, $2x + 3$ is the <b>left-hand side</b>.' },
      { w: 'right-hand side', ipa: '/raɪt hænd saɪd/', img: 'v-rhs', c: 'c-grn', def: 'The expression to the right of the equals sign in an equation.', ex: '<b>Example:</b> In $2x + 3 = 9$, $9$ is the <b>right-hand side</b>.' },
      { w: 'positive sign', ipa: '/ˈpɒz.ə.tɪv saɪn/', img: 'v-positive', c: 'c-pur', def: 'The plus sign (+), which indicates addition or a positive value.', ex: '<b>Example:</b> In $x + 5 = 12$, the + is a <b>positive sign</b>.' },
      { w: 'negative sign', ipa: '/ˈneɡ.ə.tɪv saɪn/', img: 'v-negative', c: 'c-mint', def: 'The minus sign (−), which indicates subtraction or a negative value.', ex: '<b>Example:</b> In $3x − 7 = 8$, the − is a <b>negative sign</b>.' },
      { w: 'bracket', ipa: '/ˈbræk.ɪt/', img: 'v-bracket', c: 'c-org', def: 'A pair of symbols used to group numbers, variables, or expressions.', ex: '<b>Example:</b> In $2(x + 3)$, $(x + 3)$ is a <b>bracketed expression</b>.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'New words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    const dots = h('div', { class: 'dots fixed' });
    grow.append(h('div', { class: 'fc-wrap' }, [box]));
    root.appendChild(grow);
    root.appendChild(dots);

    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      const im = ctx.img('assets/img/' + v.img + '.png', { alt: v.w, zoom: false, class: 'float-anim' });
      front.append(h('div', { class: 'vimg' }, [im]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: '(noun)' }), h('div', { class: 'vipa', text: v.ipa })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def }), Lab.para(v.ex, {}, 'vex'));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; Engine.toast('🎉 All 7 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
