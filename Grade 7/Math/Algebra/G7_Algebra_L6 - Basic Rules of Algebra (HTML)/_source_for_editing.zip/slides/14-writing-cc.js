Engine.register({
  id: 'writing-cc', section: 'Writing', title: 'C. Writing c) — put the steps in order', mech: 'order',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the sentences in the correct order: 1 → 2 → 3' }));
    const mc = h('div', { class: 'mathcard strip fixed' });
    mc.append(h('span', { class: 'mlbl', text: 'c)' }), Lab.mel('({4/9} + 3) − (8 + {4/9})'), Lab.mel('= {4/9} + 3 − 8 − {4/9}'), Lab.mel('= 3 − 8'), Lab.mel('= −5.'));
    root.appendChild(mc);
    const st = Lab.steps(ctx, [
      'Since there is a negative sign before the brackets, we remove the brackets and change the sign of $8$ and ${4/9}$, we obtain $−8$ and $−{4/9}$.',
      'Cancel ${4/9}$ and $−{4/9}$, we obtain $3 − 8$.',
      'Subtract $8$ from $3$, the final result is $−5$.'
    ]);
    root.appendChild(h('div', { class: 'grow center-col' }, [st.el]));
    root.appendChild(ctx.buttons(st));
  }
});
