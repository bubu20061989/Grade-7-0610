Engine.register({
  id: 'review', section: 'Vocabulary', title: 'Review: match the words', mech: 'match',
  render(root, ctx) {
    const W = [['equation', 'v-equation'], ['expression', 'v-expression'], ['left-hand side', 'v-lhs'], ['right-hand side', 'v-rhs'], ['positive sign', 'v-positive'], ['negative sign', 'v-negative'], ['bracket', 'v-bracket']];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its picture' }));
    const items = W.map(([w]) => ({ id: w, label: w }));
    const zones = W.map(([w, img]) => ({ id: 'z-' + w, accept: [w], capacity: 1, img }));
    const dd = ctx.dragDrop({
      items, zones,
      renderZone: z => h('div', { class: 'matcell' }, [ctx.img('assets/img/' + z.img + '.png', { alt: 'picture', zoom: false })])
    });
    const grid = h('div', { class: 'imgrid stagger', style: 'grid-template-columns:repeat(4,minmax(0,1fr));grid-template-rows:repeat(2,minmax(0,1fr))' });
    ctx.shuffle(zones).forEach(z => grid.appendChild(dd.zoneEls[z.id]));
    root.appendChild(h('div', { class: 'grow' }, [grid]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
