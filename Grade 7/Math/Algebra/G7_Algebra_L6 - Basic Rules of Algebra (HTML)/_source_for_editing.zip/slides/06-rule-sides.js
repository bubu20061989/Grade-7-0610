Engine.register({
  id: 'rule-sides', section: 'Maths Corner', title: 'Rule: changing sides', mech: 'fact',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    root.appendChild(h('div', { class: 'qtitle fixed', text: 'What is the rule for changing sides?' }));
    const RULE = 'In an equation, if we change a term from left-hand side to right-hand side or vice versa, we must change its sign.';
    const media = h('div', { class: 'grow center-col stagger' }, [
      ctx.img('assets/img/image7.png', { alt: 'Moving a term from one side of an equation to the other changes its sign', class: 'hero-img' }),
      h('div', { class: 'note', text: '🔍 What happens to +3 and −3?' })
    ]);
    root.appendChild(media);
    const box = h('div', { class: 'rulebox fixed reserve', style: 'text-align:center' });
    box.innerHTML = 'In an equation, if we change a term from <b>left-hand side</b> to <b>right-hand side</b> or vice versa, we must <mark>change its sign</mark>.';
    root.appendChild(box);
    const bRev = h('button', { class: 'btn btn-primary pulse', text: '💡 Reveal the rule' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(bRev, 'click', () => { box.classList.add('shown', 'pop-in'); bRev.classList.remove('pulse'); Sound.playEffect('click'); });
    ctx.on(bSay, 'click', () => { box.classList.add('shown'); bSay.disabled = true; Sound.speak(RULE).then(() => { bSay.disabled = false; }); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bRev, bSay]));
  }
});
