Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'speak',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const sp = h('div', { class: 'split stagger' });
    const V = [['equation', 'c-yel'], ['expression', 'c-blu'], ['left-hand side', 'c-pnk'], ['right-hand side', 'c-grn'], ['positive sign', 'c-pur'], ['negative sign', 'c-mint']];
    const chips = h('div', { class: 'vchips' });
    V.forEach(([w, c]) => { const b = h('button', { class: 'vchip ' + c, text: w }); ctx.on(b, 'click', () => { b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge'); Sound.speak(w); }); chips.appendChild(b); });
    const left = h('div', { class: 'pcard' }, [h('div', { class: 'plabel', html: '<b>Vocabulary</b> — tap to listen' }), chips]);
    const S = 'In an equation, if we change a term from left-hand side to right-hand side or vice versa, we must change its sign.';
    const spEl = h('div', { class: 'sp' });
    const words = S.split(' ').map(w => { const s = h('span', { class: 'w', text: w }); spEl.append(s, ' '); return s; });
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Say it together' });
    ctx.on(say, 'click', () => {
      say.disabled = true;
      Sound.speak(S, { onBoundary: (e) => { let n = 0; words.forEach(s => { s.classList.toggle('kara', e.charIndex >= n && e.charIndex < n + s.textContent.length + 1); n += s.textContent.length + 1; }); } })
        .then(() => { words.forEach(s => s.classList.remove('kara')); say.disabled = false; });
    });
    const right = h('div', { class: 'pcard' }, [h('div', { class: 'plabel', html: '<b>Sentence pattern</b>' }), spEl, h('div', { class: 'btnrow' }, [say]), h('div', { class: 'note', text: '📖 Prepare the next lesson.' })]);
    sp.append(left, right);
    root.appendChild(sp);
    const checks = h('div', { class: 'checkrow fixed' });
    ['I know the new words', 'I can change sides', 'I can remove brackets'].forEach(t => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '✓' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => { b.classList.toggle('on'); Sound.playEffect('click'); if (checks.querySelectorAll('.on').length === 3) Engine.confetti('star'); });
      checks.appendChild(b);
    });
    root.appendChild(checks);
  }
});
