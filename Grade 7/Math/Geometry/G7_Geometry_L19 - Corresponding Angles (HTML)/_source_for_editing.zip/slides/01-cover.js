/* L1 Cover — PPT slide 1: bìa (ảnh minh hoạ bảng-compa-thước của template + khối 3D ở nền) */
Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Corresponding Angles', mech: 'intro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const pic = ctx.img('assets/img/image3.png', { alt: 'Geometry tools: compass, set square and board', zoom: false, class: 'hero-img float-anim' });
    pic.style.cursor = 'pointer';
    ctx.on(pic, 'click', () => {
      pic.classList.remove('nudge'); void pic.offsetWidth; pic.classList.add('nudge');
      Sound.speak('Lesson nineteen. Corresponding angles.');
    });
    media.appendChild(pic);

    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 4 · Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Lesson 19:<br>Corresponding <em>Angles</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths" }),
      h('div', { class: 'note', style: 'text-align:left', text: '👆 Tap the picture to hear the title' }),
      h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
