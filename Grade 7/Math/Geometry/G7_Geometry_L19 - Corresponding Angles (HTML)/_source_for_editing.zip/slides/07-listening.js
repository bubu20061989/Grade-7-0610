/* L5 Board — PPT slide 9: B. Listening (Track 25, audio gốc). Nghe rồi kéo A/B/C vào dưới từng hình.
   Mỗi hình cắt riêng từ ảnh gốc (bỏ dòng "Diagram __" in sẵn) để ô thả luôn thẳng dưới đúng hình. */
Engine.register({
  id: 'listening', section: 'Listening', title: 'Listen: name the diagrams', mech: 'listen',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Listen and write the names' }));
    const play = h('button', { class: 'btn btn-primary', text: '▶ Play Track 25' });
    ctx.on(play, 'click', () => { Sound.stopAll(); Sound.playEffect('track25'); });
    const stop = h('button', { class: 'btn', text: '■ Stop' });
    ctx.on(stop, 'click', () => Sound.stopAll());
    root.appendChild(h('div', { class: 'trackrow fixed' }, [h('div', { class: 'note', text: 'Write the correct names (A, B, or C) of the diagrams.' }), play, stop]));

    const SRC = 'assets/img/image19.png', W = 2172, H = 724;
    const D = [
      { id: 'd1', box: [0, 0, .322, .71], ans: 'B' },
      { id: 'd2', box: [.322, 0, .692, .71], ans: 'C' },
      { id: 'd3', box: [.692, 0, 1, .71], ans: 'A' }
    ];
    const dd = ctx.dragDrop({
      items: ['A', 'B', 'C'].map(x => ({ id: x, label: x })),
      zones: D.map(d => ({ id: d.id, accept: [d.ans], capacity: 1 })),
      renderZone: () => h('div', { class: 'dd-zone' })
    });
    dd.tray.classList.add('lettertray');
    const board = h('div', { class: 'imgrid listenboard', style: 'grid-template-columns:repeat(3,minmax(0,1fr));display:grid' });
    D.forEach(d => {
      const cell = h('div', { class: 'cell', style: 'box-shadow:none;border:0' });
      cell.append(Lab.crop(ctx, SRC, W, H, d.box, { alt: 'Diagram with two angles', zoom: false }),
        h('div', { class: 'diagrow', style: 'display:flex;justify-content:center' }, [h('div', { class: 'dlab' }, [h('span', { text: 'Diagram' }), dd.zoneEls[d.id]])]));
      board.appendChild(cell);
    });
    const grow = h('div', { class: 'grow stagger' });
    grow.append(board, dd.tray);
    root.appendChild(grow);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
