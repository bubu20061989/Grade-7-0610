/* L2 Split — PPT slide 8: Maths Corner. Hình động giảng giải: trượt ∠1 dọc theo đường cắt (Line 3)
   xuống giao điểm thứ hai -> trùng khít ∠2 = "cùng vị trí tương ứng". Định nghĩa gốc lật mở từng ý. */
Engine.register({
  id: 'corner', section: 'Maths Corner', title: 'What are corresponding angles?', mech: 'sim',
  render(root, ctx) {
    const S = Lab.sv;
    root.appendChild(h('div', { class: 'pill fixed', text: 'What is a pair of corresponding angles?' }));
    const sp = h('div', { class: 'split grow stagger' });

    /* --- hình vẽ: Line 1, Line 2 song song; Line 3 cắt tại P1, P2 --- */
    const P1 = [372, 130], P2 = [312, 300], D = [P2[0] - P1[0], P2[1] - P1[1]];
    const len = Math.hypot(D[0], D[1]), u = [D[0] / len, D[1] / len];
    const R = 58;
    const wedge = (P) => `M${P[0]} ${P[1]} L${P[0] + R} ${P[1]} A${R} ${R} 0 0 0 ${(P[0] - u[0] * R).toFixed(1)} ${(P[1] - u[1] * R).toFixed(1)} Z`;
    const svg = S('svg', { viewBox: '0 0 640 400', class: 'anglesvg', role: 'img', 'aria-label': 'Line 3 crosses Line 1 and Line 2; angle 1 and angle 2 are corresponding angles' });
    const defs = S('defs', {}, [S('marker', { id: 'ar', viewBox: '0 0 10 10', refX: 8, refY: 5, markerWidth: 6, markerHeight: 6, orient: 'auto-start-reverse' }, [S('path', { d: 'M0 0L10 5L0 10z', fill: '#111827' })])]);
    svg.appendChild(defs);
    [130, 300].forEach(y => svg.appendChild(S('line', { x1: 40, y1: y, x2: 610, y2: y, stroke: '#111827', 'stroke-width': 4, 'marker-start': 'url(#ar)', 'marker-end': 'url(#ar)' })));
    const a = [P1[0] - u[0] * 105, P1[1] - u[1] * 105], b = [P2[0] + u[0] * 90, P2[1] + u[1] * 90];
    svg.appendChild(S('line', { x1: b[0].toFixed(1), y1: b[1].toFixed(1), x2: a[0].toFixed(1), y2: a[1].toFixed(1), stroke: '#111827', 'stroke-width': 4, 'marker-start': 'url(#ar)', 'marker-end': 'url(#ar)' }));
    const w2 = S('path', { d: wedge(P2), fill: 'var(--ang2)', 'fill-opacity': .85 });
    const w1 = S('path', { d: wedge(P1), fill: 'var(--ang1)', 'fill-opacity': .9 });
    const ghost = S('path', { d: wedge(P1), fill: 'var(--ang1)', 'fill-opacity': .75, stroke: '#B45309', 'stroke-width': 3, 'stroke-dasharray': '6 5', class: 'ghost', opacity: 0 });
    svg.append(w2, w1, ghost);
    const T = (x, y, s, fill, size) => { const t = S('text', { x, y, fill: fill || '#111827', 'font-size': size || 30 }); t.textContent = s; return t; };
    svg.append(T(70, 118, 'Line 1'), T(70, 288, 'Line 2'), T(a[0] + 14, a[1] + 8, 'Line 3'),
      T(P1[0] + 50, P1[1] - 32, '∠1', '#B45309', 34), T(P2[0] + 50, P2[1] - 32, '∠2', '#1D4ED8', 34));
    const media = h('div', { class: 'media' });
    const vizw = h('div', { class: 'angsvg-wrap' }, [svg]);
    const slide = h('button', { class: 'btn btn-primary', text: '▶ Slide ∠1 along Line 3' });
    const verdict = h('div', { class: 'verdict' });
    let moved = false;
    ctx.on(slide, 'click', () => {
      moved = !moved;
      ghost.setAttribute('opacity', 1);
      ghost.style.transform = moved ? `translate(${D[0]}px, ${D[1]}px)` : 'translate(0px, 0px)';
      verdict.textContent = '';
      if (moved) ctx.timeout(() => { verdict.textContent = '✓ Same position! ∠1 and ∠2 are corresponding angles.'; Sound.playEffect('ok'); }, 1350);
      slide.textContent = moved ? '↩ Move it back' : '▶ Slide ∠1 along Line 3';
    });
    const orig = h('button', { class: 'btn', text: '🔍 Original diagram' });
    ctx.on(orig, 'click', () => Engine.lightbox('assets/img/image18.png', 'Line 1, Line 2, Line 3 with angle 1 and angle 2'));
    media.append(vizw, verdict, h('div', { class: 'btnrow' }, [slide, orig]));

    /* --- định nghĩa nguyên văn, lật mở từng ý --- */
    const right = h('div', {});
    const POINTS = [
      'A pair of <b>corresponding angles</b> is formed when a <b>transversal</b> line intersects a pair of straight lines.',
      'The two angles are located on the <b>same side</b> of the transversal line and in <b>corresponding positions</b>.'
    ];
    POINTS.forEach((p, k) => {
      const c = h('div', { class: 'revcard' });
      const body = h('div', { html: '<span class="cover-txt">Tap to reveal idea ' + (k + 1) + '</span>' });
      c.append(h('span', { class: 'num', text: String(k + 1) }), body);
      ctx.on(c, 'click', () => {
        if (c.classList.contains('open')) { Sound.speak(body.textContent); return; }
        c.classList.add('open', 'pop-in'); body.innerHTML = p + ' 🔊';
        Sound.speak(body.textContent.replace('🔊', ''));
      });
      right.appendChild(c);
    });
    right.appendChild(h('div', { class: 'note', text: 'Tap an idea again to listen.' }));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
