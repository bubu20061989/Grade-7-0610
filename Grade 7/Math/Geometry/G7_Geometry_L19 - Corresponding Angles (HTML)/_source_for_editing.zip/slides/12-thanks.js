/* L1 Cover — PPT slide 13: Thanks! Cụm khối 3D của slide gốc (bấm cho nảy), lời kết, sao + ôn lại câu sai. */
Engine.register({
  id: 'thanks', section: 'Consolidation', title: 'Thanks!', mech: 'outro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const cl = h('div', { class: 'shapecluster' });
    [['image11.png', 'sphere'], ['image6.png', 'cube'], ['image9.png', 'cylinder'], ['image10.png', 'sphere']].forEach(([f, name]) => {
      const b = h('button', { 'aria-label': name });
      const im = ctx.img('assets/img/' + f, { alt: name, zoom: false });
      im.className = '';
      b.appendChild(im);
      ctx.on(b, 'click', () => { im.classList.remove('bump'); void im.offsetWidth; im.classList.add('bump'); Sound.speak(name); });
      cl.appendChild(b);
    });
    media.appendChild(cl);

    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Thanks!</em>';
    const stars = Engine.stars || 0;
    const doneN = Object.keys(Engine.done || {}).length;
    const wrong = (Engine.wrongList() || []).filter(id => Engine.slides.some(s => s.id === id));
    let msg;
    if (!doneN || !stars) msg = '⭐ ' + stars + ' stars — try the activities to collect more!';
    else if (!wrong.length) msg = '⭐ ' + stars + ' stars — great work, everyone!';
    else msg = '⭐ ' + stars + ' stars — good job! Let\'s review:';
    txt.append(t, h('div', { class: 'quote', text: '“Connecting points, shaping minds.”' }), h('div', { class: 'hero-sub', text: msg }));
    if (wrong.length && stars) {
      const rr = h('div', { class: 'revrow' });
      wrong.forEach(id => {
        const s = Engine.slides.find(x => x.id === id);
        const b = h('button', { class: 'btn', text: '↩ ' + s.title });
        ctx.on(b, 'click', () => Lab.goTo(id));
        rr.appendChild(b);
      });
      txt.appendChild(rr);
    }
    const party = h('button', { class: 'btn btn-primary pulse', text: '🎉 Celebrate' });
    ctx.on(party, 'click', () => Engine.confetti());
    txt.append(h('div', { class: 'note', style: 'text-align:left', text: '👆 Tap a shape to hear its name' }), h('div', { class: 'btnrow' }, [party]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
