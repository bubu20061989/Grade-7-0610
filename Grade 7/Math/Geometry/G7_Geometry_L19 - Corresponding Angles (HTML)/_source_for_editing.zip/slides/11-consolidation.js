/* L5 Board — PPT slide 12: Consolidation. Bấm nghe 3 từ vựng; sắp lại mẫu câu định nghĩa góc đồng vị. */
Engine.register({
  id: 'consolidation', section: 'Consolidation', title: 'Consolidation', mech: 'order',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const voc = h('div', { class: 'vocrow fixed stagger' });
    [['transversal', 'wtra'], ['parallel', 'wpar'], ['corresponding angles', 'wcor']].forEach(([w, c]) => {
      const b = h('button', { class: 'vocbtn ' + c, text: '🔊 ' + w });
      ctx.on(b, 'click', () => Sound.speak(w));
      voc.appendChild(b);
    });
    root.appendChild(h('div', { class: 'task vochead fixed', html: 'Vocabulary: <b>transversal, parallel, corresponding angles</b>' }));
    root.appendChild(voc);
    root.appendChild(h('div', { class: 'task fixed', html: '<b>Define corresponding angles.</b> Put the sentence pattern in order:' }));
    const CH = ['A pair of corresponding angles', 'is formed', 'when a transversal line', 'intersects', 'a pair of straight lines.'];
    const dd = ctx.dragDrop({
      items: CH.map((t, i) => ({ id: 'k' + i, label: t })),
      zones: CH.map((t, i) => ({ id: 's' + i, accept: ['k' + i], capacity: 1 })),
      renderZone: (z) => { const n = h('div', { class: 'dd-zone' }); n.dataset.n = String(+z.id.slice(1) + 1); return n; }
    });
    dd.tray.classList.add('ordtray');
    const grow = h('div', { class: 'grow center-col stagger', style: 'gap:clamp(8px,1.8vh,22px)' });
    const rowEl = h('div', { class: 'ordrow' }, CH.map((_, i) => dd.zoneEls['s' + i]));
    const listen = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(listen, 'click', () => Sound.speak(CH.join(' ')));
    grow.append(rowEl, dd.tray, h('div', { class: 'note', text: '📚 Prepare the next lesson.' }));
    root.appendChild(grow);
    const btns = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    btns.appendChild(listen);
    root.appendChild(btns);
  }
});
