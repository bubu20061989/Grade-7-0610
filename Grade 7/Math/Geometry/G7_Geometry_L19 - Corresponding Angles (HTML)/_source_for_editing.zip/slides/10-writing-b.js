/* L2 Split — PPT slide 11 (phần lời giải): khung Solution gốc làm hình chính; kéo 2 từ vào chỗ trống. */
Engine.register({
  id: 'writing-b', section: 'Writing', title: 'Complete the solution', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Complete the solution' }));
    const sp = h('div', { class: 'split wide-l grow stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image23.png', { alt: 'Solution with two blanks', class: 'hero-img' }), ctx.zoomHint());
    const dd = ctx.dragDrop({
      items: [{ id: 'cor', label: 'corresponding' }, { id: 'par', label: 'parallel' }],
      zones: [{ id: 'z1', accept: ['cor'], capacity: 1 }, { id: 'z2', accept: ['par'], capacity: 1 }],
      renderZone: () => h('div', { class: 'dd-zone clozeslot' })
    });
    const row = (l, z, r) => h('div', { class: 'sent' }, [h('span', { html: l }), dd.zoneEls[z], h('span', { html: r })]);
    const list = h('div', { class: 'sentlist' }, [
      row('We can see that <span class="mh">M̂₁</span> and <span class="mh">N̂₁</span> are a pair of', 'z1', 'angles.'),
      row('Also, line <i>a</i> and line <i>b</i> are', 'z2', '.')
    ]);
    sp.append(media, h('div', {}, [list, dd.tray]));
    root.appendChild(sp);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
