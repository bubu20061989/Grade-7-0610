/* L3 Stage card — PPT slide 3-4-5: 3 thẻ lật từ vựng (gộp 3 slide cùng khuôn).
   Mặt trước = đúng phần ảnh PPT hiện (hình + thẻ từ có phiên âm), mặt sau = định nghĩa + ví dụ nguyên văn. */
Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary cards', mech: 'flashcard',
  render(root, ctx) {
    const I15 = ['assets/img/image15.png', 1536, 1024], I16 = ['assets/img/image16.png', 1774, 887];
    const CARDS = [
      { w: 'parallel', cls: 'wpar', img: I15, pic: [0, .0833, 1, .4452], word: [.1512, .4356, .82, .9688],
        def: 'describing two or more lines that are always the same distance apart and never meet.',
        ex: 'Lines AB and CD are <b>parallel</b> because they never intersect.' },
      { w: 'transversal', cls: 'wtra', img: I16, pic: [0, .0172, .3361, .6481], word: [0, .6341, .3361, 1],
        def: 'a line that crosses two or more lines at different points',
        ex: 'Line t is a <b>transversal</b> of the parallel lines a and b.' },
      { w: 'corresponding', cls: 'wcor', img: I16, pic: [.3291, 0, .6789, .6481], word: [.3382, .6341, .6659, 1],
        def: 'angles that are in the same relative position at two intersections.',
        ex: '∠1 and ∠2 are <b>corresponding</b> angles.' }
    ];
    let cur = 0;
    const seen = new Set([0]);
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Say the word. Then tap the card to see its meaning.' }));
    const wrap = h('div', { class: 'fc-wrap grow stagger' });
    const card = h('div', { class: 'fc vfc' });
    const front = h('div', { class: 'face front' });
    const back = h('div', { class: 'face back' });
    card.append(front, back);
    wrap.appendChild(card);
    root.appendChild(wrap);

    const dots = h('div', { class: 'dots' });
    const prev = h('button', { class: 'btn', text: '◀ Back' });
    const listen = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    const flip = h('button', { class: 'btn', text: '🔄 Flip' });
    const next = h('button', { class: 'btn', text: 'Next card ▶' });
    root.appendChild(h('div', { class: 'fcbar fixed' }, [prev, listen, flip, dots, next]));

    const paint = () => {
      const c = CARDS[cur];
      card.className = 'fc vfc ' + c.cls;
      card.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.append(Lab.crop(null, c.img[0], c.img[1], c.img[2], c.pic, { alt: c.w + ' — diagram', zoom: false }),
        Lab.crop(null, c.img[0], c.img[1], c.img[2], c.word, { alt: c.w + ' — word card', zoom: false, cls: 'word' }));
      back.append(h('div', { class: 'wname', text: c.w }), h('div', { class: 'def', text: c.def }),
        h('div', { class: 'ex', html: '<b>Example:</b> ' + c.ex }));
      dots.innerHTML = '';
      CARDS.forEach((_, k) => dots.appendChild(h('i', { class: k === cur ? 'now' : seen.has(k) ? 'done' : '' })));
      prev.disabled = cur === 0; next.disabled = cur === CARDS.length - 1;
      card.classList.remove('pop-in'); void card.offsetWidth; card.classList.add('pop-in');
    };
    const doFlip = () => { card.classList.toggle('flipped'); Sound.playEffect('click'); };
    ctx.on(card, 'click', doFlip);
    ctx.on(flip, 'click', doFlip);
    ctx.on(listen, 'click', () => {
      const c = CARDS[cur];
      Sound.speak(card.classList.contains('flipped') ? c.w + '. ' + c.def : c.w);
    });
    ctx.on(prev, 'click', () => { if (cur > 0) { cur--; paint(); } });
    ctx.on(next, 'click', () => {
      if (cur < CARDS.length - 1) { cur++; seen.add(cur); paint(); if (seen.size === CARDS.length) Engine.confetti('star'); }
    });
    paint();
  }
});
