/* L4 Grid — PPT slide 6: Review. Kéo đúng từ vào dưới từng hình (hình cắt bỏ phần chữ của ảnh gốc). */
Engine.register({
  id: 'review', section: 'Vocabulary', title: 'Review: match the words', mech: 'match',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word under the correct picture.' }));
    const PICS = [
      { id: 'tra', src: 'assets/img/image16.png', W: 1774, H: 887, box: [0, .0172, .3361, .6200], alt: 'Two lines crossed by one line' },
      { id: 'cor', src: 'assets/img/image16.png', W: 1774, H: 887, box: [.3291, 0, .6789, .6200], alt: 'Angle 1 and angle 2 at two intersections' },
      { id: 'par', src: 'assets/img/image15.png', W: 1536, H: 1024, box: [0, .0833, 1, .4452], alt: 'Two arrows that never meet' }
    ];
    const order = ctx.shuffle(PICS);
    const dd = ctx.dragDrop({
      items: [{ id: 'transversal', label: 'transversal' }, { id: 'corresponding', label: 'corresponding' }, { id: 'parallel', label: 'parallel' }],
      zones: [
        { id: 'tra', accept: ['transversal'], capacity: 1 },
        { id: 'cor', accept: ['corresponding'], capacity: 1 },
        { id: 'par', accept: ['parallel'], capacity: 1 }
      ],
      renderZone: () => h('div', { class: 'dd-zone' })
    });
    const grid = h('div', { class: 'imgrid vm', style: 'grid-template-columns:repeat(3,minmax(0,1fr))' });
    order.forEach(p => {
      const cell = h('div', { class: 'cell' });
      cell.append(Lab.crop(ctx, p.src, p.W, p.H, p.box, { alt: p.alt, zoom: false }), dd.zoneEls[p.id]);
      grid.appendChild(cell);
    });
    const grow = h('div', { class: 'grow stagger' });
    grow.append(h('div', { class: 'fill-w grow' }, [grid]), dd.tray);
    root.appendChild(grow);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
