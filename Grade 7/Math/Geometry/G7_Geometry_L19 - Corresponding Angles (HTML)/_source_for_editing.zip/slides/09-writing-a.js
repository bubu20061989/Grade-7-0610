/* L3 Stage — PPT slide 11 (phần đề): D. Writing a). Đề bài gốc làm hình chính; tính số đo N̂₁ bằng bàn phím số. */
Engine.register({
  id: 'writing-a', section: 'Writing', title: 'Find the angle', mech: 'numpad',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Solve the problem' }));
    const grow = h('div', { class: 'grow stagger', style: 'gap:clamp(6px,1.4vh,16px)' });
    const top = h('div', { class: 'wa-top' }, [h('div', { class: 'boardimg', style: 'flex-direction:column' }, [
      ctx.img('assets/img/image22.png', { alt: 'a) Lines a and b are parallel. Angle M1 is 65°. Find angle N1.' }), ctx.zoomHint()])]);
    const left = h('div', { class: 'left' });
    left.append(
      h('div', { class: 'given', html: 'In the diagram, <b>a</b> and <b>b</b> are two parallel lines.<br>Given <span class="chipv"><span class="mh">M̂₁</span> = 65°</span>' }),
      h('div', { class: 'given', html: 'Find the measure of angle <span class="mh">N̂₁</span>.' })
    );
    let val = '';
    const box = h('span', { class: 'ansbox', text: '?' });
    const eq = h('div', { class: 'eqline' }, [h('span', { class: 'mh', text: 'N̂₁' }), h('span', { text: '=' }), box, h('span', { text: '°' })]);
    const paint = () => { box.textContent = val || '?'; ctx.clearResult(eq); };
    const pad = h('div', { class: 'keypad six' });
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].forEach(d => {
      const k = h('button', { class: 'key', text: d });
      ctx.on(k, 'click', () => { if (val.length < 3) { val += d; Sound.playEffect('click'); paint(); } });
      pad.appendChild(k);
    });
    const del = h('button', { class: 'key', text: '⌫' });
    ctx.on(del, 'click', () => { val = val.slice(0, -1); paint(); });
    pad.appendChild(del);
    const t60 = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(t60, 'click', () => Engine.timer(60));

    const why = h('div', { class: 'solline hidden', text: 'N̂₁ = M̂₁ = 65° (corresponding angles)' });
    left.append(h('div', { class: 'eqrow' }, [eq, t60]), why);
    grow.append(top, h('div', { class: 'wa-bottom' }, [left, pad]));
    root.appendChild(grow);
    root.appendChild(ctx.buttons({
      check: () => {
        const ok = val.trim() === '65';
        ctx.markResult(eq, ok);
        if (ok) why.classList.remove('hidden');
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { val = '65'; paint(); ctx.markResult(eq, true); why.classList.remove('hidden'); },
      reset: () => { val = ''; paint(); why.classList.add('hidden'); }
    }));
  }
});
