/* L2 Split — PPT slide 10: C. Practice. Bảng Figures/Statements gốc làm hình chính; kéo từ vào 3 chỗ trống. */
Engine.register({
  id: 'practice', section: 'Practice', title: 'Fill in the blanks', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Fill in the blanks' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Describe the relationship of two corresponding angles.' }));
    const sp = h('div', { class: 'split even grow stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image21.png', { alt: 'Table: figures and statements about corresponding angles', class: 'hero-img' }), ctx.zoomHint());
    const dd = ctx.dragDrop({
      items: [{ id: 'c1', label: 'corresponding' }, { id: 'c2', label: 'corresponding' }, { id: 'p', label: 'parallel' }],
      zones: [
        { id: 'z1', accept: it => it.label === 'corresponding', capacity: 1 },
        { id: 'z2', accept: it => it.label === 'corresponding', capacity: 1 },
        { id: 'z3', accept: it => it.label === 'parallel', capacity: 1 }
      ],
      renderZone: () => h('div', { class: 'dd-zone clozeslot' })
    });
    const row = (l, z, r) => h('div', { class: 'sent' }, [h('span', { html: l }), dd.zoneEls[z], h('span', { html: r })]);
    const list = h('div', { class: 'sentlist' }, [
      row('<span class="mh">M̂₁</span> and <span class="mh">N̂₁</span> are a pair of', 'z1', 'angles.'),
      row('<span class="mh">Â₁</span> and <span class="mh">B̂₁</span> are a pair of', 'z2', 'angles.'),
      row('Hence, line <i>x</i> and line <i>y</i> are', 'z3', '.')
    ]);
    sp.append(media, h('div', {}, [list, dd.tray]));
    root.appendChild(sp);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => {
      [['c1', 'z1'], ['c2', 'z2'], ['p', 'z3']].forEach(([id, z]) => {
        const n = root.querySelector('[data-dd-id="' + id + '"]');
        if (!n) return;
        ctx.clearResult(n); dd.zoneEls[z].appendChild(n); dd.place[id] = z;
      });
    }, reset: () => dd.reset() }));
  }
});
