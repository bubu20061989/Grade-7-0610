/* L3 Stage card — PPT slide 7: A. Vocabulary — Unscramble (4 từ). Bấm chữ cái theo thứ tự; giải xong thì nói nghĩa. */
Engine.register({
  id: 'unscramble', section: 'Vocabulary', title: 'Unscramble the words', mech: 'unscramble',
  render(root, ctx) {
    const WORDS = [
      { s: 'AAEPLLRL', a: 'PARALLEL' }, { s: 'CEEINRSTT', a: 'INTERSECT' },
      { s: 'AAELNRRSSTV', a: 'TRANSVERSAL' }, { s: 'CDEGINNOOPRRS', a: 'CORRESPONDING' }
    ];
    let cur = 0, picks = [];
    const solved = new Set();
    root.appendChild(h('div', { class: 'pill fixed', text: 'Unscramble the words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the letters in order to get the correct word. Then give the meaning of the word.' }));
    const grow = h('div', { class: 'grow center-col stagger', style: 'gap:clamp(8px,1.6vh,18px)' });
    const pick = h('div', { class: 'wpick' });
    const card = h('div', { class: 'stagecard', style: 'flex:0 1 auto;justify-content:center;gap:clamp(12px,2.6vh,34px);padding:clamp(14px,3vh,40px)' });
    const slots = h('div', { class: 'tiles' });
    const tiles = h('div', { class: 'tiles' });
    const say = h('div', { class: 'saybox hidden' });
    card.append(slots, tiles, say);

    const pBtns = WORDS.map((w, k) => {
      const b = h('button', { class: 'btn', text: 'Word ' + (k + 1) });
      ctx.on(b, 'click', () => { cur = k; picks = []; paint(); });
      pick.appendChild(b); return b;
    });
    const t60 = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(t60, 'click', () => Engine.timer(60));
    pick.appendChild(t60);

    const sayIt = () => {
      const w = WORDS[cur].a.toLowerCase();
      say.innerHTML = '';
      const lb = h('button', { class: 'btn', text: '🔊 ' + w });
      ctx.on(lb, 'click', () => Sound.speak(w));
      say.append(lb, h('span', { text: '💬 What does it mean? Tell your partner.' }));
      say.classList.remove('hidden');
    };
    const paint = () => {
      const w = WORDS[cur];
      pBtns.forEach((b, k) => { b.classList.toggle('cur', k === cur); b.classList.toggle('solved', solved.has(k)); });
      slots.innerHTML = ''; tiles.innerHTML = '';
      const long = w.a.length > 9;
      slots.classList.toggle('long', long); tiles.classList.toggle('long', long);
      ctx.clearResult(card);
      for (let k = 0; k < w.a.length; k++) {
        const sl = h('div', { class: 'slot', text: picks[k] != null ? w.s[picks[k]] : '' });
        ctx.on(sl, 'click', () => { if (k < picks.length) { picks.splice(k, 1); paint(); } });
        slots.appendChild(sl);
      }
      w.s.split('').forEach((ch, k) => {
        const t = h('button', { class: 'tile' + (picks.indexOf(k) >= 0 ? ' used' : ''), text: ch });
        ctx.on(t, 'click', () => { if (picks.length < w.a.length && picks.indexOf(k) < 0) { picks.push(k); Sound.playEffect('click'); paint(); } });
        tiles.appendChild(t);
      });
      if (solved.has(cur)) sayIt(); else say.classList.add('hidden');
    };
    grow.append(pick, card);
    root.appendChild(grow);
    root.appendChild(ctx.buttons({
      check: () => {
        const w = WORDS[cur];
        const ok = picks.map(k => w.s[k]).join('') === w.a;
        ctx.markResult(card, ok);
        if (ok) { solved.add(cur); pBtns[cur].classList.add('solved'); sayIt(); }
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => {
        const w = WORDS[cur];
        const used = new Set(); picks = [];
        w.a.split('').forEach(ch => { const k = w.s.split('').findIndex((c, j) => c === ch && !used.has(j)); used.add(k); picks.push(k); });
        paint(); sayIt();
      },
      reset: () => { picks = []; paint(); }
    }));
    paint();
  }
});
