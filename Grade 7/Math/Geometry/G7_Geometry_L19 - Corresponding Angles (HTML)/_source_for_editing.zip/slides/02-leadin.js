/* L2 Split — PPT slide 2: Lead-in "Opening problem" (thang gỗ). Chọn số đo góc -> hiện lời giải gốc. */
Engine.register({
  id: 'leadin', section: 'Lead-in', title: 'Opening problem', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Opening problem' }));
    const sp = h('div', { class: 'split grow stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image14.png', { alt: 'A wooden ladder: the first bar makes a 60° angle with the vertical bar', class: 'hero-img' }), ctx.zoomHint());

    const right = h('div', {});
    const prob = h('div', { class: 'card', style: 'font-size:var(--f-small);line-height:1.3' });
    prob.innerHTML = 'Mr. Minh is constructing a wooden ladder by attaching the horizontal bars to the two vertical bars. He measures the angle between the first horizontal bar and a vertical bar. This angle is <b>60°</b>.<br>To ensure that all the horizontal bars are <b>parallel</b>, what should be the angle between the other horizontal bars and the vertical bar?';
    const opts = h('div', { class: 'optgrid', style: 'grid-template-columns:repeat(4,minmax(0,1fr));grid-auto-rows:auto' });
    const expl = h('div', { class: 'card hidden', style: 'font-size:var(--f-small);line-height:1.3;border:3px solid #DC2626;color:#B91C1C' });
    expl.innerHTML = 'The vertical bar acts as a <b>transversal</b> cutting through the horizontal bars. To ensure the horizontal bars are parallel, their <b>corresponding angles</b> must be equal.<br><b>Therefore, the angle between the other horizontal bars and the vertical bar should also be 60°.</b>';
    let solved = false;
    ['30°', '60°', '90°', '120°'].forEach(v => {
      const b = h('button', { class: 'opt', text: v });
      ctx.on(b, 'click', () => {
        if (solved) return;
        const ok = v === '60°';
        ctx.markResult(b, ok, { sound: true });
        if (ok) { solved = true; expl.classList.remove('hidden'); prob.classList.add('hidden'); Engine.score(1, 1); }
      });
      opts.appendChild(b);
    });
    const t30 = h('button', { class: 'btn', text: '⏱ 30s' });
    ctx.on(t30, 'click', () => Engine.timer(30));
    const show = h('button', { class: 'btn btn-show', text: '👁 Show answer' });
    ctx.on(show, 'click', () => {
      opts.querySelectorAll('.opt').forEach(b => { if (b.textContent === '60°') ctx.markResult(b, true); });
      solved = true; expl.classList.remove('hidden'); prob.classList.add('hidden');
    });
    const again = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(again, 'click', () => {
      solved = false; expl.classList.add('hidden'); prob.classList.remove('hidden');
      opts.querySelectorAll('.opt').forEach(b => ctx.clearResult(b));
    });
    right.append(prob, expl, h('div', { class: 'qline', text: 'The other angles should be…' }), opts, h('div', { class: 'btnrow' }, [t30, show, again]));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
