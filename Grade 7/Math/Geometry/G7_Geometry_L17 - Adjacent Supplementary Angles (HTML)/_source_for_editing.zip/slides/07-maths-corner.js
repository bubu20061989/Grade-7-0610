/* PPT slide 16 "Maths Corner": giữ nguyên văn 3 ý; hình 2 góc kề bù thành mô phỏng — đổi góc yOz, xOy tự đổi, tổng luôn 180°. */
Engine.register({
  id: 'maths-corner', section: 'Maths Corner', title: 'What is a pair of adjacent supplementary angles?', mech: 'sim',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' });
    const f = Lab.svg('0 0 600 300'), s = f.svg;
    const O = [300, 235];
    const sx = sv => { const e = document.createElementNS('http://www.w3.org/2000/svg', sv); return e; };
    const p1 = sx('path'); p1.setAttribute('class', 's1');
    const p2 = sx('path'); p2.setAttribute('class', 's2');
    s.append(p1, p2);
    Lab.ray(s, O[0], O[1], 180, 270); Lab.ray(s, O[0], O[1], 0, 270);
    const ry = sx('g'); s.appendChild(ry);
    const dot = sx('circle'); dot.setAttribute('cx', O[0]); dot.setAttribute('cy', O[1]); dot.setAttribute('r', 9); dot.setAttribute('fill', '#EF4444'); s.appendChild(dot);
    Lab.txt(s, 22, O[1] - 2, 'x', 40); Lab.txt(s, 580, O[1] - 2, 'z', 40); Lab.txt(s, O[0], O[1] + 42, 'O', 38);
    const ty = Lab.txt(s, 0, 0, 'y', 40);
    const t1 = Lab.txt(s, 0, 0, '', 30, 'lbl'), t2 = Lab.txt(s, 0, 0, '', 30, 'lbl');
    const read = h('div', { class: 'angread' });
    const r1 = h('span', { class: 'a1' }), r2 = h('span', { class: 'a2' }), rs = h('span', { class: 'sum', text: '' });
    read.append(r1, r2, rs);
    let cur = 30, raf = 0;
    const draw = (a) => {
      p1.setAttribute('d', Lab.sector(O[0], O[1], 92, a, 180));
      p2.setAttribute('d', Lab.sector(O[0], O[1], 120, 0, a));
      ry.innerHTML = ''; Lab.ray(ry, O[0], O[1], a, 215);
      const e = Lab.pt(O[0], O[1], 245, a); ty.setAttribute('x', e[0]); ty.setAttribute('y', e[1]);
      const m1 = Lab.pt(O[0], O[1], 135, (a + 180) / 2), m2 = Lab.pt(O[0], O[1], 160, a / 2);
      const A = Math.round(a);
      t1.setAttribute('x', m1[0]); t1.setAttribute('y', m1[1]); t1.textContent = (180 - A) + '°';
      t2.setAttribute('x', m2[0]); t2.setAttribute('y', Math.min(m2[1], O[1] - 22)); t2.textContent = A + '°';
      r1.innerHTML = '<span class="m">xOy</span> = ' + (180 - A) + '°';
      r2.innerHTML = '<span class="m">yOz</span> = ' + A + '°';
      rs.textContent = (180 - A) + '° + ' + A + '° = 180°';
    };
    const go = (to) => {
      cancelAnimationFrame(raf);
      const from = cur, t0 = performance.now(), D = document.body.classList.contains('nomotion') ? 1 : 650;
      const step = (t) => {
        if (!s.isConnected) return;
        const k = Math.min(1, (t - t0) / D), e = 1 - Math.pow(1 - k, 3);
        cur = from + (to - from) * e; draw(cur);
        if (k < 1) raf = requestAnimationFrame(step); else cur = to;
      };
      raf = requestAnimationFrame(step);
    };
    const btns = h('div', { class: 'angbtns' }, [h('span', { class: 'lbl', html: '<span class="m">yOz</span> =' })]);
    [30, 60, 90, 120, 150].forEach(v => {
      const b = h('button', { class: 'btn' + (v === 30 ? ' on' : ''), text: v + '°' });
      ctx.on(b, 'click', () => { btns.querySelectorAll('.btn').forEach(x => x.classList.toggle('on', x === b)); Sound.playEffect('click'); go(v); });
      btns.appendChild(b);
    });
    media.append(f, read, btns);
    draw(cur);

    const right = h('div', {});
    const B = [
      'Two angles are called <mark>adjacent</mark> if they share a common vertex and a common arm, and do not overlap each other.',
      'Two angles are called <mark>supplementary</mark> if the total measure of them is 180°.',
      'A pair of <mark>adjacent supplementary angles</mark> is formed when two straight lines intersect at a point. The two angles are located next to each other.'
    ];
    const bul = h('div', { class: 'bul' });
    B.forEach((t, k) => {
      const b = h('button', { class: 'b' }, [h('span', { class: 'k', text: String(k + 1) }), h('span', { class: 't', html: t })]);
      ctx.on(b, 'click', () => { bul.querySelectorAll('.b').forEach(x => x.classList.toggle('on', x === b)); Sound.speak(b.textContent.slice(1)); });
      bul.appendChild(b);
    });
    right.append(h('div', { class: 'qnavy', text: 'What is a pair of adjacent supplementary angles?' }), h('div', { class: 'note', text: '👆 Tap a card to listen · tap an angle to change yOz' }), bul);
    sp.append(media, right);
    root.appendChild(sp);
  },
  destroy() { }
});
