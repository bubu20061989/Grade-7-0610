/* PPT slide 19 "Consolidation": từ vựng (bấm nghe) · định nghĩa 2 loại góc (nói trước, bấm để kiểm — nội dung từ Maths Corner) · mẫu câu (karaoke). */
Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'speak',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const grow = h('div', { class: 'grow center-col' });
    const card = h('div', { class: 'stagecard consol stagger' });
    const V = [['vertex', 'c-blu'], ['side', 'c-yel'], ['adjacent', 'c-pur'], ['supplementary', 'c-grn']];
    const chips = h('div', { class: 'vchips' }, [h('span', { class: 'plabel', html: '<b>Vocabulary:</b>' })]);
    V.forEach(([w, c]) => { const b = h('button', { class: 'vchip ' + c, text: w }); ctx.on(b, 'click', () => { b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge'); Sound.speak(w); }); chips.appendChild(b); });
    const D = [
      ['Define adjacent angles', 'Two angles are called adjacent if they share a common vertex and a common arm, and do not overlap each other.'],
      ['Define supplementary angles', 'Two angles are called supplementary if the total measure of them is 180°.']
    ];
    const defs = h('div', { class: 'defrow' });
    D.forEach(([t, d]) => {
      const b = h('button', { class: 'defcard' }, [h('span', { class: 'dh', text: t }), h('span', { class: 'dt', text: d }), h('span', { class: 'dq', text: '🗣 Say it, then tap to check' })]);
      ctx.on(b, 'click', () => { b.classList.add('open'); Sound.speak(d); });
      defs.appendChild(b);
    });
    const S = 'Two angles are called supplementary if the total measure of them is 180°.';
    const spEl = h('div', { class: 'sp' });
    const words = S.split(' ').map(w => { const s = h('span', { class: 'w', text: w }); spEl.append(s, ' '); return s; });
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Say it together' });
    ctx.on(say, 'click', () => {
      say.disabled = true;
      Sound.speak(S, { onBoundary: (e) => { let n = 0; words.forEach(s => { s.classList.toggle('kara', e.charIndex >= n && e.charIndex < n + s.textContent.length + 1); n += s.textContent.length + 1; }); } })
        .then(() => { words.forEach(s => s.classList.remove('kara')); say.disabled = false; });
    });
    card.append(chips, defs, h('div', { class: 'plabel', html: '<b>Sentence pattern</b>' }), spEl, h('div', { class: 'sprow' }, [say, h('span', { class: 'note', text: '📖 Prepare the next lesson.' })]));
    grow.appendChild(card);
    root.appendChild(grow);
  }
});
