Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Adjacent Supplementary Angles', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const ill = h('div', { class: 'illus float-anim' }, [ctx.img('assets/img/image3.png', { alt: 'Geometry tools: compass, set square, board and book', zoom: false })]);
    ctx.on(ill, 'click', () => { ill.classList.remove('nudge'); void ill.offsetWidth; ill.classList.add('nudge'); Sound.speak('Adjacent supplementary angles'); });
    media.appendChild(ill);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 4 · Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Lesson 17:<br><em>Adjacent Supplementary</em> Angles';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths · 👆 Tap the picture" }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
