/* PPT slide 17 "C. Practice" — hàng 1 của bảng (hình xOy = 100°, zEt = 80°). Tách 2 slide để hình đủ to, chữ không đè.
   Ngân hàng từ gốc giữ đủ 4 từ ở cả 2 slide (từ thừa = thẻ nhiễu), chấm theo ô đích. */
Engine.register({
  id: 'practice-a', section: 'C. Practice', title: 'Practice a: xOy and zEt', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to describe the relationships of two angles in the figures. (1/2)' }));
    const W = ['supplementary', 'adjacent', 'vertex', 'arm'];
    const Z = [{ id: 'b1', accept: ['supplementary'] }];
    const dd = ctx.dragDrop({ items: W.map(w => ({ id: w, label: w })), zones: Z.map(z => ({ id: z.id, accept: z.accept, capacity: 1 })), renderZone: () => h('span', { class: 'dd-zone slot' }) });
    const f = Lab.svg('0 -20 560 270'), s = f.svg;
    const O = [215, 200];
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 80, 80, 180), 'class': 's1' }));
    Lab.ray(s, O[0], O[1], 180, 175); Lab.ray(s, O[0], O[1], 80, 185);
    s.appendChild(Lab.sv('circle', { cx: O[0], cy: O[1], r: 9, 'class': 'dot' }));
    let m = Lab.pt(O[0], O[1], 112, 132); Lab.txt(s, m[0] - 10, m[1], '100°', 30, 'lbl');
    Lab.txt(s, 22, O[1], 'x', 38); m = Lab.pt(O[0], O[1], 212, 80); Lab.txt(s, m[0] + 14, m[1], 'y', 38); Lab.txt(s, O[0] + 26, O[1] + 34, 'O', 34);
    const E = [365, 50];
    s.appendChild(Lab.sv('path', { d: Lab.sector(E[0], E[1], 58, -95, -15), 'class': 's2' }));
    s.appendChild(Lab.sv('path', { d: Lab.arc(E[0], E[1], 42, -95, -15), fill: 'none', stroke: '#0C4A6E', 'stroke-width': 3 }));
    const pz = Lab.pt(E[0], E[1], 190, -95);
    s.appendChild(Lab.sv('line', { x1: E[0], y1: E[1], x2: pz[0], y2: pz[1], 'class': 'ray' }));
    Lab.ray(s, E[0], E[1], -15, 175);
    m = Lab.pt(E[0], E[1], 92, -50); Lab.txt(s, m[0], m[1], '80°', 30, 'lbl');
    Lab.txt(s, E[0] - 26, E[1] - 6, 'E', 36); Lab.txt(s, pz[0] - 22, pz[1] - 6, 'z', 38); m = Lab.pt(E[0], E[1], 200, -15); Lab.txt(s, m[0], m[1] - 30, 't', 38);
    const p = h('div', { class: 'para pstate' });
    p.innerHTML = 'The two angles <span class="m">xOy</span> and <span class="m">zEt</span> are <span data-s></span> since 100° added to 80° is 180°.';
    p.querySelector('[data-s]').replaceWith(dd.zoneEls.b1);
    root.append(h('div', { class: 'pboard stagger' }, [h('div', { class: 'pfig' }, [f]), p]), dd.tray);
    root.appendChild(ctx.buttons({ check: () => Lab.ddCheck(ctx, dd, Z), show: () => { dd.show(); Lab.ddClear(ctx, dd); }, reset: () => { dd.reset(); Lab.ddClear(ctx, dd); } }));
  }
});
