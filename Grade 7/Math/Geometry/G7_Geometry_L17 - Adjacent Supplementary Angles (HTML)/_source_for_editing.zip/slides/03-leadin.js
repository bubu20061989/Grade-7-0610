/* PPT slide 8-9 gộp: bài toán mở đầu (slide 8) + lời giải 180 – 150 = 30° (slide 9) hiện sau khi Check/Show. */
Engine.register({
  id: 'leadin', section: 'Lead-in', title: 'Opening problem: the wood tabletop', mech: 'numpad',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const sp = h('div', { class: 'split leadsplit stagger' });
    const disp = h('span', { class: 'npdisp' });
    const pad = Lab.numpad(ctx, disp, 3);
    const media = h('div', { class: 'media' });
    /* màn dọc: bàn phím chuyển sang cột chữ để ảnh giữ được chiều cao; xoay màn hình -> dựng lại slide */
    const mq = window.matchMedia('(max-aspect-ratio: 1/1)');
    ctx.on(mq, 'change', () => Engine.go(Engine.idx, 'jump'));
    const ans = [h('div', { class: 'ansline' }, [h('span', { text: '? =' }), disp]), pad.el];
    media.append(ctx.img('assets/img/image16.png', { alt: 'Wood tabletop: the trapezoid angle is 150°, the triangle angle is ?', class: 'hero-img' }), ctx.zoomHint());
    if (!mq.matches) media.append(...ans);
    const prob = h('div', { class: 'probtxt' });
    prob.innerHTML = '<span class="ptag">Opening problem</span><br>A carpenter wants to make a wood tabletop. He tries to attach a triangular piece and a trapezoidal piece together. The angle at the base of the trapezoid is 150°. What should be the measure of the angle at the base of the triangular piece?';
    const bub = h('div', { class: 'bubble hide' });
    bub.innerHTML = 'The angle at the base of the triangular piece is<br>180 – 150 = 30°';
    const right = h('div', {}, [prob].concat(mq.matches ? ans : [], [h('div', { class: 'leadrow' }, [h('div', { class: 'boy' }, [ctx.img('assets/img/image15.png', { alt: 'A boy thinking', zoom: false })]), bub])]));
    sp.append(media, right);
    root.appendChild(sp);
    root.appendChild(ctx.buttons({
      check: () => {
        const ok = pad.get() === '30';
        ctx.markResult(disp, ok);
        if (ok) bub.classList.remove('hide');
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { pad.set('30'); bub.classList.remove('hide'); },
      reset: () => { pad.clear(); bub.classList.add('hide'); }
    }));
  }
});
