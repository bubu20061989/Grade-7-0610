/* PPT slide 18 "D. Writing" (2/2): lời giải bước 3-4 + kết luận (hiện khi làm đúng / Show answer). */
Engine.register({
  id: 'writing-b', section: 'D. Writing', title: 'Writing: find angle xOy (2/2)', mech: 'choose',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to complete the following problems. 👆 Tap a blank to change the word.' }));
    const f = Lab.svg('0 0 620 230'), s = f.svg, O = [300, 175];
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 85, 30, 180), 'class': 's1' }));
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 115, 0, 30), 'class': 's2' }));
    s.appendChild(Lab.sv('path', { d: Lab.arc(O[0], O[1], 99, 0, 30), fill: 'none', stroke: '#0C4A6E', 'stroke-width': 3 }));
    Lab.ray(s, O[0], O[1], 180, 255); Lab.ray(s, O[0], O[1], 0, 255); Lab.ray(s, O[0], O[1], 30, 230);
    s.appendChild(Lab.sv('circle', { cx: O[0], cy: O[1], r: 9, 'class': 'dot' }));
    let m = Lab.pt(O[0], O[1], 165, 14); Lab.txt(s, m[0], m[1] - 4, '30°', 34, 'lbl');
    Lab.txt(s, 22, O[1], 'x', 42); Lab.txt(s, 598, O[1], 'z', 42); Lab.txt(s, O[0], O[1] + 38, 'O', 36);
    m = Lab.pt(O[0], O[1], 252, 30); Lab.txt(s, m[0] + 8, m[1] - 8, 'y', 42);
    const M = (t) => '<span class="m">' + t + '</span>';
    const why = (parts) => { const d = h('div', { class: 'why' }); parts.forEach(p => d.append(typeof p === 'string' ? document.createTextNode(p) : p)); return d; };
    const step = (eqHtml, w) => h('div', { class: 'wstep' }, [h('div', { class: 'eq', html: eqHtml }), w]);
    const BANK = ['supplementary', 'right-hand side', 'sign'];
    const recap = h('div', { class: 'recap', html: M('xOy') + ' + ' + M('yOz') + ' = 180°<br>' + M('xOy') + ' + 30° = 180°' });
    const c2 = Lab.cyc(ctx, BANK, 1), c3 = Lab.cyc(ctx, BANK, 2);
    const concl = h('div', { class: 'concl off', html: 'In conclusion, the measure of angle ' + M('xOy') + ' is <span class="red">150°</span>.' });
    const box = h('div', { class: 'solbox' }, [h('div', { class: 'stitle', text: 'Solution (continued)' }),
      step(M('xOy') + ' = 180° – 30°', why(['Move 30° to the ', c2, ' and change its ', c3, '.'])),
      step(M('xOy') + ' = <span class="red">150°</span>', why(['Simplify the right-hand side.'])), concl]);
    root.appendChild(h('div', { class: 'split stagger' }, [h('div', {}, [box]), h('div', { class: 'media' }, [f, recap])]));
    const all = [c2, c3];
    root.appendChild(ctx.buttons({
      check: () => { let c = 0; all.forEach(w => { if (w.__check()) c++; }); if (c === 2) { concl.classList.remove('off'); Engine.confetti('star'); } return { correct: c, total: 2 }; },
      show: () => { all.forEach(w => w.__show()); concl.classList.remove('off'); },
      reset: () => { all.forEach(w => w.__reset()); concl.classList.add('off'); }
    }));
  }
});
