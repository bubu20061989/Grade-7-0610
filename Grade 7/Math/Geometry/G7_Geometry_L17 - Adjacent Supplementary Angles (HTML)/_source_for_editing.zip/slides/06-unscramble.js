/* PPT slide 15 "A. Vocabulary": 6 từ xáo chữ (giữ đúng chuỗi chữ cái của PPT), làm lần lượt từng từ. */
Engine.register({
  id: 'unscramble', section: 'Vocabulary', title: 'Unscramble the words', mech: 'unscramble',
  render(root, ctx) {
    const W = [['AMR', 'ARM'], ['EERTVX', 'VERTEX'], ['AACDEJNT', 'ADJACENT'], ['CEEINRSTT', 'INTERSECT'], ['AGHIRSTT', 'STRAIGHT'], ['AEELMNPPRSTUY', 'SUPPLEMENTARY']];
    root.appendChild(h('div', { class: 'pill fixed', text: 'A. Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Unscramble the letters to get the correct words and then give the meaning of the words.' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const card = h('div', { class: 'stagecard', style: 'width:min(100%,1600px)' });
    const nav = h('div', { class: 'wordnav' });
    const bP = h('button', { class: 'btn', text: '◀' });
    const dots = h('div', { class: 'dots' });
    const bN = h('button', { class: 'btn', text: '▶' });
    nav.append(bP, dots, bN);
    const uns = h('div', { class: 'uns' });
    card.append(nav, uns);
    grow.appendChild(card);
    root.appendChild(grow);

    let i = 0, slots = [], tiles = [], fill = [], say;
    const solved = {};
    const paint = () => {
      const [scr, ans] = W[i];
      uns.innerHTML = '';
      uns.style.setProperty('--lsz', Math.min(1.25, 13.5 / ans.length).toFixed(2));
      const sl = h('div', { class: 'slots' }), tl = h('div', { class: 'tiles' });
      fill = new Array(ans.length).fill(-1);
      slots = ans.split('').map((_, k) => {
        const s = h('button', { class: 'lt-slot', 'aria-label': 'letter ' + (k + 1) });
        ctx.on(s, 'click', () => { if (fill[k] < 0) return; tiles[fill[k]].classList.remove('used'); fill[k] = -1; s.textContent = ''; s.classList.remove('has'); ctx.clearResult(sl); });
        sl.appendChild(s); return s;
      });
      tiles = scr.split('').map((ch, k) => {
        const t = h('button', { class: 'lt-tile', text: ch });
        ctx.on(t, 'click', () => {
          const e = fill.indexOf(-1); if (e < 0) return;
          Sound.playEffect('click');
          fill[e] = k; slots[e].textContent = ch; slots[e].classList.add('has'); t.classList.add('used');
        });
        tl.appendChild(t); return t;
      });
      this._sl = sl;
      say = h('div', { class: 'say', text: '' });
      uns.append(h('div', { class: 'scr', text: (i + 1) + ' / ' + W.length }), sl, tl, say);
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (solved[k] ? 'done' : '') })));
      uns.classList.remove('pop-in'); void uns.offsetWidth; uns.classList.add('pop-in');
    };
    const word = () => fill.map(k => k < 0 ? '' : W[i][0][k]).join('');
    const showWord = () => {
      const [scr, ans] = W[i]; const used = {};
      fill = ans.split('').map(ch => { for (let k = 0; k < scr.length; k++) if (scr[k] === ch && !used[k]) { used[k] = 1; return k; } return -1; });
      tiles.forEach((t, k) => t.classList.toggle('used', !!used[k]));
      slots.forEach((s, k) => { s.textContent = ans[k]; s.classList.add('has'); });
    };
    ctx.on(bP, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bN, 'click', () => { i = (i + 1) % W.length; paint(); });
    const row = ctx.buttons({
      check: () => {
        const ok = word() === W[i][1];
        ctx.markResult(this._sl, ok);
        if (ok) { solved[i] = 1; say.textContent = '🗣 ' + W[i][1].toLowerCase() + ' — now give the meaning of the word.'; Sound.speak(W[i][1].toLowerCase()); }
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { showWord(); ctx.clearResult(this._sl); say.textContent = '🗣 ' + W[i][1].toLowerCase() + ' — give the meaning of the word.'; },
      reset: () => paint()
    });
    const bT = h('button', { class: 'btn', text: '⏱ 30s' });
    ctx.on(bT, 'click', () => Engine.timer(30));
    row.appendChild(bT);
    root.appendChild(row);
    paint();
  },
  destroy() { Engine.timer(0); }
});
