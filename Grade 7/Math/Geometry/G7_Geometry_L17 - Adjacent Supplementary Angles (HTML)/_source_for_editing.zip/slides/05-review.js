/* PPT slide 14 "Review": bảng 4 từ + 4 hình -> học sinh kéo từ vào đúng hình */
Engine.register({
  id: 'review', section: 'Vocabulary', title: 'Review: match the words', mech: 'match',
  render(root, ctx) {
    const WORDS = ['vertex', 'side', 'adjacent', 'supplementary'];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its picture' }));
    const dd = ctx.dragDrop({
      items: WORDS.map(w => ({ id: w, label: w })),
      zones: WORDS.map(w => ({ id: 'z-' + w, accept: [w], capacity: 1 })),
      renderZone: () => h('div', { class: 'dd-zone slot' })
    });
    const grid = h('div', { class: 'revgrid stagger' });
    ctx.shuffle(WORDS).forEach(w => grid.appendChild(h('div', { class: 'revcell' }, [Lab.vocabFig(w), dd.zoneEls['z-' + w]])));
    root.append(grid, dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
