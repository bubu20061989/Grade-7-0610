/* PPT slide 10-13: 4 thẻ từ vựng. Hình vẽ lại bằng SVG theo đúng hình gốc (tam giác đỉnh đỏ, tam giác các cạnh màu, 2 góc kề, 2 góc bù). */
Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary flashcards', mech: 'flashcard',
  render(root, ctx) {
    const W = [
      { w: 'vertex', pos: '(noun)', ipa: '/ˈvɜːteks/', c: 'c-blu', def: 'a point where two or more sides meet.', ex: '<b>Example:</b> A triangle has three <b>vertices</b>.' },
      { w: 'side', pos: '(noun)', ipa: '/saɪd/', c: 'c-yel', def: 'a straight line that forms part of a shape.', ex: '<b>Example:</b> A triangle has three <b>sides</b>.' },
      { w: 'adjacent', pos: '(adjective)', ipa: '/əˈdʒeɪsənt/', c: 'c-pur', def: 'next to or sharing a common side or vertex.', ex: '<b>Example:</b> These two angles are <b>adjacent</b>.' },
      { w: 'supplementary', pos: '(adjective)', ipa: '/ˌsʌplɪˈmentəri/', c: 'c-grn', def: 'adding up to 180°.', ex: '<b>Example:</b> The two angles are <b>supplementary</b>.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    const dots = h('div', { class: 'dots fixed' });
    grow.append(h('div', { class: 'fc-wrap fill-w center-col' }, [box]));
    root.appendChild(grow);
    root.appendChild(dots);

    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.append(h('div', { class: 'vimg' }, [Lab.vocabFig(v.w)]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: v.pos }), h('div', { class: 'vipa', text: v.ipa })]));
      const ex = h('div', { class: 'vex' }); ex.innerHTML = v.ex;
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def }), ex);
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; Engine.toast('🎉 All 4 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    this._cheered = false;
    paint();
  }
});
