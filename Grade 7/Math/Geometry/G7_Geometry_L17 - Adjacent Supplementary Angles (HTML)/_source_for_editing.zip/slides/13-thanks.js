Engine.register({
  id: 'thanks', section: 'Wrap-up', title: 'Thanks!', mech: 'summary', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const stars = Engine.stars || 0;
    const done = Object.keys(Engine.done || {}).length;
    const media = h('div', { class: 'cover-media' }, [h('div', { class: 'starbig' }, [
      h('div', { class: 'num float-anim', text: '⭐ ' + stars }),
      h('div', { class: 'lbl', text: stars ? 'stars today — well done!' : (done > 2 ? 'Keep practising — you can do it!' : 'Ready to try the activities?') })
    ])]);
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Thanks!</em>';
    txt.append(t, h('div', { class: 'quote', text: '“Don’t be afraid of errors; even trial and error leads to discovery!”' }));
    const wrong = (Engine.wrongList() || []).filter(id => Engine.slides.some(s => s.id === id));
    if (wrong.length) {
      txt.appendChild(h('div', { class: 'hero-sub', text: "Let's review:" }));
      const row = h('div', { class: 'btnrow', style: 'justify-content:flex-start' });
      wrong.slice(0, 4).forEach(id => { const s = Engine.slides.find(x => x.id === id); const b = h('button', { class: 'btn', text: s.title }); ctx.on(b, 'click', () => Lab.goTo(id)); row.appendChild(b); });
      txt.appendChild(row);
    } else if (done > 2) {
      txt.appendChild(h('div', { class: 'hero-sub', text: 'You know adjacent supplementary angles. Great job! 🎉' }));
    }
    const again = h('button', { class: 'btn btn-primary', text: '↺ Start again' });
    ctx.on(again, 'click', () => Engine.go(0, 'jump'));
    txt.appendChild(h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [again]));
    cov.append(media, txt);
    root.appendChild(cov);
    if (stars) ctx.timeout(() => Engine.confetti('star'), 500);
  }
});
