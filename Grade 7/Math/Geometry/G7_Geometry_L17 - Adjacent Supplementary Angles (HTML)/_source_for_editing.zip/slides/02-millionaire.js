/* PPT slide 2-7: trò "Who's the Millionaire?" ôn bài cũ (3D shapes). Đáp án lấy từ trigger Win/Lose của PPT gốc.
   Nhạc gốc: media1 = nhạc câu hỏi, media2 = Final Answer, media3 = Win, media4 = Lose. */
Engine.register({
  id: 'millionaire', section: 'Warm-up', title: "Who's the Millionaire?", mech: 'quiz', bg: 'show',
  render(root, ctx) {
    const Q = [
      { q: 'What do we call a 3D shape with 2 triangular bases and 3 rectangular faces?', o: ['Triangle', 'Hexagon', 'Triangular prism', 'Parallelogram'], a: 2 },
      { q: 'Which object below is a quadrilateral prism?', o: ['Pencilcase', 'Diamond', 'Ring', 'Chair'], a: 0 },
      { q: 'What is the point that is opposite the base of a shape called?', o: ['Edge', 'Vertex', 'Volume', 'Total area'], a: 1 },
      { q: 'What is the farthest point of something called?', o: ['Volume', 'Surface area', 'Total area', 'Edge'], a: 3 },
      { q: 'What is the amount of two-dimensional space that an object occupies called?', o: ['Surface area', 'Total area', 'Volume', 'Edge'], a: 1 }
    ];
    const L = ['A', 'B', 'C', 'D'];
    const wrap = h('div', { class: 'mil stagger' });
    const main = h('div', { class: 'mil-main' });
    const ladder = h('div', { class: 'ladder' });
    const rungs = Q.map((_, i) => { const r = h('div', { class: 'rung' }, [h('span', { class: 'n', text: String(i + 1) }), h('span', { text: '⭐ ' + (i + 1) })]); ladder.appendChild(r); return r; });
    wrap.append(main, ladder);
    root.appendChild(wrap);
    const row = h('div', { class: 'btnrow fixed' });
    root.appendChild(row);

    let qi = 0, locked = false, right = 0;
    const res = [];
    const btn = (cls, text, fn) => { const b = h('button', { class: 'btn ' + cls, text }); ctx.on(b, 'click', fn); return b; };

    const start = () => {
      main.innerHTML = ''; row.innerHTML = '';
      document.body.classList.remove('mil-play');
      main.append(h('div', { class: 'mil-space' }), h('div', { class: 'mil-sub mil-banner', text: '5 questions about 3D shapes · Teams take turns!' }));
      row.append(btn('btn-primary pulse', '▶ Start the game', () => ask(0)));
    };
    const ask = (i) => {
      qi = i; locked = false;
      document.body.classList.add('mil-play');
      rungs.forEach((r, k) => r.classList.toggle('now', k === i));
      main.innerHTML = ''; row.innerHTML = '';
      const it = Q[i];
      const qb = h('div', { class: 'mil-q pop-in' }); qb.innerHTML = '<b>Question ' + (i + 1) + ':</b> ' + it.q;
      const grid = h('div', { class: 'mil-opts' });
      const note = h('div', { class: 'mil-note', text: 'Choose your final answer' });
      const opts = it.o.map((o, k) => {
        const b = h('button', { class: 'mil-opt' }, [h('span', { class: 'lt', text: L[k] + '.' }), h('span', { text: o })]);
        ctx.on(b, 'click', () => pick(k, opts, note));
        grid.appendChild(b); return b;
      });
      main.append(qb, grid, note);
      row.append(btn('', '▶ Play music', () => Sound.playEffect('q')), btn('', '⏱ 30s', () => Engine.timer(30)));
      Sound.playEffect('q');
    };
    const pick = (k, opts, note) => {
      if (locked) return;
      locked = true;
      Engine.timer(0);
      const it = Q[qi];
      opts[k].classList.add('sel');
      note.textContent = 'Final answer: ' + L[k] + '!';
      Sound.playEffect('final');
      ctx.timeout(() => {
        opts[k].classList.remove('sel');
        opts.forEach((b, j) => { if (j !== k && j !== it.a) b.classList.add('dim'); });
        opts[it.a].classList.add('right');
        const ok = k === it.a;
        res[qi] = ok;
        if (ok) { right++; ctx.markResult(opts[k], true, { shake: false }); Sound.playEffect('win'); Engine.confetti('star'); note.textContent = 'Correct! ' + it.o[it.a]; }
        else { opts[k].classList.add('wrong'); ctx.markResult(opts[k], false); Sound.playEffect('lose'); note.textContent = 'The answer is ' + L[it.a] + '. ' + it.o[it.a]; }
        rungs[qi].classList.remove('now'); rungs[qi].classList.add(ok ? 'won' : 'lost');
        row.innerHTML = '';
        row.append(qi < Q.length - 1 ? btn('btn-primary', 'Next question ▶', () => ask(qi + 1)) : btn('btn-primary', '🏆 Results', finish));
      }, 2600);
    };
    const finish = () => {
      main.innerHTML = ''; row.innerHTML = '';
      main.append(h('div', { class: 'mil-logo pop-in', text: right + ' / ' + Q.length }),
        h('div', { class: 'mil-sub', text: right === Q.length ? 'Amazing! You are a Millionaire!' : (right >= 3 ? 'Great job! Keep going!' : 'Good try! Let’s learn more today.') }));
      Engine.score(right, Q.length);
      row.append(btn('btn-reset', '↺ Play again', reset), btn('btn-primary', 'Next ▶', () => Engine.next()));
    };
    const reset = () => {
      Sound.stopAll(); Engine.timer(0); right = 0; res.length = 0;
      rungs.forEach(r => r.classList.remove('now', 'won', 'lost'));
      start();
    };
    start();
  },
  destroy() { Engine.timer(0); document.body.classList.remove('mil-play'); }
});
