/* PPT slide 18 "D. Writing" (1/2): hình + đề + lời giải bước 1-2. Ngân hàng từ gốc: supplementary, right-hand side, sign.
   Tách 2 slide để hình đủ to và chữ lời giải không phải co nhỏ. */
Engine.register({
  id: 'writing-a', section: 'D. Writing', title: 'Writing: find angle xOy (1/2)', mech: 'choose',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to complete the following problems. 👆 Tap a blank to change the word.' }));
    const f = Lab.svg('0 0 620 230'), s = f.svg, O = [300, 175];
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 85, 30, 180), 'class': 's1' }));
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 115, 0, 30), 'class': 's2' }));
    s.appendChild(Lab.sv('path', { d: Lab.arc(O[0], O[1], 99, 0, 30), fill: 'none', stroke: '#0C4A6E', 'stroke-width': 3 }));
    Lab.ray(s, O[0], O[1], 180, 255); Lab.ray(s, O[0], O[1], 0, 255); Lab.ray(s, O[0], O[1], 30, 230);
    s.appendChild(Lab.sv('circle', { cx: O[0], cy: O[1], r: 9, 'class': 'dot' }));
    let m = Lab.pt(O[0], O[1], 165, 14); Lab.txt(s, m[0], m[1] - 4, '30°', 34, 'lbl');
    Lab.txt(s, 22, O[1], 'x', 42); Lab.txt(s, 598, O[1], 'z', 42); Lab.txt(s, O[0], O[1] + 38, 'O', 36);
    m = Lab.pt(O[0], O[1], 252, 30); Lab.txt(s, m[0] + 8, m[1] - 8, 'y', 42);
    const M = (t) => '<span class="m">' + t + '</span>';
    const why = (parts) => { const d = h('div', { class: 'why' }); parts.forEach(p => d.append(typeof p === 'string' ? document.createTextNode(p) : p)); return d; };
    const step = (eqHtml, w) => h('div', { class: 'wstep' }, [h('div', { class: 'eq', html: eqHtml }), w]);
    const BANK = ['supplementary', 'right-hand side', 'sign'];
    const given = h('div', { class: 'givenbox' });
    given.innerHTML = 'The diagram on the left includes a pair of adjacent supplementary angles <span class="m">xOy</span> and <span class="m">yOz</span>. Given that the measure of angle <span class="m">yOz</span> is 30°, find the measure of angle <span class="m">xOy</span>.';
    const c1 = Lab.cyc(ctx, BANK, 0);
    const box = h('div', { class: 'solbox' }, [h('div', { class: 'stitle', text: 'Solution' }),
      h('div', { class: 'lead', html: 'Since ' + M('xOy') + ' and ' + M('yOz') + ' are supplementary adjacent,' }),
      step(M('xOy') + ' + ' + M('yOz') + ' = 180°', why(['The sum of two ', c1, ' adjacent angles is 180°.'])),
      step(M('xOy') + ' + 30° = 180°', why(['Plug ', h('span', { class: 'm', text: 'yOz' }), ' = 30°.']))]);
    root.appendChild(h('div', { class: 'split stagger' }, [h('div', { class: 'media' }, [f, given]), h('div', {}, [box])]));
    root.appendChild(ctx.buttons({
      check: () => { const ok = c1.__check(); return { correct: ok ? 1 : 0, total: 1 }; },
      show: () => c1.__show(),
      reset: () => c1.__reset()
    }));
  }
});
