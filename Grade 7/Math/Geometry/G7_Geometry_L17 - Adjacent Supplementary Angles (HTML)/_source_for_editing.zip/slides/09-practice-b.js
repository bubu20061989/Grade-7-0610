/* PPT slide 17 "C. Practice" — hàng 2 của bảng (2 góc kề xOy, yOz). */
Engine.register({
  id: 'practice-b', section: 'C. Practice', title: 'Practice b: xOy and yOz', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to describe the relationships of two angles in the figures. (2/2)' }));
    const W = ['supplementary', 'adjacent', 'vertex', 'arm'];
    const Z = [{ id: 'b1', accept: ['adjacent'] }, { id: 'b2', accept: ['vertex'] }, { id: 'b3', accept: ['arm'] }];
    const dd = ctx.dragDrop({ items: W.map(w => ({ id: w, label: w })), zones: Z.map(z => ({ id: z.id, accept: z.accept, capacity: 1 })), renderZone: () => h('span', { class: 'dd-zone slot' }) });
    const f = Lab.svg('0 0 560 250'), s = f.svg, O = [210, 205];
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 105, 35, 150), 'class': 's1' }));
    s.appendChild(Lab.sv('path', { d: Lab.sector(O[0], O[1], 135, 3, 35), 'class': 's2' }));
    Lab.ray(s, O[0], O[1], 150, 210); Lab.ray(s, O[0], O[1], 35, 255); Lab.ray(s, O[0], O[1], 3, 300);
    s.appendChild(Lab.sv('circle', { cx: O[0], cy: O[1], r: 9, 'class': 'dot' }));
    let m = Lab.pt(O[0], O[1], 238, 150); Lab.txt(s, m[0], m[1] - 10, 'x', 38);
    m = Lab.pt(O[0], O[1], 282, 35); Lab.txt(s, m[0], m[1], 'y', 38);
    m = Lab.pt(O[0], O[1], 328, 3); Lab.txt(s, m[0], m[1], 'z', 38);
    Lab.txt(s, O[0], O[1] + 36, 'O', 34);
    const p = h('div', { class: 'para pstate' });
    p.innerHTML = 'The two angles <span class="m">xOy</span> and <span class="m">yOz</span> are <span data-s="b1"></span> since they share a common <span data-s="b2"></span> O and a common <span data-s="b3"></span> <span class="m">Oy</span>, and do not overlap each other.';
    p.querySelectorAll('[data-s]').forEach(e => e.replaceWith(dd.zoneEls[e.dataset.s]));
    root.append(h('div', { class: 'pboard stagger' }, [h('div', { class: 'pfig' }, [f]), p]), dd.tray);
    root.appendChild(ctx.buttons({ check: () => Lab.ddCheck(ctx, dd, Z), show: () => { dd.show(); Lab.ddClear(ctx, dd); }, reset: () => { dd.reset(); Lab.ddClear(ctx, dd); } }));
  }
});
