(function (global) {
  'use strict';
  if (global.Lab) return;
  var NS = 'http://www.w3.org/2000/svg';
  var Lab = {};
  global.Lab = Lab;

  function sv(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  Lab.sv = sv;
  function dv(cls, txt) { var d = document.createElement('div'); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  Lab.dv = dv;

  /* ===== 1. TẦNG NỀN THEO PHẦN HỌC (nằm ngoài .slide) ===== */
  /* Mỗi SECTION tự nhận 1 bảng màu theo thứ tự xuất hiện -> đổi bài không phải sửa gì.
     Chỉ định tay: Lab.PAL = { 'Tên section': ['#..','#..','#..'] }. */
  var POOL = [
    ['#5EEAD4', '#93C5FD', '#A7F3D0'],
    ['#7DD3FC', '#BAE6FD', '#5EEAD4'],
    ['#34D399', '#A3E635', '#A7F3D0'],
    ['#2DD4BF', '#34D399', '#93C5FD'],
    ['#A5B4FC', '#93C5FD', '#C7D2FE'],
    ['#FCD34D', '#A3E635', '#FDE68A']
  ];
  var palMap = null;
  function palFor(key) {
    if (!palMap) {
      palMap = {};
      var seen = [];
      Engine.slides.forEach(function (s) { var k = s.section || '-'; if (seen.indexOf(k) < 0) seen.push(k); });
      seen.forEach(function (k, i) { palMap[k] = POOL[i % POOL.length]; });
    }
    return (Lab.PAL && Lab.PAL[key]) || palMap[key] || POOL[0];
  }
  function rgba(hex, a) {
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.slice(0,2),16) + ',' + parseInt(h.slice(2,4),16) + ',' + parseInt(h.slice(4,6),16) + ',' + a + ')';
  }

  /* Khung gần trung tính, màu CHỈ ở 2 góc, giữa màn hình sạch tuyệt đối:
     không có gì nằm sau vùng chữ -> mắt không bị nhiễu. */
  function sceneD(c) {
    var sc = dv('scene');
    sc.style.background = 'linear-gradient(180deg,#FFFFFF 0%,#F7FBF9 56%,#EEF6F2 100%)';
    var tr = dv('deco');
    tr.style.right = '-16vw'; tr.style.top = '-34vh'; tr.style.width = '62vw'; tr.style.height = '62vw';
    tr.style.borderRadius = '50%'; tr.style.opacity = '1';
    tr.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[0], .26) + ' 0%,' + rgba(c[0], 0) + ' 66%)';
    sc.appendChild(tr);
    var bl = dv('deco');
    bl.style.left = '-20vw'; bl.style.bottom = '-32vh'; bl.style.width = '56vw'; bl.style.height = '56vw';
    bl.style.borderRadius = '50%'; bl.style.opacity = '1';
    bl.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[2], .22) + ' 0%,' + rgba(c[2], 0) + ' 66%)';
    sc.appendChild(bl);
    return sc;
  }

  var STYLES = { D: sceneD };
  Lab.bgStyle = 'D';
  function buildScene(key) {
    if (Lab.scene) return Lab.scene(key);                /* L17: cảnh nền gốc của PPT (mục 6) */
    return (STYLES[Lab.bgStyle] || sceneD)(palFor(key));
  }

  var bgHost = null, curScene = null, curKey = null;
  function applyScene() {
    if (!bgHost) {
      bgHost = document.getElementById('bgLayer');
      if (!bgHost) { bgHost = dv(''); bgHost.id = 'bgLayer'; document.body.insertBefore(bgHost, document.body.firstChild); }
    }
    var def = Engine.slides[Engine.idx];
    var key = (def && def.section) || '-';
    if (def && def.bg) key = def.bg + ':' + key;          /* L17: slide tự chọn cảnh nền (cover/show) */
    if (key === curKey && !Lab.__force) return;
    Lab.__force = false;
    curKey = key;
    var next = buildScene(key);
    bgHost.appendChild(next);
    void next.offsetWidth;
    next.classList.add('on');
    var old = curScene;
    curScene = next;
    if (old) setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 700);
  }

  /* ===== 2. fitStage() — lưới an toàn chống vỡ =====
     Dùng biến CSS, KHÔNG transform:scale() lên .slide: tổ tiên có transform
     sẽ phá position:fixed của #dragLayer. */
  var fitRaf = 0, fitTries = 0;
  function curSlide() { return document.querySelector('.stage > .slide'); }
  function minFit() {
    var fs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--fs-scale')) || 1;
    return Math.min(1, 0.72 / fs);
  }
  /* Sàn CHÍNH XÁC cho từng slide: đo cỡ chữ NHỎ NHẤT đang hiện ở --fit = 1, rồi cho co
     đúng tới lúc cỡ đó chạm ngưỡng đọc được từ cuối lớp (1/40 chiều cao màn hình, tối
     thiểu 22px). Bỏ qua chữ trong <svg> vì nó co theo khung hình, không theo --fit. */
  function textFloor(slide) {
    var th = Math.max(22, global.innerHeight / 40);
    var min = Infinity;
    var nodes = slide.querySelectorAll('*');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.ownerSVGElement || n.tagName.toLowerCase() === 'svg') continue;
      var hasText = false;
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3 && c.nodeValue.trim()) { hasText = true; break; }
      }
      if (!hasText) continue;
      var r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      var fsz = parseFloat(getComputedStyle(n).fontSize);
      if (fsz && fsz < min) min = fsz;
    }
    if (!isFinite(min) || !th) return 0.45;
    /* co hệ số f => chữ nhỏ nhất thành min*f; cần min*f >= th => f >= th/min */
    return Math.max(0.45, Math.min(1, (th * 1.06) / min));   // +6% biên an toàn
  }
  function fitNow() {
    fitRaf = 0;
    var slide = curSlide();
    if (!slide) return;
    var lo = slide.__floor != null ? slide.__floor : minFit();
    var cur = parseFloat(slide.style.getPropertyValue('--fit'));
    if (!(cur > 0)) cur = 1;
    var guard = 0;
    /* Vòng lặp ĐỒNG BỘ: đọc scrollHeight ép trình duyệt tính lại layout ngay, nên slide
       vừa vào là đã vừa khung — không nhấp nháy 1-2 khung hình. */
    while (slide.scrollHeight > slide.clientHeight + 1 && cur > lo + 0.001 && guard++ < 16) {
      cur = Math.max(lo, cur - 0.05);
      slide.style.setProperty('--fit', cur.toFixed(3));
    }
    fitTries = guard;
  }
  function scheduleFit() {
    if (fitRaf) return;
    fitRaf = global.requestAnimationFrame ? requestAnimationFrame(fitNow) : setTimeout(fitNow, 16);
  }
  function resetFit() {
    var slide = curSlide();
    if (slide) {
      slide.style.setProperty('--fit', '1');
      slide.__floor = textFloor(slide);
    }
    fitTries = 0;
    fitNow();
    scheduleFit();
  }
  Lab.setBgStyle = function (k) { Lab.bgStyle = k; Lab.__force = true; applyScene(); };
  Lab.fit = scheduleFit;
  Lab.refit = resetFit;

  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };

  /* ===== 3. NÚT LỚP HỌC: Tập trung / Giảm chuyển động ===== */
  function addNavButtons() {
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#focusBtn')) return;
    var anchor = nav.querySelector('#fullscreenBtn') || nav.querySelector('#tlockBtn');
    var mk = function (id, icon, title, cls) {
      var b = document.createElement('button');
      b.className = 'iconbtn'; b.id = id; b.textContent = icon; b.title = title;
      b.addEventListener('click', function () {
        var on = document.body.classList.toggle(cls);
        b.classList.toggle('on', on);
        try { sessionStorage.setItem('pref:' + cls, on ? '1' : '0'); } catch (e) { }
        Engine.toast(title + (on ? ' — ON' : ' — OFF'));
        resetFit();
      });
      try { if (sessionStorage.getItem('pref:' + cls) === '1') { document.body.classList.add(cls); b.classList.add('on'); } } catch (e) { }
      if (anchor) nav.insertBefore(b, anchor); else nav.appendChild(b);
      return b;
    };
    mk('focusBtn', '🎯', 'Focus mode', 'focus');
    mk('motionBtn', '🌀', 'Reduce motion', 'nomotion');
  }

  /* ===== 4. NỐI VÀO ENGINE ===== */
  var origGo = Engine.go;
  Engine.go = function (i, dir) {
    origGo.call(Engine, i, dir);
    applyScene();
    resetFit();
    setTimeout(scheduleFit, 140);
    setTimeout(scheduleFit, 620);
  };
  var origFs = Engine._applyFontScale;
  Engine._applyFontScale = function (v) { origFs.call(Engine, v); resetFit(); };

  var origStart = Engine.start;
  Engine.start = function (cfg) {
    origStart.call(Engine, cfg);
    applyScene();
    addNavButtons();
    resetFit();
    var stage = document.querySelector('.stage');
    if (stage) {
      if (global.ResizeObserver) new ResizeObserver(resetFit).observe(stage);
      else global.addEventListener('resize', resetFit);
      new MutationObserver(scheduleFit).observe(stage, { childList: true, subtree: true, characterData: true });
      stage.addEventListener('load', scheduleFit, true);   // ảnh tải xong -> đo lại
    }
    global.addEventListener('resize', resetFit);
    document.addEventListener('fullscreenchange', resetFit);
  };

  /* ===== 5. LỚP THẨM MỸ: icon SVG, thanh công cụ gọn, nhãn phần =====
     Chạy SAU engine dựng navbar, không sửa engine.js. Tắt từng phần nếu cần:
     Lab.tidyNav = false · Lab.svgIcons = false · Lab.autoEyebrow = false (đặt trong slide đầu). */
  var IC = {
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2.1 1.2M17.7 15.3l2.1 1.2M4.2 16.5l2.1-1.2M17.7 8.7l2.1-1.2"/><circle cx="12" cy="12" r="7"/>',
    check: '<path d="M4.5 12.5l4.8 4.8L19.5 7"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/>',
    sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 2.5h5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    star: '<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12"/>'
  };
  /* Icon vẽ bằng CSS mask (thẻ <i>), KHÔNG chèn <svg> vào DOM: qa.py mục 5 coi mọi <svg> là
     widget và báo "QUÁ NHỎ" oan cho icon trong nút. Màu icon = currentColor của nút. */
  Lab.icon = function (name) {
    var i = document.createElement('i');
    i.className = 'ic'; i.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (IC[name] || '') + '</svg>';
    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    i.style.webkitMaskImage = url; i.style.maskImage = url;
    return i;
  };
  function setIcon(btn, name) { if (!btn) return; btn.textContent = ''; btn.appendChild(Lab.icon(name)); }

  /* Emoji đầu nhãn nút -> icon SVG cùng nghĩa. Emoji không có trong bảng thì để nguyên. */
  var LEAD = [
    [/^\s*(✅|✔️?)\s*/, 'check'], [/^\s*👁️?\s*/, 'eye'], [/^\s*(↺|🔄)\s*/, 'reset'],
    [/^\s*(🔊|🔈)\s*/, 'sound'], [/^\s*(⏱️?)\s*/, 'timer'], [/^\s*(▶️?)\s*/, 'play'], [/^\s*(↩️?)\s*/, 'undo']
  ];
  function iconizeButtons(scope) {
    if (Lab.svgIcons === false || !scope) return;
    scope.querySelectorAll('.btn').forEach(function (b) {
      if (b.querySelector('.ic') || b.children.length) return;
      var t = b.textContent;
      for (var i = 0; i < LEAD.length; i++) {
        if (LEAD[i][0].test(t)) { b.textContent = t.replace(LEAD[i][0], ''); b.insertBefore(Lab.icon(LEAD[i][1]), b.firstChild); return; }
      }
    });
  }
  Lab.iconize = iconizeButtons;

  function tidyNav() {
    if (Lab.tidyNav === false) return;
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#tdrawerBtn')) return;
    var byTitle = function (p) { var r = null; nav.querySelectorAll('.iconbtn').forEach(function (b) { if (!r && (b.title || '').indexOf(p) === 0) r = b; }); return r; };
    var prev = byTitle('Previous'), next = byTitle('Next'), full = nav.querySelector('#fullscreenBtn');
    var drawer = dv(''); drawer.id = 'tdrawer';
    var row = function (label, els) {
      els = els.filter(Boolean); if (!els.length) return;
      var r = dv('row'); r.appendChild(dv('lbl', label)); els.forEach(function (e) { r.appendChild(e); }); drawer.appendChild(r);
    };
    row('Text size', [nav.querySelector('.fs-group')]);
    row('Sound', [byTitle('Mute'), nav.querySelector('#voiceBtn')]);
    row('Teams', [nav.querySelector('.teams')]);
    row('Class tools', [byTitle('Timer'), byTitle('Spotlight'), byTitle('Slides')]);
    row('Display', [nav.querySelector('#focusBtn'), nav.querySelector('#motionBtn')]);
    row('Lock', [nav.querySelector('#tlockBtn')]);
    document.body.appendChild(drawer);

    var tb = document.createElement('button');
    tb.id = 'tdrawerBtn'; tb.className = 'iconbtn tbtn'; tb.title = 'Teacher tools';
    tb.appendChild(Lab.icon('gear')); tb.appendChild(document.createTextNode('Teacher'));
    tb.addEventListener('click', function (e) { e.stopPropagation(); drawer.classList.toggle('on'); });
    document.addEventListener('pointerdown', function (e) {
      if (drawer.classList.contains('on') && !drawer.contains(e.target) && !tb.contains(e.target)) drawer.classList.remove('on');
    });
    var anchor = full || prev;
    if (anchor) nav.insertBefore(tb, anchor); else nav.appendChild(tb);

    if (Lab.svgIcons !== false) {
      if (prev) { setIcon(prev, 'prev'); prev.classList.add('nav-arrow'); }
      if (next) { setIcon(next, 'next'); next.classList.add('nav-arrow'); }
      if (full) {
        var sync = function () { setIcon(full, document.fullscreenElement ? 'shrink' : 'expand'); };
        sync(); document.addEventListener('fullscreenchange', function () { setTimeout(sync, 0); });
      }
    }
  }

  /* Nhãn phần (section) nhỏ phía trên tiêu đề — người xem luôn biết đang ở phần nào của bài */
  function addEyebrow() {
    if (Lab.autoEyebrow === false) return;
    var slide = curSlide(); var def = Engine.slides[Engine.idx];
    if (!slide || !def || !def.section || slide.querySelector('.eyebrow, .cover')) return;
    var pill = slide.querySelector(':scope > .pill');
    if (!pill || pill.textContent.toLowerCase().indexOf(def.section.toLowerCase()) >= 0) return;
    var eb = dv('eyebrow fixed', def.section);
    slide.insertBefore(eb, pill);
    /* Nhãn phần là trang trí: slide chật (font 150%, màn dọc) thì bỏ nhãn TRƯỚC khi fitStage phải co chữ */
    var f0 = slide.style.getPropertyValue('--fit');
    slide.style.setProperty('--fit', '1');
    var tight = slide.scrollHeight > slide.clientHeight + 1;
    if (f0) slide.style.setProperty('--fit', f0);
    if (tight || global.innerHeight < 560) eb.remove();
    resetFit();
  }

  var goAes = Engine.go;
  Engine.go = function (i, dir) {
    goAes.call(Engine, i, dir);
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
  };
  var startAes = Engine.start;
  Engine.start = function (cfg) {
    startAes.call(Engine, cfg);
    tidyNav();
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
    var st = document.querySelector('.stage');
    if (st) new MutationObserver(function () { iconizeButtons(st); }).observe(st, { childList: true, subtree: true });
  };

  /* ===================== 6. RIÊNG BÀI G7 · GEOMETRY L17 ===================== */
  Lab.autoEyebrow = false;   /* tiêu đề slide đã là tên phần như tab của PPT gốc */

  /* --- 6a. Cảnh nền gốc của PPT: khung sổ + khối 3D bóng (giữ hình minh hoạ nền theo yêu cầu GV) --- */
  var IMG = 'assets/img/deco-';
  /* mỗi phần học một bố cục khối 3D khác nhau -> sang phần mới là thấy đổi cảnh */
  var PAPER = [
    [['sphere-yellow', { right: '-2.2vw', bottom: '-4vh', w: 10.5 }, 'drift'], ['tube-pink', { left: '-3.4vw', bottom: '1vh', w: 12, r: -24 }], ['cube-white', { right: '-1.6vw', top: '9vh', w: 6.5, r: 8 }]],
    [['cube-pink', { left: '-2.4vw', top: '7vh', w: 8, r: -10 }, 'drift'], ['sphere-blue', { right: '-2.6vw', bottom: '-3vh', w: 10 }], ['tube-yellow', { right: '-3vw', top: '6vh', w: 10, r: 30 }]],
    [['tube-blue', { left: '-3.2vw', bottom: '3vh', w: 12, r: 18 }], ['cube-yellow', { right: '-2vw', bottom: '-3vh', w: 9, r: -8 }, 'drift'], ['sphere-pink', { left: '-2vw', top: '6vh', w: 6.5 }]],
    [['sphere-pink', { right: '-2.2vw', top: '7vh', w: 7.5 }, 'drift'], ['cube-white', { left: '-2.2vw', bottom: '-2vh', w: 9, r: 12 }], ['tube-yellow', { right: '-3vw', bottom: '2vh', w: 11, r: -28 }]],
    [['cube-yellow', { left: '-2.2vw', top: '8vh', w: 7.5, r: 10 }], ['sphere-blue', { right: '-2.2vw', bottom: '-4vh', w: 10.5 }, 'drift'], ['tube-pink', { left: '-3.4vw', bottom: '2vh', w: 11, r: 22 }]],
    [['tube-blue', { right: '-3.4vw', top: '8vh', w: 11, r: -20 }], ['sphere-yellow', { left: '-2.6vw', bottom: '-3vh', w: 10 }, 'drift'], ['cube-pink', { right: '-1.8vw', bottom: '-2vh', w: 8, r: -12 }]]
  ];
  var COVER = [['sphere-blue', { right: '3vw', top: '-6vh', w: 13 }, 'drift'], ['sphere-pink', { right: '-3vw', bottom: '-7vh', w: 15 }],
    ['cube-yellow', { left: '-3vw', bottom: '-6vh', w: 14, r: -8 }, 'drift2'], ['tube-yellow', { left: '-4vw', top: '4vh', w: 16, r: -18 }],
    ['cube-white', { left: '40vw', bottom: '-9vh', w: 9, r: 14 }], ['tube-blue', { right: '24vw', top: '-5vh', w: 13, r: 12 }]];
  function shape(spec) {
    var d = dv('deco shape' + (spec[2] ? ' ' + spec[2] : ''));
    var p = spec[1], ratio = spec[0].indexOf('tube') === 0 ? .5 : (spec[0].indexOf('cube') === 0 ? .96 : 1);
    d.style.backgroundImage = 'url("' + IMG + spec[0] + '.png")';
    d.style.width = p.w + 'vw'; d.style.height = (p.w * ratio) + 'vw';
    ['left', 'right', 'top', 'bottom'].forEach(function (k) { if (p[k] != null) d.style[k] = p[k]; });
    if (p.r) d.style.rotate = p.r + 'deg';
    return d;
  }
  var secOrder = null;
  Lab.scene = function (key) {
    var parts = key.split(':'), kind = parts.length > 1 ? parts[0] : 'paper', sec = parts[parts.length - 1];
    document.body.dataset.scene = kind;
    var sc = dv('scene ' + kind);
    if (kind === 'show') return sc;
    if (kind === 'cover') { COVER.forEach(function (s) { sc.appendChild(shape(s)); }); return sc; }
    if (!secOrder) { secOrder = []; Engine.slides.forEach(function (s) { if (!s.bg && secOrder.indexOf(s.section) < 0) secOrder.push(s.section); }); }
    sc.appendChild(dv('sheet-back')); sc.appendChild(dv('tab t1')); sc.appendChild(dv('tab t2')); sc.appendChild(dv('sheet'));
    var i = Math.max(0, secOrder.indexOf(sec));
    PAPER[i % PAPER.length].forEach(function (s) { sc.appendChild(shape(s)); });
    return sc;
  };

  /* --- 6b. Hình góc bằng SVG: toạ độ toán học (độ, ngược chiều kim đồng hồ), y SVG lật ngược --- */
  function pt(cx, cy, r, a) { var t = a * Math.PI / 180; return [cx + r * Math.cos(t), cy - r * Math.sin(t)]; }
  Lab.pt = pt;
  Lab.sector = function (cx, cy, r, a1, a2) {
    var p1 = pt(cx, cy, r, a1), p2 = pt(cx, cy, r, a2), big = (a2 - a1) > 180 ? 1 : 0;
    return 'M' + cx + ' ' + cy + ' L' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 ' + big + ' 0 ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1) + ' Z';
  };
  Lab.arc = function (cx, cy, r, a1, a2) {
    var p1 = pt(cx, cy, r, a1), p2 = pt(cx, cy, r, a2), big = (a2 - a1) > 180 ? 1 : 0;
    return 'M' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 ' + big + ' 0 ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
  };
  /* tia có mũi tên: từ (cx,cy) theo góc a, dài len */
  Lab.ray = function (svg, cx, cy, a, len, cls) {
    var e = pt(cx, cy, len, a), h1 = pt(e[0], e[1], 18, a + 155), h2 = pt(e[0], e[1], 18, a - 155);
    var g = sv('g', { 'class': cls || '' });
    g.appendChild(sv('line', { x1: cx, y1: cy, x2: e[0].toFixed(1), y2: e[1].toFixed(1), 'class': 'ray' }));
    g.appendChild(sv('path', { d: 'M' + h1[0].toFixed(1) + ' ' + h1[1].toFixed(1) + ' L' + e[0].toFixed(1) + ' ' + e[1].toFixed(1) + ' L' + h2[0].toFixed(1) + ' ' + h2[1].toFixed(1), 'class': 'ray' }));
    svg.appendChild(g);
    return g;
  };
  Lab.txt = function (svg, x, y, s, size, cls) {
    var t = sv('text', { x: x, y: y, 'font-size': size || 34, 'text-anchor': 'middle', 'dominant-baseline': 'middle', 'class': cls || '' });
    t.textContent = s; svg.appendChild(t); return t;
  };
  Lab.svg = function (vb) {
    var w = dv('fig');
    var s = sv('svg', { viewBox: vb, preserveAspectRatio: 'xMidYMid meet', role: 'img' });
    w.appendChild(s); w.svg = s; return w;
  };

  /* 4 hình từ vựng — vẽ lại đúng hình của slide Vocabulary/Review trong PPT */
  Lab.vocabFig = function (word) {
    var f = Lab.svg('0 0 300 240'), s = f.svg;
    if (word === 'vertex' || word === 'side') {
      var A = [150, 30], B = [40, 205], C = [260, 205];
      s.appendChild(sv('path', { d: 'M' + A + ' L' + B + ' L' + C + ' Z', fill: word === 'vertex' ? '#A5C8F0' : '#BBE5B5', stroke: word === 'vertex' ? '#1F2937' : 'none', 'stroke-width': 4, 'stroke-linejoin': 'round' }));
      if (word === 'vertex') {
        [A, B, C].forEach(function (p) { s.appendChild(sv('circle', { cx: p[0], cy: p[1], r: 11, 'class': 'vdot pulse-dot' })); });
      } else {
        [[A, B, '#15803D'], [B, C, '#1D4ED8'], [C, A, '#16A34A']].forEach(function (q, i) {
          var l = sv('line', { x1: q[0][0], y1: q[0][1], x2: q[1][0], y2: q[1][1], stroke: q[2], 'stroke-width': 8, 'stroke-linecap': 'round', pathLength: 1, 'class': 'draw' });
          l.style.animationDelay = (i * .45) + 's'; s.appendChild(l);
        });
        [A, B, C].forEach(function (p) { s.appendChild(sv('circle', { cx: p[0], cy: p[1], r: 6, 'class': 'dot' })); });
      }
    } else if (word === 'adjacent') {
      var O = [45, 205];
      s.appendChild(sv('path', { d: Lab.sector(O[0], O[1], 95, 0, 38), 'class': 's3' }));
      s.appendChild(sv('path', { d: Lab.sector(O[0], O[1], 80, 38, 72), 'class': 's2' }));
      Lab.ray(s, O[0], O[1], 0, 240);
      var r1 = Lab.ray(s, O[0], O[1], 38, 225); r1.querySelectorAll('.ray').forEach(function (e) { e.style.stroke = '#DC2626'; });
      var r2 = Lab.ray(s, O[0], O[1], 72, 190); r2.querySelectorAll('.ray').forEach(function (e) { e.style.stroke = '#1D4ED8'; });
      s.appendChild(sv('circle', { cx: O[0], cy: O[1], r: 7, 'class': 'dot' }));
    } else {
      var P = [150, 170];
      s.appendChild(sv('path', { d: Lab.sector(P[0], P[1], 78, 75, 180), 'class': 's2' }));
      s.appendChild(sv('path', { d: Lab.sector(P[0], P[1], 92, 0, 75), 'class': 's3' }));
      Lab.ray(s, P[0], P[1], 0, 140); Lab.ray(s, P[0], P[1], 180, 140);
      s.appendChild(sv('circle', { cx: P[0], cy: P[1], r: 8, 'class': 'dot' }));
    }
    return f;
  };

  /* --- 6c. Chọn 1 trong vài phương án ngay trong câu (lấy từ bài L6) --- */
  Lab.ich = function (ctx, opts, answer) {
    var w = document.createElement('span'); w.className = 'ich';
    w.__val = -1;
    opts.forEach(function (o, i) {
      var b = document.createElement('button'); b.textContent = o;
      ctx.on(b, 'click', function () {
        Sound.playEffect('click');
        ctx.clearResult(w);
        w.__val = i;
        w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === i); });
        w.classList.add('chosen');
        if (w.__onpick) w.__onpick(i);
      });
      w.appendChild(b);
    });
    w.__check = function () { var ok = w.__val === answer; ctx.markResult(w, ok); return ok; };
    w.__show = function () { ctx.clearResult(w); w.__val = answer; w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === answer); }); w.classList.add('chosen'); };
    w.__reset = function () { ctx.clearResult(w); w.__val = -1; w.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); }); w.classList.remove('chosen'); };
    return w;
  };

  /* --- 6d. Bàn phím số trên màn hình (bảng tương tác không có bàn phím) --- */
  Lab.numpad = function (ctx, disp, maxLen) {
    var pad = dv('npad'); var val = '';
    var paint = function () { disp.textContent = val ? val + '°' : ''; disp.classList.toggle('has', !!val); ctx.clearResult(disp); };
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '⌫', 'C'].forEach(function (k) {
      var b = document.createElement('button'); b.className = 'key' + (k === '⌫' || k === 'C' ? ' del' : ''); b.textContent = k;
      ctx.on(b, 'click', function () {
        Sound.playEffect('click');
        if (k === '⌫') val = val.slice(0, -1); else if (k === 'C') val = ''; else if (val.length < (maxLen || 3)) val += k;
        paint();
      });
      pad.appendChild(b);
    });
    return { el: pad, get: function () { return val; }, set: function (v) { val = String(v); paint(); }, clear: function () { val = ''; paint(); } };
  };

  /* --- 6e. Chấm dragDrop CHỈ theo ô đích (khay có thẻ nhiễu — lấy từ bài L6). zones: [{id, accept:[...]}] --- */
  Lab.ddCheck = function (ctx, dd, zones) {
    var correct = 0;
    dd.tray.querySelectorAll('.drag-item').forEach(function (n) { ctx.clearResult(n); });
    zones.forEach(function (z) {
      var zn = dd.zoneEls[z.id];
      var it = zn.querySelector('.drag-item');
      ctx.clearResult(zn);
      if (!it) { ctx.markResult(zn, false, { badge: false }); return; }
      var ok = z.accept.indexOf(it.dataset.ddId) >= 0;
      if (ok) correct++;
      ctx.markResult(it, ok);
    });
    return { correct: correct, total: zones.length };
  };
  Lab.ddClear = function (ctx, dd) { Object.keys(dd.zoneEls).forEach(function (k) { ctx.clearResult(dd.zoneEls[k]); }); };

  /* --- 6f. Chỗ trống bấm để đổi lần lượt các từ trong ngân hàng (gọn hơn hàng nút chọn khi câu dài) --- */
  Lab.cyc = function (ctx, opts, answer) {
    var b = document.createElement('button'); b.className = 'cyc'; b.textContent = '?';
    b.__val = -1;
    var paint = function () { b.textContent = b.__val < 0 ? '?' : opts[b.__val]; b.classList.toggle('chosen', b.__val >= 0); };
    ctx.on(b, 'click', function () { Sound.playEffect('click'); ctx.clearResult(b); b.__val = (b.__val + 1) % opts.length; paint(); });
    b.__check = function () { var ok = b.__val === answer; ctx.markResult(b, ok); return ok; };
    b.__show = function () { ctx.clearResult(b); b.__val = answer; paint(); };
    b.__reset = function () { ctx.clearResult(b); b.__val = -1; paint(); };
    return b;
  };
})(window);
