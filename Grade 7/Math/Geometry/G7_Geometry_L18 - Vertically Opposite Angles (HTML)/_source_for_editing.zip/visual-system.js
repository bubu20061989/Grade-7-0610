(function (global) {
  'use strict';
  if (global.Lab) return;
  var NS = 'http://www.w3.org/2000/svg';
  var Lab = {};
  global.Lab = Lab;

  function sv(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  Lab.sv = sv;
  function dv(cls, txt) { var d = document.createElement('div'); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  Lab.dv = dv;

  /* ===== 1. TẦNG NỀN THEO PHẦN HỌC (nằm ngoài .slide) ===== */
  /* Mỗi SECTION tự nhận 1 bảng màu theo thứ tự xuất hiện -> đổi bài không phải sửa gì.
     Chỉ định tay: Lab.PAL = { 'Tên section': ['#..','#..','#..'] }. */
  var POOL = [
    ['#5EEAD4', '#93C5FD', '#A7F3D0'],
    ['#7DD3FC', '#BAE6FD', '#5EEAD4'],
    ['#34D399', '#A3E635', '#A7F3D0'],
    ['#2DD4BF', '#34D399', '#93C5FD'],
    ['#A5B4FC', '#93C5FD', '#C7D2FE'],
    ['#FCD34D', '#A3E635', '#FDE68A']
  ];
  var palMap = null;
  function palFor(key) {
    if (!palMap) {
      palMap = {};
      var seen = [];
      Engine.slides.forEach(function (s) { var k = s.section || '-'; if (seen.indexOf(k) < 0) seen.push(k); });
      seen.forEach(function (k, i) { palMap[k] = POOL[i % POOL.length]; });
    }
    return (Lab.PAL && Lab.PAL[key]) || palMap[key] || POOL[0];
  }
  function rgba(hex, a) {
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.slice(0,2),16) + ',' + parseInt(h.slice(2,4),16) + ',' + parseInt(h.slice(4,6),16) + ',' + a + ')';
  }

  /* Khung gần trung tính, màu CHỈ ở 2 góc, giữa màn hình sạch tuyệt đối:
     không có gì nằm sau vùng chữ -> mắt không bị nhiễu. */
  function sceneD(c) {
    var sc = dv('scene');
    sc.style.background = 'linear-gradient(180deg,#FFFFFF 0%,#F7FBF9 56%,#EEF6F2 100%)';
    var tr = dv('deco');
    tr.style.right = '-16vw'; tr.style.top = '-34vh'; tr.style.width = '62vw'; tr.style.height = '62vw';
    tr.style.borderRadius = '50%'; tr.style.opacity = '1';
    tr.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[0], .26) + ' 0%,' + rgba(c[0], 0) + ' 66%)';
    sc.appendChild(tr);
    var bl = dv('deco');
    bl.style.left = '-20vw'; bl.style.bottom = '-32vh'; bl.style.width = '56vw'; bl.style.height = '56vw';
    bl.style.borderRadius = '50%'; bl.style.opacity = '1';
    bl.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[2], .22) + ' 0%,' + rgba(c[2], 0) + ' 66%)';
    sc.appendChild(bl);
    return sc;
  }

  var STYLES = { D: sceneD };
  Lab.bgStyle = 'P';   /* bài này: giữ nền minh hoạ gốc của PPT (scenePaper, cuối file) */
  function buildScene(key) { if (Lab.bgStyle === 'P') return scenePaper(key); return (STYLES[Lab.bgStyle] || sceneD)(palFor(key)); }

  var bgHost = null, curScene = null, curKey = null;
  function applyScene() {
    if (!bgHost) {
      bgHost = document.getElementById('bgLayer');
      if (!bgHost) { bgHost = dv(''); bgHost.id = 'bgLayer'; document.body.insertBefore(bgHost, document.body.firstChild); }
    }
    var def = Engine.slides[Engine.idx];
    var key = Lab.bgStyle === 'P' ? ((def && def.bg) || 'page') : ((def && def.section) || '-');
    if (key === curKey && !Lab.__force) return;
    Lab.__force = false;
    curKey = key;
    var next = buildScene(key);
    bgHost.appendChild(next);
    void next.offsetWidth;
    next.classList.add('on');
    var old = curScene;
    curScene = next;
    if (old) setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 700);
  }

  /* ===== 2. fitStage() — lưới an toàn chống vỡ =====
     Dùng biến CSS, KHÔNG transform:scale() lên .slide: tổ tiên có transform
     sẽ phá position:fixed của #dragLayer. */
  var fitRaf = 0, fitTries = 0;
  function curSlide() { return document.querySelector('.stage > .slide'); }
  function minFit() {
    var fs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--fs-scale')) || 1;
    return Math.min(1, 0.72 / fs);
  }
  /* Sàn CHÍNH XÁC cho từng slide: đo cỡ chữ NHỎ NHẤT đang hiện ở --fit = 1, rồi cho co
     đúng tới lúc cỡ đó chạm ngưỡng đọc được từ cuối lớp (1/40 chiều cao màn hình, tối
     thiểu 22px). Bỏ qua chữ trong <svg> vì nó co theo khung hình, không theo --fit. */
  function textFloor(slide) {
    var th = Math.max(22, global.innerHeight / 40);
    var min = Infinity;
    var nodes = slide.querySelectorAll('*');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.ownerSVGElement || n.tagName.toLowerCase() === 'svg') continue;
      var hasText = false;
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3 && c.nodeValue.trim()) { hasText = true; break; }
      }
      if (!hasText) continue;
      var r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      var fsz = parseFloat(getComputedStyle(n).fontSize);
      if (fsz && fsz < min) min = fsz;
    }
    if (!isFinite(min) || !th) return 0.45;
    /* co hệ số f => chữ nhỏ nhất thành min*f; cần min*f >= th => f >= th/min */
    return Math.max(0.45, Math.min(1, (th * 1.06) / min));   // +6% biên an toàn
  }
  /* Bài này: khối con (.grow/.split/thẻ) tràn nội dung nhưng .slide không cuộn (overflow:hidden)
     -> scrollHeight của .slide không đổi. Đo thêm từng khối để fitStage vẫn co chữ. */
  function innerOverflow(slide) {
    /* so khung LAYOUT (offset*, không bị transform của hiệu ứng .stagger làm lệch) của con trực tiếp
       với khung cha — scrollHeight báo nhầm khi có ảnh co giãn, getBoundingClientRect nhầm khi đang animate */
    var bx = slide.querySelectorAll('.grow, .split > *, .stagecard, .pcard, .card, .clozelist, .clozegrid, .rowwrap > *, .fc-wrap');
    for (var i = 0; i < bx.length; i++) {
      var box = bx[i]; if (!box.offsetHeight) continue;
      var kids = box.children;
      for (var j = 0; j < kids.length; j++) {
        var k = kids[j]; if (!k.offsetHeight) continue;
        var top, bot;
        if (k.offsetParent === box) { top = k.offsetTop; bot = top + k.offsetHeight; if (bot > box.clientHeight + 3 || top < -3) return true; }
        else if (k.offsetParent === box.offsetParent) { top = k.offsetTop; bot = top + k.offsetHeight; if (bot > box.offsetTop + box.offsetHeight + 3 || top < box.offsetTop - 3) return true; }
      }
    }
    return false;
  }
  function fitNow() {
    fitRaf = 0;
    var slide = curSlide();
    if (!slide) return;
    var lo = slide.__floor != null ? slide.__floor : minFit();
    var cur = parseFloat(slide.style.getPropertyValue('--fit'));
    if (!(cur > 0)) cur = 1;
    var guard = 0;
    /* Vòng lặp ĐỒNG BỘ: đọc scrollHeight ép trình duyệt tính lại layout ngay, nên slide
       vừa vào là đã vừa khung — không nhấp nháy 1-2 khung hình. */
    while ((slide.scrollHeight > slide.clientHeight + 1 || innerOverflow(slide)) && cur > lo + 0.001 && guard++ < 16) {
      cur = Math.max(lo, cur - 0.05);
      slide.style.setProperty('--fit', cur.toFixed(3));
    }
    fitTries = guard;
  }
  function scheduleFit() {
    if (fitRaf) return;
    fitRaf = global.requestAnimationFrame ? requestAnimationFrame(fitNow) : setTimeout(fitNow, 16);
  }
  function resetFit() {
    var slide = curSlide();
    if (slide) {
      slide.style.setProperty('--fit', '1');
      slide.__floor = textFloor(slide);
    }
    fitTries = 0;
    fitNow();
    scheduleFit();
  }
  Lab.setBgStyle = function (k) { Lab.bgStyle = k; Lab.__force = true; applyScene(); };
  Lab.fit = scheduleFit;
  Lab.refit = resetFit;

  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };

  /* ===== 3. NÚT LỚP HỌC: Tập trung / Giảm chuyển động ===== */
  function addNavButtons() {
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#focusBtn')) return;
    var anchor = nav.querySelector('#fullscreenBtn') || nav.querySelector('#tlockBtn');
    var mk = function (id, icon, title, cls) {
      var b = document.createElement('button');
      b.className = 'iconbtn'; b.id = id; b.textContent = icon; b.title = title;
      b.addEventListener('click', function () {
        var on = document.body.classList.toggle(cls);
        b.classList.toggle('on', on);
        try { sessionStorage.setItem('pref:' + cls, on ? '1' : '0'); } catch (e) { }
        Engine.toast(title + (on ? ' — ON' : ' — OFF'));
        resetFit();
      });
      try { if (sessionStorage.getItem('pref:' + cls) === '1') { document.body.classList.add(cls); b.classList.add('on'); } } catch (e) { }
      if (anchor) nav.insertBefore(b, anchor); else nav.appendChild(b);
      return b;
    };
    mk('focusBtn', '🎯', 'Focus mode', 'focus');
    mk('motionBtn', '🌀', 'Reduce motion', 'nomotion');
  }

  /* ===== 4. NỐI VÀO ENGINE ===== */
  var origGo = Engine.go;
  Engine.go = function (i, dir) {
    origGo.call(Engine, i, dir);
    applyScene();
    resetFit();
    setTimeout(scheduleFit, 140);
    setTimeout(scheduleFit, 620);
  };
  var origFs = Engine._applyFontScale;
  Engine._applyFontScale = function (v) { origFs.call(Engine, v); resetFit(); };

  var origStart = Engine.start;
  Engine.start = function (cfg) {
    origStart.call(Engine, cfg);
    applyScene();
    addNavButtons();
    resetFit();
    var stage = document.querySelector('.stage');
    if (stage) {
      if (global.ResizeObserver) new ResizeObserver(function () { requestAnimationFrame(resetFit); }).observe(stage);
      else global.addEventListener('resize', resetFit);
      new MutationObserver(scheduleFit).observe(stage, { childList: true, subtree: true, characterData: true });
      stage.addEventListener('load', scheduleFit, true);   // ảnh tải xong -> đo lại
    }
    global.addEventListener('resize', resetFit);
    document.addEventListener('fullscreenchange', resetFit);
  };

  /* ===== 5. LỚP THẨM MỸ: icon SVG, thanh công cụ gọn, nhãn phần =====
     Chạy SAU engine dựng navbar, không sửa engine.js. Tắt từng phần nếu cần:
     Lab.tidyNav = false · Lab.svgIcons = false · Lab.autoEyebrow = false (đặt trong slide đầu). */
  var IC = {
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2.1 1.2M17.7 15.3l2.1 1.2M4.2 16.5l2.1-1.2M17.7 8.7l2.1-1.2"/><circle cx="12" cy="12" r="7"/>',
    check: '<path d="M4.5 12.5l4.8 4.8L19.5 7"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/>',
    sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 2.5h5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    star: '<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12"/>'
  };
  /* Icon vẽ bằng CSS mask (thẻ <i>), KHÔNG chèn <svg> vào DOM: qa.py mục 5 coi mọi <svg> là
     widget và báo "QUÁ NHỎ" oan cho icon trong nút. Màu icon = currentColor của nút. */
  Lab.icon = function (name) {
    var i = document.createElement('i');
    i.className = 'ic'; i.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (IC[name] || '') + '</svg>';
    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    i.style.webkitMaskImage = url; i.style.maskImage = url;
    return i;
  };
  function setIcon(btn, name) { if (!btn) return; btn.textContent = ''; btn.appendChild(Lab.icon(name)); }

  /* Emoji đầu nhãn nút -> icon SVG cùng nghĩa. Emoji không có trong bảng thì để nguyên. */
  var LEAD = [
    [/^\s*(✅|✔️?)\s*/, 'check'], [/^\s*👁️?\s*/, 'eye'], [/^\s*(↺|🔄)\s*/, 'reset'],
    [/^\s*(🔊|🔈)\s*/, 'sound'], [/^\s*(⏱️?)\s*/, 'timer'], [/^\s*(▶️?)\s*/, 'play'], [/^\s*(↩️?)\s*/, 'undo']
  ];
  function iconizeButtons(scope) {
    if (Lab.svgIcons === false || !scope) return;
    scope.querySelectorAll('.btn').forEach(function (b) {
      if (b.querySelector('.ic') || b.children.length) return;
      var t = b.textContent;
      for (var i = 0; i < LEAD.length; i++) {
        if (LEAD[i][0].test(t)) { b.textContent = t.replace(LEAD[i][0], ''); b.insertBefore(Lab.icon(LEAD[i][1]), b.firstChild); return; }
      }
    });
  }
  Lab.iconize = iconizeButtons;

  function tidyNav() {
    if (Lab.tidyNav === false) return;
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#tdrawerBtn')) return;
    var byTitle = function (p) { var r = null; nav.querySelectorAll('.iconbtn').forEach(function (b) { if (!r && (b.title || '').indexOf(p) === 0) r = b; }); return r; };
    var prev = byTitle('Previous'), next = byTitle('Next'), full = nav.querySelector('#fullscreenBtn');
    var drawer = dv(''); drawer.id = 'tdrawer';
    var row = function (label, els) {
      els = els.filter(Boolean); if (!els.length) return;
      var r = dv('row'); r.appendChild(dv('lbl', label)); els.forEach(function (e) { r.appendChild(e); }); drawer.appendChild(r);
    };
    row('Text size', [nav.querySelector('.fs-group')]);
    row('Sound', [byTitle('Mute'), nav.querySelector('#voiceBtn')]);
    row('Teams', [nav.querySelector('.teams')]);
    row('Class tools', [byTitle('Timer'), byTitle('Spotlight'), byTitle('Slides')]);
    row('Display', [nav.querySelector('#focusBtn'), nav.querySelector('#motionBtn')]);
    row('Lock', [nav.querySelector('#tlockBtn')]);
    document.body.appendChild(drawer);

    var tb = document.createElement('button');
    tb.id = 'tdrawerBtn'; tb.className = 'iconbtn tbtn'; tb.title = 'Teacher tools';
    tb.appendChild(Lab.icon('gear')); tb.appendChild(document.createTextNode('Teacher'));
    tb.addEventListener('click', function (e) { e.stopPropagation(); drawer.classList.toggle('on'); });
    document.addEventListener('pointerdown', function (e) {
      if (drawer.classList.contains('on') && !drawer.contains(e.target) && !tb.contains(e.target)) drawer.classList.remove('on');
    });
    var anchor = full || prev;
    if (anchor) nav.insertBefore(tb, anchor); else nav.appendChild(tb);

    if (Lab.svgIcons !== false) {
      if (prev) { setIcon(prev, 'prev'); prev.classList.add('nav-arrow'); }
      if (next) { setIcon(next, 'next'); next.classList.add('nav-arrow'); }
      if (full) {
        var sync = function () { setIcon(full, document.fullscreenElement ? 'shrink' : 'expand'); };
        sync(); document.addEventListener('fullscreenchange', function () { setTimeout(sync, 0); });
      }
    }
  }

  /* Nhãn phần (section) nhỏ phía trên tiêu đề — người xem luôn biết đang ở phần nào của bài */
  function addEyebrow() {
    if (Lab.autoEyebrow === false) return;
    var slide = curSlide(); var def = Engine.slides[Engine.idx];
    if (!slide || !def || !def.section || slide.querySelector('.eyebrow, .cover')) return;
    var pill = slide.querySelector(':scope > .pill');
    if (!pill || pill.textContent.toLowerCase().indexOf(def.section.toLowerCase()) >= 0) return;
    var eb = dv('eyebrow fixed', def.section);
    slide.insertBefore(eb, pill);
    /* Nhãn phần là trang trí: slide chật (font 150%, màn dọc) thì bỏ nhãn TRƯỚC khi fitStage phải co chữ */
    var f0 = slide.style.getPropertyValue('--fit');
    slide.style.setProperty('--fit', '1');
    var tight = slide.scrollHeight > slide.clientHeight + 1;
    if (f0) slide.style.setProperty('--fit', f0);
    if (tight || global.innerHeight < 560) eb.remove();
    resetFit();
  }

  var goAes = Engine.go;
  Engine.go = function (i, dir) {
    goAes.call(Engine, i, dir);
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
  };
  var startAes = Engine.start;
  Engine.start = function (cfg) {
    startAes.call(Engine, cfg);
    tidyNav();
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
    var st = document.querySelector('.stage');
    if (st) new MutationObserver(function () { iconizeButtons(st); }).observe(st, { childList: true, subtree: true });
  };


  /* ===================== 6. RIÊNG BÀI G7 · Geometry L18 — Vertically Opposite Angles ===================== */
  Lab.autoEyebrow = false;   /* tab tiêu đề đỏ như PPT gốc; nhãn phần đè lên mép khung sổ nên tắt */

  /* Nền: ảnh minh hoạ gốc của PPT, mỗi slide khai `bg`. space = nền thiên hà phần Review (+ thuyền capybara). */
  var BG = { cover: 'bg-cover.jpg', page: 'bg-page.jpg', page2: 'bg-page2.jpg', page3: 'bg-page3.jpg',
    space: 'bg-space.jpg', space2: 'bg-space2.jpg', project: 'bg-project.jpg', thanks: 'bg-thanks.jpg' };
  function scenePaper(key) {
    if (!BG[key]) key = 'page';
    var sc = dv('scene paper k-' + key);
    sc.style.backgroundImage = 'url("assets/img/' + BG[key] + '")';
    if (key === 'space' || key === 'space2') {
      var b = dv('boat drift'); var im = document.createElement('img');
      im.src = 'assets/img/boat.png'; im.alt = ''; b.appendChild(im); sc.appendChild(b);
    }
    document.body.setAttribute('data-bg', key);
    return sc;
  }

  /* Toán: "^xAm" -> tên góc có mũ. Lab.para: $toán$ + [[slot]] như bài trước. */
  Lab.m = function (s) { return String(s).replace(/\^([A-Za-z]{2,3})/g, '<span class="ang">$1</span>'); };
  Lab.para = function (text, slots, cls) {
    var p = document.createElement('div'); p.className = cls || 'para';
    p.innerHTML = Lab.m(text).replace(/\[\[(\w+)\]\]/g, '<span data-slot="$1"></span>');
    p.querySelectorAll('[data-slot]').forEach(function (s) { var e = slots && slots[s.dataset.slot]; if (e) s.replaceWith(e); else s.remove(); });
    return p;
  };
  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };
  /* Chấm dragDrop CHỈ theo ô đích (khay có thẻ nhiễu). zones: [{id, accept:[...]}] */
  Lab.ddCheck = function (ctx, dd, zones) {
    var correct = 0;
    dd.tray.querySelectorAll('.drag-item').forEach(function (n) { ctx.clearResult(n); });
    zones.forEach(function (z) {
      var zn = dd.zoneEls[z.id];
      var it = zn.querySelector('.drag-item');
      if (!it) { ctx.clearResult(zn); ctx.markResult(zn, false, { badge: false }); return; }
      ctx.clearResult(zn);
      var ok = z.accept.indexOf(it.dataset.ddId) >= 0;
      if (ok) correct++;
      ctx.markResult(it, ok);
    });
    return { correct: correct, total: zones.length };
  };
  Lab.ddClear = function (ctx, dd) { Object.keys(dd.zoneEls).forEach(function (k) { ctx.clearResult(dd.zoneEls[k]); }); };

  /* Chọn 1 trong 2-3 phương án ngay trong câu. opts: chuỗi (cho phép $toán$) */
  Lab.ich = function (ctx, opts, answer) {
    var w = document.createElement('span'); w.className = 'ich';
    w.__val = -1;
    opts.forEach(function (o, i) {
      var b = document.createElement('button');
      b.innerHTML = Lab.m(o);
      ctx.on(b, 'click', function () {
        Sound.playEffect('click');
        ctx.clearResult(w);
        w.__val = i;
        w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === i); });
        w.classList.add('chosen');
      });
      w.appendChild(b);
    });
    w.__check = function () { var ok = w.__val === answer; ctx.markResult(w, ok); return ok; };
    w.__show = function () { ctx.clearResult(w); w.__val = answer; w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === answer); }); w.classList.add('chosen'); };
    w.__reset = function () { ctx.clearResult(w); w.__val = -1; w.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); }); w.classList.remove('chosen'); };
    return w;
  };
  Lab.ichGroup = function (list) {
    return {
      check: function () { var c = 0; list.forEach(function (w) { if (w.__check()) c++; }); return { correct: c, total: list.length }; },
      show: function () { list.forEach(function (w) { w.__show(); }); },
      reset: function () { list.forEach(function (w) { w.__reset(); }); }
    };
  };

  /* Sắp thứ tự bằng cách chạm lần lượt (đánh số 1,2,3...). items: HTML theo ĐÚNG thứ tự */
  Lab.steps = function (ctx, items) {
    var box = document.createElement('div'); box.className = 'steps stagger';
    var order = items.map(function (_, i) { return i; });
    var tries = 0;
    do { order = ctx.shuffle(order); tries++; } while (order.every(function (v, i) { return v === i; }) && tries < 20);
    var seq = [];
    var nodes = order.map(function (k) {
      var b = document.createElement('button'); b.className = 'step'; b.dataset.k = k;
      var no = document.createElement('span'); no.className = 'no'; no.textContent = '?';
      var tx = document.createElement('span'); tx.innerHTML = Lab.m(items[k]);
      b.append(no, tx);
      ctx.on(b, 'click', function () {
        ctx.clearResult(b);
        var at = seq.indexOf(b);
        if (at >= 0) seq.splice(at, 1); else seq.push(b);
        Sound.playEffect('click');
        paint();
      });
      box.appendChild(b);
      return b;
    });
    function paint() {
      nodes.forEach(function (b) {
        var at = seq.indexOf(b);
        b.classList.toggle('numbered', at >= 0);
        b.querySelector('.no').textContent = at >= 0 ? String(at + 1) : '?';
      });
    }
    return {
      el: box,
      check: function () {
        var c = 0;
        nodes.forEach(function (b) {
          var at = seq.indexOf(b); var ok = at === +b.dataset.k;
          if (ok) c++;
          ctx.markResult(b, ok);
        });
        return { correct: c, total: nodes.length };
      },
      show: function () {
        nodes.forEach(function (b) { ctx.clearResult(b); });
        seq = nodes.slice().sort(function (a, b) { return a.dataset.k - b.dataset.k; });
        seq.forEach(function (b) { box.appendChild(b); });
        paint();
      },
      reset: function () { seq = []; nodes.forEach(function (b) { ctx.clearResult(b); }); paint(); }
    };
  };


  /* ---------- SVG GÓC: 2 đường thẳng cắt nhau / góc kề ---------- */
  function P(cx, cy, r, deg) { var a = deg * Math.PI / 180; return [cx + r * Math.cos(a), cy - r * Math.sin(a)]; }
  function wedgePath(cx, cy, r, a, b) {          /* a -> b ngược chiều kim đồng hồ (độ) */
    var p1 = P(cx, cy, r, a), p2 = P(cx, cy, r, b), large = ((b - a) % 360 + 360) % 360 > 180 ? 1 : 0;
    return 'M' + cx + ',' + cy + ' L' + p1[0].toFixed(1) + ',' + p1[1].toFixed(1) + ' A' + r + ',' + r + ' 0 ' + large + ' 0 ' + p2[0].toFixed(1) + ',' + p2[1].toFixed(1) + ' Z';
  }
  Lab.P = P; Lab.wedgePath = wedgePath;

  /* Hình "2 đường thẳng cắt nhau" xoay được. o: {a1, theta, labels:[4 tên tia], vertex, interactive, onChange} */
  Lab.cross = function (ctx, o) {
    o = o || {};
    var W = 640, H = 440, cx = 320, cy = 220, L = 205, R = 74;
    var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': 'Two straight lines intersect at a point' });
    var g = sv('g'); svg.appendChild(g);
    var st = { a1: o.a1 == null ? 200 : o.a1, th: o.theta == null ? 40 : o.theta, hl: -1 };
    var wedges = [], labs = [];
    function draw() {
      while (g.firstChild) g.removeChild(g.firstChild);
      var a1 = st.a1, a2 = st.a1 + st.th, rays = [a1, a2, a1 + 180, a2 + 180];
      wedges = [];
      for (var k = 0; k < 4; k++) {
        var from = rays[k], to = k < 3 ? rays[k + 1] : rays[0] + 360;
        var cls = 'wedge ' + (k % 2 === 0 ? 'b' : 'o');
        if (st.hl >= 0) cls += (k % 2 === st.hl % 2) ? ' hl' : ' fade';
        var w = sv('path', { d: wedgePath(cx, cy, k % 2 ? R : R + 6, from, to), class: cls, 'data-k': k });
        wedges.push(w); g.appendChild(w);
        var mid = (from + to) / 2, lp = P(cx, cy, R + 40, mid);
        var meas = k % 2 === 0 ? st.th : 180 - st.th;
        var t = sv('text', { x: lp[0].toFixed(1), y: (lp[1] + 11).toFixed(1), 'text-anchor': 'middle', class: 'deg', 'font-size': 30, fill: k % 2 ? '#B45309' : '#0369A1' });
        t.textContent = (o.numbers ? (k + 1) + ': ' : '') + Math.round(meas) + '°';
        g.appendChild(t);
      }
      [[a1, a1 + 180, '#0F172A'], [a2, a2 + 180, '#0F172A']].forEach(function (ln) {
        var p = P(cx, cy, L, ln[0]), q = P(cx, cy, L, ln[1]);
        g.appendChild(sv('line', { x1: p[0], y1: p[1], x2: q[0], y2: q[1], stroke: ln[2], 'stroke-width': 6, 'stroke-linecap': 'round' }));
      });
      g.appendChild(sv('circle', { cx: cx, cy: cy, r: 8, fill: '#0F172A' }));
      var names = o.labels || [];
      rays.forEach(function (a, k) {
        if (!names[k]) return;
        var p = P(cx, cy, L + 26, a);
        var t = sv('text', { x: p[0].toFixed(1), y: (p[1] + 12).toFixed(1), 'text-anchor': 'middle', 'font-size': 38, fill: '#0F172A' });
        t.textContent = names[k]; g.appendChild(t);
      });
      if (o.vertex) { var t2 = sv('text', { x: cx, y: cy + 52, 'text-anchor': 'middle', 'font-size': 36, fill: '#0F172A' }); t2.textContent = o.vertex; g.appendChild(t2); }
      if (o.interactive) {
        var hp = P(cx, cy, L, a2);
        var hnd = sv('circle', { cx: hp[0], cy: hp[1], r: 22, class: 'handle' }); g.appendChild(hnd);
      }
      o.onChange && o.onChange(st);
    }
    if (o.interactive) {
      var dragging = false;
      ctx.on(svg, 'pointerdown', function (e) {
        var w = e.target.closest && e.target.closest('.wedge');
        if (w) { var k = +w.getAttribute('data-k'); st.hl = st.hl === k % 2 ? -1 : k % 2; Sound.playEffect('click'); draw(); return; }
        if (e.target.classList && e.target.classList.contains('handle')) { dragging = true; try { svg.setPointerCapture(e.pointerId); } catch (x) { } }
      });
      ctx.on(svg, 'pointermove', function (e) {
        if (!dragging) return;
        var r = svg.getBoundingClientRect(), s = Math.min(r.width / W, r.height / H);
        var ox = r.left + (r.width - W * s) / 2, oy = r.top + (r.height - H * s) / 2;
        var x = (e.clientX - ox) / s - cx, y = cy - (e.clientY - oy) / s;
        var ang = Math.atan2(y, x) * 180 / Math.PI;
        var th = ((ang - st.a1) % 180 + 180) % 180;
        st.th = Math.max(20, Math.min(160, Math.round(th / 5) * 5)); draw();
      });
      var stop = function () { dragging = false; };
      ctx.on(svg, 'pointerup', stop); ctx.on(svg, 'pointercancel', stop);
    }
    draw();
    return {
      el: svg,
      rotate: function (d) { st.th = Math.max(20, Math.min(160, st.th + d)); draw(); },
      set: function (th) { st.th = th; draw(); },
      highlight: function (k) { st.hl = k; draw(); },
      state: st
    };
  };

  /* Q5: góc kề bù xOy (cam) + yOz = 30° (xanh) */
  Lab.figQ5 = function () {
    var svg = sv('svg', { viewBox: '0 0 640 300', role: 'img', 'aria-label': 'Angle xOy and angle yOz = 30 degrees on a straight line xz' });
    var cx = 320, cy = 220, a0 = 3;   /* đường xz hơi nghiêng như hình gốc */
    var pz = P(cx, cy, 290, a0), px = P(cx, cy, 290, a0 + 180), py = P(cx, cy, 250, a0 + 30);
    svg.appendChild(sv('path', { d: wedgePath(cx, cy, 70, a0 + 30, a0 + 180), fill: '#F59E0B' }));
    svg.appendChild(sv('path', { d: wedgePath(cx, cy, 60, a0, a0 + 30), fill: '#0EA5E9' }));
    svg.appendChild(sv('line', { x1: px[0], y1: px[1], x2: pz[0], y2: pz[1], stroke: '#0F172A', 'stroke-width': 5 }));
    svg.appendChild(sv('line', { x1: cx, y1: cy, x2: py[0], y2: py[1], stroke: '#0F172A', 'stroke-width': 5 }));
    var lab = function (x, y, t, cls, fs) { var e = sv('text', { x: x, y: y, 'text-anchor': 'middle', 'font-size': fs || 40, 'font-family': 'Georgia,serif', 'font-style': cls ? 'normal' : 'italic', 'font-weight': 700, fill: '#0F172A' }); e.textContent = t; svg.appendChild(e); };
    lab(px[0] + 6, px[1] - 18, 'x'); lab(pz[0] - 6, pz[1] - 18, 'z'); lab(py[0] + 22, py[1] + 8, 'y'); lab(cx, cy + 50, 'O', 1);
    var pd = P(cx, cy, 100, a0 + 14); lab(pd[0] + 18, pd[1] + 6, '30°', 1, 32);
    return svg;
  };

  /* Hình minh hoạ 4 từ vựng (vẽ lại nét từ thẻ từ vựng gốc) */
  Lab.vocabFig = function (k) {
    var svg = sv('svg', { viewBox: '0 0 400 300', role: 'img', 'aria-label': ['vertically', 'opposite', 'straight line', 'intersect'][k] });
    var defs = sv('defs'); svg.appendChild(defs);
    ['#DC2626', '#1D4ED8', '#0F172A'].forEach(function (c, i) {
      var m = sv('marker', { id: 'ah' + k + i, viewBox: '0 0 10 10', refX: 6, refY: 5, markerWidth: 4.2, markerHeight: 4.2, orient: 'auto-start-reverse' });
      m.appendChild(sv('path', { d: 'M0,0 L10,5 L0,10 z', fill: c })); defs.appendChild(m);
    });
    var ln = function (x1, y1, x2, y2, ci, both) { var a = { x1: x1, y1: y1, x2: x2, y2: y2, stroke: ['#DC2626', '#1D4ED8', '#0F172A'][ci], 'stroke-width': 9, 'stroke-linecap': 'round', 'marker-end': 'url(#ah' + k + ci + ')' }; if (both) a['marker-start'] = 'url(#ah' + k + ci + ')'; svg.appendChild(sv('line', a)); };
    var tx = function (x, y, t) { var e = sv('text', { x: x, y: y, 'text-anchor': 'middle', 'font-size': 34, 'font-family': 'Georgia,serif', 'font-style': 'italic', 'font-weight': 700, fill: '#0F172A' }); e.textContent = t; svg.appendChild(e); };
    if (k === 0) {
      svg.appendChild(sv('line', { x1: 110, y1: 40, x2: 290, y2: 40, stroke: '#0F172A', 'stroke-width': 4, 'stroke-dasharray': '12 10' }));
      ln(200, 270, 200, 52, 0); svg.appendChild(sv('path', { d: 'M200,70 h22 v-22', fill: 'none', stroke: '#DC2626', 'stroke-width': 4 }));
      tx(240, 100, 'A'); tx(240, 280, 'B');
    } else if (k === 1) { ln(60, 110, 340, 110, 1, true); ln(60, 200, 340, 200, 0, true); }
    else if (k === 2) {
      ln(40, 150, 360, 150, 2, true);
      [[110, 'A'], [200, 'B'], [290, 'C']].forEach(function (p) { svg.appendChild(sv('circle', { cx: p[0], cy: 150, r: 9, fill: '#0F172A' })); tx(p[0], 205, p[1]); });
    } else {
      ln(90, 260, 310, 40, 0); ln(310, 260, 90, 40, 1);
      svg.appendChild(sv('circle', { cx: 200, cy: 150, r: 11, fill: '#0F172A' })); tx(238, 162, 'O');
    }
    return svg;
  };

  /* ---------- BÀN PHÍM SỐ (không dùng <input>) ---------- */
  Lab.keypad = function (ctx, onKey) {
    var kp = document.createElement('div'); kp.className = 'keypad';
    ['7', '8', '9', '⌫', '4', '5', '6', 'C', '1', '2', '3', '0'].forEach(function (k) {
      var b = document.createElement('button'); b.className = 'key'; b.textContent = k;
      ctx.on(b, 'click', function () { Sound.playEffect('click'); onKey(k); });
      kp.appendChild(b);
    });
    return kp;
  };
  /* Ô số chạm-để-chọn. fields: [{el, val}] — trả về bộ điều khiển chung với 1 bàn phím */
  Lab.numGroup = function (ctx, n, maxLen) {
    var fields = [], cur = 0;
    for (var i = 0; i < n; i++) (function (i) {
      var f = document.createElement('button'); f.className = 'numfield'; f.__v = '';
      f.innerHTML = '&nbsp;';
      ctx.on(f, 'click', function () { cur = i; paint(); });
      fields.push(f);
    })(i);
    function paint() { fields.forEach(function (f, i) { f.classList.toggle('on', i === cur && fields.length > 1); f.textContent = f.__v ? f.__v + '°' : ' '; }); }
    function key(k) {
      var f = fields[cur]; ctx.clearResult(f);
      if (k === '⌫') f.__v = f.__v.slice(0, -1);
      else if (k === 'C') f.__v = '';
      else if (f.__v.length < (maxLen || 3)) f.__v += k;
      if (f.__v.length >= (maxLen || 3) && cur < fields.length - 1) cur++;
      paint();
    }
    paint();
    return {
      fields: fields, key: key,
      check: function (ans) { var c = 0; fields.forEach(function (f, i) { var ok = +f.__v === ans[i] && f.__v !== ''; if (ok) c++; ctx.markResult(f, ok); }); return { correct: c, total: fields.length }; },
      show: function (ans) { fields.forEach(function (f, i) { ctx.clearResult(f); f.__v = String(ans[i]); }); paint(); },
      reset: function () { fields.forEach(function (f) { ctx.clearResult(f); f.__v = ''; }); cur = 0; paint(); }
    };
  };

  /* ---------- ÔN TẬP: 12 câu của bảng "bắt capybara" ---------- */
  Lab.QZ = [
    null,
    { q: 'What is the point where two lines meet to form an angle called?', o: ['Vertex', 'Edge', 'Side', 'Total area'], a: 0, mode: 'tap' },
    { q: 'What is the one of the line segments that form a polygon called?', o: ['Edge', 'Side', 'Vertex', 'Surface'], a: 1, mode: 'drag' },
    { q: 'What are two angles are next to each other and share a line called?', o: ['Supplementary angle', 'Straight angle', 'Adjacent angle', 'Obtuse angle'], a: 2, mode: 'tap' },
    { q: 'What are two angles whose measures add up to 180° called?', o: ['Acute angle', 'Obtuse angle', 'Adjacent angle', 'Supplementary angle'], a: 3, mode: 'vote' },
    { q: 'Find the measure of ^xOy.', o: ['150°', '120°', '180°', '55°'], a: 0, mode: 'tap', fig: 'svg5' },
    { q: 'What are the two angles ^xOy and ^zEt called?', o: ['Adjacent', 'Supplementary', 'Vertex', 'Arm'], a: 1, mode: 'tap', fig: 'assets/img/q6.png' },
    { q: 'What are the two angles ^xOy and ^yOz called?', o: ['Acute', 'Obtuse', 'Adjacent', 'Supplementary'], a: 2, mode: 'vote', fig: 'assets/img/q7.png' },
    { letters: 'AACDEJNT', word: 'ADJACENT' },
    { letters: 'EERTVX', word: 'VERTEX' },
    { q: 'What is a straight edge connecting two vertices (corners) of the shape called?', o: ['Vertex', 'Side', 'Base', 'Angle'], a: 1, mode: 'tap' },
    { q: 'What is the point that is opposite the base of a shape called?', o: ['Edge', 'Base', 'Vertex', 'Side'], a: 2, mode: 'drag' },
    { letters: 'AEELMNPPRSTUY', word: 'SUPPLEMENTARY' }
  ];
  function capy(n) { return 'assets/img/capy-' + (n < 10 ? '0' : '') + n + '.png'; }
  Lab.capy = capy;

  function boardRow(ctx, extra) {
    var row = document.createElement('div'); row.className = 'btnrow fixed';
    var b = document.createElement('button'); b.className = 'btn board'; b.textContent = '◀ Back to the board';
    ctx.on(b, 'click', function () { Lab.goTo('hub'); });
    (extra || []).forEach(function (e) { row.appendChild(e); });
    row.appendChild(b);
    return row;
  }

  /* Dựng 1 slide câu hỏi. Chế độ: tap (chạm chọn, chấm ngay) · drag (kéo thẻ vào ô) · vote (cả lớp bình chọn rồi lật) · word (ghép chữ) */
  Lab.quiz = function (root, ctx, n) {
    var Q = Lab.QZ[n];
    var LT = ['A', 'B', 'C', 'D'];
    var wrap = dv('qwrap stagger');
    var card = dv('qcard');
    card.appendChild(dv('qnum', 'Question ' + n));
    if (Q.word) {
      var im0 = ctx.img(capy(n), { alt: 'Capybara', zoom: false, class: 'capy float-anim' });
      card.append(im0, dv('qtext', 'Unscramble these letters to get the correct word.'), dv('letters', Q.letters));
    } else if (Q.fig) {
      var qt = dv('qtext'); qt.innerHTML = Lab.m(Q.q);
      var fg = dv('qfig');
      if (Q.fig === 'svg5') fg.appendChild(Lab.figQ5()); else fg.appendChild(ctx.img(Q.fig, { alt: 'Figure for question ' + n }));
      card.append(fg, qt);
    } else {
      var im = ctx.img(capy(n), { alt: 'Capybara', zoom: false, class: 'capy float-anim' });
      var qt2 = dv('qtext'); qt2.innerHTML = Lab.m(Q.q);
      card.append(im, qt2);
    }
    wrap.appendChild(card);
    root.appendChild(wrap);

    var win = function () { Engine.toast('🎉 You caught capybara ' + n + '!'); };

    if (Q.word) {
      var side = dv('qside');
      var slots = dv('slots'), tiles = dv('ltiles');
      var filled = [];
      var sl = Q.word.split('').map(function () { var s = dv('slot1'); slots.appendChild(s); return s; });
      var tl = Q.letters.split('').map(function (ch, i) {
        var b = document.createElement('button'); b.className = 'ltile'; b.textContent = ch;
        ctx.on(b, 'click', function () {
          if (filled.length >= sl.length) return;
          Sound.playEffect('click'); filled.push(b); b.classList.add('used'); paint();
        });
        tiles.appendChild(b); return b;
      });
      sl.forEach(function (s, i) {
        ctx.on(s, 'click', function () {
          if (i >= filled.length) return;
          var out = filled.splice(i, 1)[0]; out.classList.remove('used'); paint();
        });
      });
      function paint() {
        ctx.clearResult(slots);
        sl.forEach(function (s, i) { s.textContent = filled[i] ? filled[i].textContent : ''; s.classList.toggle('full', !!filled[i]); });
      }
      side.append(dv('note', 'Tap the letters in order. Tap a box to take a letter back.'), slots, tiles);
      wrap.appendChild(side);
      root.appendChild(ctx.buttons({
        check: function () {
          var w = filled.map(function (b) { return b.textContent; }).join('');
          var ok = w === Q.word; ctx.markResult(slots, ok);
          if (ok) { Sound.speak(Q.word.toLowerCase()); win(); }
          return { correct: ok ? 1 : 0, total: 1 };
        },
        show: function () {
          filled = []; tl.forEach(function (b) { b.classList.remove('used'); });
          Q.word.split('').forEach(function (ch) { var b = tl.find(function (x) { return x.textContent === ch && filled.indexOf(x) < 0; }); filled.push(b); b.classList.add('used'); });
          paint(); Sound.speak(Q.word.toLowerCase());
        },
        reset: function () { filled = []; tl.forEach(function (b) { b.classList.remove('used'); }); paint(); }
      }));
      root.lastChild.appendChild(boardRow(ctx).firstChild);
      return;
    }

    if (Q.mode === 'drag') {
      var side2 = dv('qside');
      var dd = ctx.dragDrop({
        items: Q.o.map(function (t, i) { return { id: 'o' + i, label: LT[i] + '. ' + t }; }),
        zones: [{ id: 'ans', accept: ['o' + Q.a], capacity: 1 }],
        renderZone: function () { return dv('card dd-zone ansbox'); }
      });
      side2.append(dv('note', 'Drag the correct answer into the box.'), dd.zoneEls.ans, dd.tray);
      wrap.appendChild(side2);
      root.appendChild(ctx.buttons({
        check: function () { var r = Lab.ddCheck(ctx, dd, [{ id: 'ans', accept: ['o' + Q.a] }]); if (r.correct) win(); return r; },
        show: function () { dd.reset(); Lab.ddClear(ctx, dd); var n0 = dd.tray.querySelector('[data-dd-id="o' + Q.a + '"]'); dd.zoneEls.ans.appendChild(n0); dd.place['o' + Q.a] = 'ans'; },
        reset: function () { dd.reset(); Lab.ddClear(ctx, dd); }
      }));
      root.lastChild.appendChild(boardRow(ctx).firstChild);
      return;
    }

    var col = dv('optcol');
    var tried = false, solved = false;
    var opts = Q.o.map(function (t, i) {
      var b = document.createElement('button'); b.className = 'qopt';
      var lt = dv('lt', LT[i]); lt.setAttribute('aria-hidden', 'true');
      var tx = document.createElement('span'); tx.className = 'tx'; tx.innerHTML = Lab.m(t);
      b.append(lt, tx);
      if (Q.mode === 'vote') { b.__n = 0; b.__t = dv('tally', '0'); b.appendChild(b.__t); }
      ctx.on(b, 'click', function () {
        if (Q.mode === 'vote') { if (solved) return; b.__n++; b.__t.textContent = b.__n; b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge'); Sound.playEffect('click'); return; }
        if (solved || b.classList.contains('dim')) return;
        var ok = i === Q.a;
        ctx.markResult(b, ok, { sound: false });
        if (!tried) { tried = true; Engine.score(ok ? 1 : 0, 1); } else Sound.playEffect(ok ? 'ok' : 'bad');
        if (ok) { solved = true; win(); opts.forEach(function (x, j) { if (j !== i) x.classList.add('dim'); }); }
        else b.classList.add('dim');
      });
      col.appendChild(b); return b;
    });
    wrap.appendChild(col);
    if (Q.mode === 'vote') {
      var rev = document.createElement('button'); rev.className = 'btn btn-show'; rev.textContent = '👁 Reveal the answer';
      var rs = document.createElement('button'); rs.className = 'btn btn-reset'; rs.textContent = '↺ Reset';
      ctx.on(rev, 'click', function () {
        if (solved) return; solved = true;
        opts.forEach(function (x, j) { if (j === Q.a) ctx.markResult(x, true); else x.classList.add('dim'); });
        Sound.playEffect('ok'); Engine.confetti(); win();
        Engine.done['q' + n] = 1; try { Store.sess('done', Engine.done); } catch (e) { }
      });
      ctx.on(rs, 'click', function () { solved = false; opts.forEach(function (x) { ctx.clearResult(x); x.classList.remove('dim'); x.__n = 0; x.__t.textContent = '0'; }); });
      root.insertBefore(dv('note fixed', 'Class vote! Tap an answer to add a vote, then reveal.'), wrap);
      root.appendChild(boardRow(ctx, [rev, rs]));
    } else {
      root.insertBefore(dv('note fixed', 'Tap the correct answer.'), wrap);
      root.appendChild(boardRow(ctx));
    }
  };
})(window);
