Engine.register({
  id: 'presentation', section: 'Project', title: 'Presentation', mech: 'speak', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Presentation' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1.4fr) minmax(0,.8fr)' });
    const Q = ['What object did you choose?', 'What angles did you find?', 'Why are they adjacent supplementary or vertically opposite angles?'];
    const list = h('div', { class: 'qlist' });
    Q.forEach((q, i) => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '✓' }), h('span', { text: (i + 1) + '. ' + q })]);
      ctx.on(b, 'click', () => { b.classList.toggle('on'); if (b.classList.contains('on')) Sound.speak(q); if (list.querySelectorAll('.on').length === Q.length) { Engine.confetti('star'); Engine.toast('Great presentation! 👏'); } });
      list.appendChild(b);
    });
    const t1 = h('button', { class: 'btn', text: '⏱ 60s' });
    const t2 = h('button', { class: 'btn', text: '⏱ 90s' });
    ctx.on(t1, 'click', () => Engine.timer(60)); ctx.on(t2, 'click', () => Engine.timer(90));
    const left = h('div', {}, [h('div', { class: 'note', text: 'Present your work. Tap each question when you answer it.' }), list, h('div', { class: 'btnrow' }, [t1, t2])]);
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/presenter.png', { alt: 'A student presenting', zoom: false, class: 'hero-img float-anim' })]);
    sp.append(left, media);
    root.appendChild(sp);
  }
});
