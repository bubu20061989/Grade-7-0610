Engine.register({
  id: 'writing-problem', section: 'Writing', title: 'D. Writing: find all the angles', mech: 'keypad', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/prob.png', { alt: 'Lines xy and mn intersect at A; angle xAm = 35 degrees', class: 'hero-img' }), ctx.zoomHint()]);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'probtext', html: 'Two straight lines <i>xy</i> and <i>mn</i> intersect at a point A. Given that the measure of angle <i>xAm</i> is 35°, find the measure of all other angles.' }));
    const ng = Lab.numGroup(ctx, 3, 3);
    const lab = (t) => { const s = h('span', {}); s.innerHTML = Lab.m(t) + ' ='; return s; };
    const rows = h('div', { class: 'numrows' });
    ['^nAy', '^xAn', '^mAy'].forEach((t, i) => rows.appendChild(h('div', { class: 'numrow' }, [lab(t), ng.fields[i]])));
    right.append(h('div', { class: 'rowwrap', style: 'flex:0 0 auto;align-items:center' }, [rows, Lab.keypad(ctx, ng.key)]));
    sp.append(media, right);
    root.appendChild(sp);
    root.appendChild(ctx.buttons({ check: () => ng.check([35, 145, 145]), show: () => ng.show([35, 145, 145]), reset: () => ng.reset() }));
  }
});
