Engine.register({
  id: 'q10', section: 'Review', title: 'Review question 10', mech: 'quiz', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 10);
  }
});
