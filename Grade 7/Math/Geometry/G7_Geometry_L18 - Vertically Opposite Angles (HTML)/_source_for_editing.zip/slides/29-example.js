Engine.register({
  id: 'example', section: 'Project', title: 'Example', mech: 'listen', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Example' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Look at the example. Tap a button to listen, then say it together.' }));
    const media = h('div', { class: 'grow center-col stagger' }, [h('div', { class: 'media fill-w', style: 'flex:1 1 auto;min-height:0;display:flex;align-items:center;justify-content:center;background:#fff;border-radius:28px;box-shadow:var(--shadow);padding:clamp(6px,1vh,14px)' }, [ctx.img('assets/img/example.png', { alt: 'Example: open laptop (adjacent supplementary angles) and scissors (vertically opposite angles)', class: 'hero-img' })]), ctx.zoomHint()]);
    root.appendChild(media);
    const T1 = 'Object: open laptop. A 1 and A 2 are adjacent supplementary angles because they share a common vertex, the hinge, and a common side, the screen.';
    const T2 = 'Object: scissors. A 1 and A 3 are vertically opposite angles. A 2 and A 4 are vertically opposite angles.';
    const b1 = h('button', { class: 'btn', text: '🔊 Laptop' }), b2 = h('button', { class: 'btn', text: '🔊 Scissors' });
    const sp = h('button', { class: 'btn', text: '🔦 Spotlight' });
    ctx.on(b1, 'click', () => Sound.speak(T1)); ctx.on(b2, 'click', () => Sound.speak(T2)); ctx.on(sp, 'click', () => Engine.spotlight());
    root.appendChild(h('div', { class: 'btnrow fixed' }, [b1, b2, sp]));
  }
});
