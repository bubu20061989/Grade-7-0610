Engine.register({
  id: 'project', section: 'Project', title: 'Angles around us', mech: 'intro', bg: 'project',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const fig = h('div', { class: 'coverfig' });
    const viz = h('div', { class: 'angviz' });
    const X = Lab.cross(ctx, { a1: 195, theta: 65, interactive: true });
    viz.appendChild(X.el);
    fig.append(viz, h('div', { class: 'note', text: '👆 Where can you see angles like these?' }));
    media.appendChild(fig);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Project' }), h('span', { class: 'tag', text: 'Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Angles <em>around us</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    const say = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak('Angles around us'));
    txt.append(t, h('div', { class: 'hero-sub', text: 'Find adjacent supplementary and vertically opposite angles in everyday objects.' }), h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [go, say]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
