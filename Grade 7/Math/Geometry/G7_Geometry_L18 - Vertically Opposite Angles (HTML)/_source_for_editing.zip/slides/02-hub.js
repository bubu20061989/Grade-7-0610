Engine.register({
  id: 'hub', section: 'Review', title: 'Review: catch the capybaras', mech: 'hub', bg: 'space2',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Pick a number to catch a capybara and answer its question!' }));
    const grid = h('div', { class: 'hubgrid stagger' });
    const left = [];
    for (let n = 1; n <= 12; n++) {
      const done = !!(Engine.done && Engine.done['q' + n]);
      const b = h('button', { class: 'tile' + (done ? ' done' : ''), 'aria-label': 'Question ' + n });
      b.appendChild(ctx.img(Lab.capy(n), { alt: '', zoom: false, class: 'capyimg' + (done ? ' float-anim' : '') }));
      if (!done) { b.appendChild(ctx.img('assets/img/net.png', { alt: '', zoom: false, class: 'netimg' })); left.push(n); }
      b.appendChild(h('span', { class: 'num', text: String(n).padStart(2, '0') }));
      if (done) b.appendChild(h('span', { class: 'tick', text: '✓' }));
      ctx.on(b, 'click', () => { Sound.playEffect('click'); Lab.goTo('q' + n); });
      grid.appendChild(b);
    }
    root.appendChild(grid);
    const rnd = h('button', { class: 'btn btn-primary', text: '🎲 Random number' });
    ctx.on(rnd, 'click', () => {
      if (!left.length) { Engine.toast('All 12 capybaras caught! 🎉'); Engine.confetti('star'); return; }
      const n = left[Math.floor(Math.random() * left.length)];
      const tile = grid.children[n - 1];
      tile.classList.remove('nudge'); void tile.offsetWidth; tile.classList.add('nudge');
      Engine.toast('Number ' + n + '!');
      ctx.timeout(() => Lab.goTo('q' + n), 700);
    });
    const after = h('button', { class: 'btn', text: 'Skip to Lead-in ▶' });
    ctx.on(after, 'click', () => Lab.goTo('leadin'));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [rnd, after]));
    if (!left.length) ctx.timeout(() => Engine.confetti('star'), 400);
  }
});
