Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Vertically Opposite Angles', mech: 'intro', bg: 'cover',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const fig = h('div', { class: 'coverfig' });
    const viz = h('div', { class: 'angviz' });
    const X = Lab.cross(ctx, { a1: 200, theta: 40, interactive: true });
    viz.appendChild(X.el);
    fig.append(viz, h('div', { class: 'note', text: '👆 Drag the orange dot — what do you notice?' }));
    media.appendChild(fig);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 4: Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<span class="l18">Lesson 18</span>Vertically Opposite <em>Angles</em>';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths" }), h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
