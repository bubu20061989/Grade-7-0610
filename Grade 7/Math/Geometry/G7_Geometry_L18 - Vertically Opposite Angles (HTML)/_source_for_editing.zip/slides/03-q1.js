Engine.register({
  id: 'q1', section: 'Review', title: 'Review question 1', mech: 'quiz', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 1);
  }
});
