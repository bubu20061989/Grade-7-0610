Engine.register({
  id: 'maths-corner', section: 'Maths Corner', title: 'What is a pair of vertically opposite angles?', mech: 'explore', bg: 'page2',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' });
    const viz = h('div', { class: 'angviz' });
    const ro = h('div', { class: 'readout' });
    const X = Lab.cross(ctx, { a1: 200, theta: 40, interactive: true, numbers: true, onChange: (s) => {
      ro.innerHTML = '';
      ro.append(h('span', { class: 'r b', text: 'Angle 1 = Angle 3 = ' + s.th + '°' }), h('span', { class: 'r o', text: 'Angle 2 = Angle 4 = ' + (180 - s.th) + '°' }));
    } });
    viz.appendChild(X.el);
    media.append(viz, ro);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'qtitle', text: 'What is a pair of vertically opposite angles?' }));
    right.appendChild(h('div', { class: 'mcdef', html: 'A pair of <b>vertically opposite angles</b> is formed when two <b>straight lines intersect</b> at a point.' }));
    right.appendChild(h('div', { class: 'mcdef', html: 'The two angles are located <b>directly opposite</b> each other through the vertex.' }));
    right.appendChild(h('div', { class: 'note', text: '👆 Drag the orange dot to turn a line. Tap an angle to see its pair.' }));
    const rl = h('button', { class: 'btn', text: '↺ Turn' });
    const rr = h('button', { class: 'btn', text: 'Turn ↻' });
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    ctx.on(rl, 'click', () => X.rotate(10)); ctx.on(rr, 'click', () => X.rotate(-10));
    ctx.on(say, 'click', () => Sound.speak('A pair of vertically opposite angles is formed when two straight lines intersect at a point. The two angles are located directly opposite each other through the vertex.'));
    right.appendChild(h('div', { class: 'btnrow' }, [rl, rr, say]));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
