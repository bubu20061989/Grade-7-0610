Engine.register({
  id: 'writing-steps', section: 'Writing', title: 'D. Writing: explain each step', mech: 'match', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing · Solution' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each explanation to the matching step.' }));
    const E = ['Substitute ^xAm = 35 degrees.', 'Move 35 degrees to the right-hand side and change its sign.', 'Simplify the right-hand side, we obtain the result is 145 degrees.'];
    const dd = ctx.dragDrop({
      items: E.map((t, i) => ({ id: 'e' + i, html: t })),
      zones: E.map((_, i) => ({ id: 'x' + i, accept: ['e' + i], capacity: 1 })),
      renderItem: (it) => { const n = h('div', { class: 'chip long' }); n.appendChild(h('span', { html: Lab.m(it.html) })); return n; },
      renderZone: () => h('div', { class: 'dd-zone slot' })
    });
    const sol = h('div', { class: 'sol grow center-col stagger' });
    sol.appendChild(Lab.para('Since ^xAm and ^xAn are a pair of <b>adjacent supplementary</b> angles,', {}, 'sub para'));
    const eg = h('div', { class: 'eqgrid', style: 'width:100%' });
    ['^xAm + ^xAn = 180°', '35° + ^xAn = 180°', '^xAn = 180° − 35°', '^xAn = 145°.'].forEach((e, i) => {
      eg.append(h('div', { class: 'eq', html: Lab.m(e) }), i ? dd.zoneEls['x' + (i - 1)] : h('div', {}));
    });
    sol.appendChild(eg);
    root.appendChild(sol);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
