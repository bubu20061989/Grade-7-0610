Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'build', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const V = [['vertically opposite angles', 'c-blu'], ['straight line', 'c-grn'], ['intersect', 'c-pur']];
    const chips = h('div', { class: 'vchips' });
    V.forEach(([w, c]) => { const b = h('button', { class: 'vchip ' + c, text: w }); ctx.on(b, 'click', () => { b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge'); Sound.speak(w); }); chips.appendChild(b); });
    const top = h('div', { class: 'pcard fixed' }, [h('div', { class: 'plabel', html: '<b>Vocabulary</b> — tap to listen' }), chips]);
    root.appendChild(top);
    const dd = ctx.dragDrop({
      items: [{ id: 'a', label: 'vertically opposite angles' }, { id: 'b', label: 'straight lines' }, { id: 'c', label: 'intersect' }],
      zones: [{ id: 'za', accept: ['a'], capacity: 1 }, { id: 'zb', accept: ['b'], capacity: 1 }, { id: 'zc', accept: ['c'], capacity: 1 }],
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const S = 'A pair of vertically opposite angles is formed when two straight lines intersect at a point.';
    const card = h('div', { class: 'pcard grow stagger' }, [
      h('div', { class: 'plabel', html: '<b>Sentence pattern</b> — build it, then say it together' }),
      Lab.para('A pair of [[za]] is formed when two [[zb]] [[zc]] at a point.', { za: dd.zoneEls.za, zb: dd.zoneEls.zb, zc: dd.zoneEls.zc }, 'para'),
      dd.tray
    ]);
    root.appendChild(card);
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Say it together' });
    ctx.on(say, 'click', () => Sound.speak(S));
    const row = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    row.insertBefore(say, row.firstChild);
    root.appendChild(row);
    root.appendChild(h('div', { class: 'note fixed', text: '📖 Prepare the next lesson.' }));
  }
});
