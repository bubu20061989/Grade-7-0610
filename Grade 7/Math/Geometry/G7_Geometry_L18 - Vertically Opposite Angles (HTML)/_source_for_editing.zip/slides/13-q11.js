Engine.register({
  id: 'q11', section: 'Review', title: 'Review question 11', mech: 'drag1', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 11);
  }
});
