Engine.register({
  id: 'q7', section: 'Review', title: 'Review question 7', mech: 'vote', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 7);
  }
});
