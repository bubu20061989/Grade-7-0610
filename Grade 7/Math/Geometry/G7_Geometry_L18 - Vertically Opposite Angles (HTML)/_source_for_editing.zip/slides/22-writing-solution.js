Engine.register({
  id: 'writing-solution', section: 'Writing', title: 'D. Writing: solution steps 1–2', mech: 'cloze', bg: 'page2',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing · Solution' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks to complete the solution.' }));
    const dd = ctx.dragDrop({
      items: [{ id: 'vo', label: 'vertically opposite' }, { id: 'as', label: 'adjacent supplementary' }],
      zones: [{ id: 's1', accept: ['vo'], capacity: 1 }, { id: 's2', accept: ['as'], capacity: 1 }],
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const z = dd.zoneEls;
    const sol = h('div', { class: 'sol' }, [
      Lab.para('First, we find the measure of angle nAy.', {}, 'bul'),
      Lab.para('Since ^xAm and ^nAy are a pair of [[s1]] angles, ^nAy = ^xAm = 35°.', z, 'sub para'),
      Lab.para('Next, we find the measure of angle xAn.', {}, 'bul'),
      Lab.para('Since ^xAm and ^xAn are a pair of [[s2]] angles, ...', z, 'sub para')
    ]);
    const fig = h('div', { class: 'mini' }, [ctx.img('assets/img/prob.png', { alt: 'Lines xy and mn intersect at A; angle xAm = 35 degrees' })]);
    root.appendChild(h('div', { class: 'rowwrap stagger' }, [h('div', { class: 'colhalf', style: 'flex:0 1 30%' }, [fig]), h('div', { class: 'colhalf', style: 'flex:1 1 70%' }, [sol])]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
