Engine.register({
  id: 'q5', section: 'Review', title: 'Review question 5', mech: 'quizfig', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 5);
  }
});
