Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary flashcards', mech: 'flashcard', bg: 'page2',
  render(root, ctx) {
    const W = [
      { w: 'vertically', pos: '(adverb)', ipa: '/ˈvɜːtɪkəli/', c: 'c-blu', def: 'in a vertical direction; from top to bottom', ex: '<b>Example:</b> Line AB is drawn <b>vertically</b>.' },
      { w: 'opposite', pos: '(adjective)', ipa: '/ˈɒpəzɪt/', c: 'c-org', def: 'facing or pointing in different directions', ex: '<b>Example:</b> The two rays point in <b>opposite</b> directions.' },
      { w: 'straight line', pos: '(noun)', ipa: '/streɪt laɪn/', c: 'c-grn', def: 'a line that has no curves or bends', ex: '<b>Example:</b> Points A, B, and C lie on the same <b>straight line</b>.' },
      { w: 'intersect', pos: '(verb)', ipa: '/ˌɪntəˈsekt/', c: 'c-pur', def: 'to cross at a common point', ex: '<b>Example:</b> Lines AB and CD <b>intersect</b> at point O.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    const dots = h('div', { class: 'dots fixed' });
    grow.append(h('div', { class: 'fc-wrap' }, [box]));
    root.appendChild(grow);
    root.appendChild(dots);
    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      const fig = h('div', { class: 'vimg' }, [h('div', { class: 'vfig float-anim' }, [Lab.vocabFig(i)])]);
      front.append(fig, h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: v.pos }), h('div', { class: 'vipa', text: v.ipa })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def }), h('div', { class: 'vex', html: v.ex }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; Engine.toast('🎉 All 4 words!'); Engine.confetti('star'); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
