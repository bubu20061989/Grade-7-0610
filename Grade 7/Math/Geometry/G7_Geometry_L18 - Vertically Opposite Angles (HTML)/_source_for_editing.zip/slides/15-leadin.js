Engine.register({
  id: 'leadin', section: 'Lead-in', title: 'Lead-in: the scissors problem', mech: 'keypad', bg: 'page',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.85fr) minmax(0,1.15fr)' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/boy.png', { alt: 'A boy opening a pair of scissors; the angle between the blades is 30 degrees', class: 'hero-img' }), ctx.zoomHint()]);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'probtext', html: '<b>Opening problem</b><br>Imagine you are holding a pair of scissors. Now, you want to open the scissors so that the angle between the two blades is 30°. What should be the angle between the two handles of the scissors?' }));
    const ng = Lab.numGroup(ctx, 1, 3);
    const kp = h('div', { class: 'leadkp' }, [h('div', { class: 'numrow', style: 'justify-content:center' }, [h('span', { text: 'Handles:' }), ng.fields[0]]), Lab.keypad(ctx, ng.key)]);
    const ans = h('div', { class: 'bubble hide', html: 'The two handles continue the two blades through the pivot, so the angle between the handles and the angle between the blades are <b>vertically opposite angles</b>.<br><b>Angle between the handles = 30°</b>' });
    right.append(kp, ans);
    sp.append(media, right);
    root.appendChild(sp);
    const flip = (on) => { ans.classList.toggle('hide', !on); };
    root.appendChild(ctx.buttons({
      check: () => { const r = ng.check([30]); flip(true); return r; },
      show: () => { ng.show([30]); flip(true); },
      reset: () => { ng.reset(); flip(false); }
    }));
  }
});
