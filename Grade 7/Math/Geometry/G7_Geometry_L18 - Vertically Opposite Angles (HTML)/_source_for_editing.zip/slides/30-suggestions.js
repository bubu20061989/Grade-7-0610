Engine.register({
  id: 'suggestions', section: 'Project', title: 'Suggestions: find the angles', mech: 'spot', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Suggestions' }));
    /* tâm từng đồ vật (% ảnh sug.jpg) + loại góc theo slide đáp án gốc (sug-ans.jpg) */
    const OBJ = [
      ['pencil case', .345, .19, 'as'], ['bottle', .54, .20, 'as'], ['book', .75, .20, 'as'], ['pizza', .14, .38, 'as'],
      ['pencils', .34, .44, 'vo'], ['clock', .54, .57, 'as'], ['rulers', .75, .43, 'vo'], ['two sticks', .74, .66, 'vo'],
      ['chopsticks', .17, .71, 'vo'], ['set square and protractor', .39, .84, 'as'], ['fan', .72, .83, 'as']
    ];
    let mode = 'as';
    const tags = {};
    const pick = h('div', { class: 'tagpick fixed' });
    const bAS = h('button', { class: 'btn as on', text: 'Adjacent supplementary' });
    const bVO = h('button', { class: 'btn vo', text: 'Vertically opposite' });
    [[bAS, 'as'], [bVO, 'vo']].forEach(([b, m]) => ctx.on(b, 'click', () => { mode = m; bAS.classList.toggle('on', m === 'as'); bVO.classList.toggle('on', m === 'vo'); Sound.playEffect('click'); }));
    pick.append(h('span', { class: 'note', text: 'Choose a label, then tap an object:' }), bAS, bVO);
    root.appendChild(pick);
    const spots = OBJ.map((o, i) => ({ x: o[1], y: o[2], i }));
    const hw = ctx.hotspots('assets/img/sug.jpg', spots, {
      alt: 'Everyday objects: pencil case, bottle, book, pizza, pencils, clock, rulers, sticks, chopsticks, set square and protractor, fan', tolerance: 0.085,
      onPick: (hit) => {
        if (!hit) return;
        const i = hit.i;
        if (tags[i]) tags[i].remove();
        if (tags[i] && tags[i].__m === mode) { delete tags[i]; Sound.playEffect('click'); return; }
        const t = h('i', { class: 'tagmark ' + mode, text: mode === 'as' ? 'AS' : 'VO', style: 'left:' + OBJ[i][1] * 100 + '%;top:' + OBJ[i][2] * 100 + '%' });
        t.__m = mode; hw.appendChild(t); tags[i] = t; Sound.speak(OBJ[i][0]);
      }
    });
    const media = h('div', { class: 'sugmedia stagger' }, [hw]);
    root.appendChild(media);
    root.appendChild(h('div', { class: 'note fixed', text: 'AS = adjacent supplementary angles · VO = vertically opposite angles' }));
    const im = hw.querySelector('img');
    root.appendChild(ctx.buttons({
      check: () => { let c = 0; OBJ.forEach((o, i) => { const t = tags[i]; if (t) { const ok = t.__m === o[3]; if (ok) c++; ctx.markResult(t, ok, { badge: false, shake: false }); t.textContent = (t.__m === 'as' ? 'AS' : 'VO') + (ok ? ' ✓' : ' ✗'); } }); return { correct: c, total: OBJ.length }; },
      show: () => { Object.keys(tags).forEach(k => { tags[k].remove(); delete tags[k]; }); im.src = 'assets/img/sug-ans.jpg'; Engine.toast('Red + green arcs show the angles'); },
      reset: () => { Object.keys(tags).forEach(k => { tags[k].remove(); delete tags[k]; }); im.src = 'assets/img/sug.jpg'; }
    }));
  }
});
