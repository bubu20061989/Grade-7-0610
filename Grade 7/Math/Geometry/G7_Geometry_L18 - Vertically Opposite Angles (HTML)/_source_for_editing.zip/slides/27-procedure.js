Engine.register({
  id: 'procedure', section: 'Project', title: '2. Procedure', mech: 'order', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '2. Procedure' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.7fr) minmax(0,1.3fr)' });
    const media = h('div', { class: 'media' }, [
      ctx.img('assets/img/p-adj.png', { alt: 'Adjacent supplementary angles 1 and 2', class: 'hero-img' }),
      ctx.img('assets/img/p-cross.png', { alt: 'Two intersecting lines', class: 'hero-img' })
    ]);
    const S = [
      'Choose one object with adjacent supplementary angles and one object with vertically opposite angles.',
      'Draw the objects in the two boxes.',
      'Label and identify adjacent supplementary and vertically opposite angles.',
      'Decorate your drawings and present your work to the class.'
    ];
    const st = Lab.steps(ctx, S);
    sp.append(media, h('div', {}, [h('div', { class: 'note', text: 'Tap the steps in the right order: 1 → 4.' }), st.el]));
    root.appendChild(sp);
    root.appendChild(ctx.buttons({ check: () => st.check(), show: () => st.show(), reset: () => st.reset() }));
  }
});
