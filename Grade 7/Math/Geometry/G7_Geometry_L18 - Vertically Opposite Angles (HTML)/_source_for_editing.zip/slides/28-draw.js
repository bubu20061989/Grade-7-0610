Engine.register({
  id: 'draw', section: 'Project', title: '3. Draw and analyze', mech: 'draw', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '3. Draw and analyze' }));
    const COL = [['Red', '#DC2626'], ['Blue', '#1D4ED8'], ['Green', '#15803D'], ['Orange', '#EA580C'], ['Black', '#0F172A']];
    const row = h('div', { class: 'drawrow stagger' });
    const cans = [];
    let color = COL[0][1], width = 8, active = null;
    [['as', 'Adjacent Supplementary Angles'], ['vo', 'Vertically Opposite Angles']].forEach(([k, t]) => {
      const c = ctx.canvas({ color, width });
      cans.push(c);
      ctx.on(c, 'pointerdown', () => { active = c; c.__color = color; c.__w = width; });
      row.appendChild(h('div', { class: 'drawcol' }, [h('div', { class: 'hd ' + k, text: t }), h('div', { class: 'workarea' }, [c])]));
    });
    root.appendChild(row);
    const pal = h('div', { class: 'palette fixed' });
    COL.forEach(([n, c], i) => {
      const b = h('button', { class: 'sw' + (i ? '' : ' on'), text: n, style: 'background:' + c });
      ctx.on(b, 'click', () => { color = c; pal.querySelectorAll('.sw').forEach(x => x.classList.toggle('on', x === b)); cans.forEach(cv => cv.__color = c); Sound.speak(n); });
      pal.appendChild(b);
    });
    [['Thin', 5], ['Thick', 12]].forEach(([n, w]) => { const b = h('button', { class: 'btn', text: n }); ctx.on(b, 'click', () => { width = w; cans.forEach(cv => cv.__w = w); }); pal.appendChild(b); });
    const undo = h('button', { class: 'btn', text: '↩ Undo' });
    ctx.on(undo, 'click', () => (active || cans[0]).__undo());
    pal.appendChild(undo);
    root.appendChild(pal);
    root.appendChild(ctx.buttons({
      check: () => { Engine.toast('Did you label the angles and name them?'); Sound.speak('Did you label the angles? Which angles are adjacent supplementary? Which are vertically opposite?'); },
      show: () => { Engine.lightbox('assets/img/example.png', 'Example: open laptop and scissors'); },
      reset: () => { cans.forEach(cv => cv.__clear()); }
    }));
  }
});
