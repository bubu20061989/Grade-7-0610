Engine.register({
  id: 'q3', section: 'Review', title: 'Review question 3', mech: 'quiz', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 3);
  }
});
