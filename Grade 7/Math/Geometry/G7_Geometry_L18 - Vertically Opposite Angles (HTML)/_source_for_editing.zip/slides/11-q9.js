Engine.register({
  id: 'q9', section: 'Review', title: 'Review question 9', mech: 'unscramble', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 9);
  }
});
