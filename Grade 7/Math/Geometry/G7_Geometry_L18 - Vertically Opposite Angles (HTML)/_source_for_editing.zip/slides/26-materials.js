Engine.register({
  id: 'materials', section: 'Project', title: '1. Materials', mech: 'checklist', bg: 'project',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '1. Materials' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Do you have everything? Tap each one you have.' }));
    const M = [['m-pencil', 'Pencil & eraser'], ['m-ruler', 'Ruler'], ['m-protractor', 'Protractor'], ['m-colours', 'Coloured pencils']];
    const grid = h('div', { class: 'matgrid stagger' });
    M.forEach(([img, name]) => {
      const b = h('button', { class: 'matcard' }, [h('div', { class: 'im' }, [ctx.img('assets/img/' + img + '.png', { alt: name, zoom: false })]), h('div', { class: 'lb' }, [h('span', { class: 'box', text: '✓' }), h('span', { text: name })])]);
      ctx.on(b, 'click', () => {
        b.classList.toggle('on'); Sound.playEffect('click');
        if (b.classList.contains('on')) Sound.speak(name.replace('&', 'and'));
        if (grid.querySelectorAll('.matcard.on').length === M.length) { Engine.toast('Ready to start! 🎉'); Engine.confetti('star'); }
      });
      grid.appendChild(b);
    });
    root.appendChild(grid);
  }
});
