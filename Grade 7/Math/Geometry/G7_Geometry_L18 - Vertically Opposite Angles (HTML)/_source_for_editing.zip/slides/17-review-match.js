Engine.register({
  id: 'review-match', section: 'Vocabulary', title: 'Review: match words and pictures', mech: 'match', bg: 'page3',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each word to its picture' }));
    const words = ['vertically', 'opposite', 'straight line', 'intersect'];
    const dd = ctx.dragDrop({
      items: words.map((w, i) => ({ id: 'w' + i, label: w })),
      zones: words.map((w, i) => ({ id: 'z' + i, accept: ['w' + i], capacity: 1 })),
      renderZone: () => h('div', { class: 'dd-zone slot' })
    });
    const grid = h('div', { class: 'imgrid grow stagger', style: 'grid-template-columns:repeat(4,minmax(0,1fr))' });
    words.forEach((w, i) => {
      const fig = h('div', { class: 'vfig' }, [Lab.vocabFig(i)]);
      const cell = h('div', { class: 'card matchcard' }, [fig, dd.zoneEls['z' + i]]);
      grid.appendChild(cell);
    });
    root.appendChild(grid);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => { const r = dd.check(); if (r.correct === r.total) words.forEach((w, k) => ctx.timeout(() => Sound.speak(w), k * 900)); return r; },
      show: () => dd.show(),
      reset: () => dd.reset()
    }));
  }
});
