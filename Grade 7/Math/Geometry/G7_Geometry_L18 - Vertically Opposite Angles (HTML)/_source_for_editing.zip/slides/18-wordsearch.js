Engine.register({
  id: 'wordsearch', section: 'Vocabulary', title: 'A. Vocabulary: word search', mech: 'wordsearch', bg: 'page',
  render(root, ctx) {
    const G = ['ALTTSONEHLSGER', 'GEXCCTPGJHPETD', 'OYDESTRPVSTNYX', 'VIESSFNAOTOODN', 'ERIRAETGISGGOX', 'RCEERIEFRGITNV', 'TLITVGCRCNHTEF',
      'IDTNENTRINXTEG', 'CFEIRTVIELSPOD', 'AGEATJDIIXHALF', 'LSEAEGCNSOPDTG', 'LASAXMEFCLSAVA', 'YVSYGCOEEAIHEG', 'TTXLIHGGDOIVRG'];
    /* vị trí tìm được trong ô chữ gốc: [hàng, cột, dHàng, dCột] */
    const WORDS = [['VERTEX', 6, 4, 1, 0], ['STRAIGHT', 0, 4, 1, 1], ['LINE', 8, 9, 1, -1], ['VERTICALLY', 3, 0, 1, 0], ['OPPOSITE', 0, 5, 1, 1], ['INTERSECT', 8, 3, -1, 0]];
    root.appendChild(h('div', { class: 'pill fixed', text: 'A. Vocabulary' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1.25fr) minmax(0,1fr)' });
    const box = h('div', { class: 'wsbox' });
    const grid = h('div', { class: 'wsgrid', role: 'grid', 'aria-label': 'Word search puzzle' });
    const cells = [];
    G.forEach((row, r) => row.split('').forEach((ch, c) => { const d = h('div', { class: 'c', text: ch }); d.dataset.r = r; d.dataset.c = c; grid.appendChild(d); cells.push(d); }));
    const at = (r, c) => cells[r * 14 + c];
    box.appendChild(grid);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'note', html: 'Find the words <b>vertex, straight, line, vertically, opposite, intersect</b> in the puzzle and give their meanings.' }));
    const list = h('div', { class: 'wslist' });
    const found = {};
    const btns = WORDS.map((w, i) => { const b = h('button', { class: 'wsword' }, [h('span', { class: 'mk' }), h('span', { text: w[0].toLowerCase() })]); ctx.on(b, 'click', () => Sound.speak(w[0].toLowerCase())); list.appendChild(b); return b; });
    const msg = h('div', { class: 'wsmeaning', text: 'Tap the first letter, then the last letter of a word (or drag across it).' });
    right.append(list, msg);
    sp.append(box, right);
    root.appendChild(sp);

    const paintWord = (i) => { const [, r, c, dr, dc] = WORDS[i]; for (let k = 0; k < WORDS[i][0].length; k++) at(r + dr * k, c + dc * k).classList.add('f' + i); btns[i].classList.add('found'); found[i] = 1; };
    const clearSel = () => cells.forEach(x => x.classList.remove('sel'));
    const line = (a, b) => {
      const r0 = +a.dataset.r, c0 = +a.dataset.c, r1 = +b.dataset.r, c1 = +b.dataset.c;
      const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0), n = Math.max(Math.abs(r1 - r0), Math.abs(c1 - c0));
      if (!(r0 === r1 || c0 === c1 || Math.abs(r1 - r0) === Math.abs(c1 - c0))) return null;
      const out = []; for (let k = 0; k <= n; k++) out.push(at(r0 + dr * k, c0 + dc * k)); return out;
    };
    let start = null, downAt = null, moved = false;
    const cellAt = (e) => { const el = document.elementFromPoint(e.clientX, e.clientY); return el && el.classList && el.classList.contains('c') && grid.contains(el) ? el : null; };
    const finish = (endCell) => {
      const seg = line(start, endCell); clearSel();
      const s = start; start = null;
      if (!seg) { Sound.playEffect('bad'); return; }
      const word = seg.map(x => x.textContent).join('');
      const i = WORDS.findIndex(w => w[0] === word || w[0] === word.split('').reverse().join(''));
      if (i >= 0 && !found[i]) {
        paintWord(i); Sound.playEffect('ok'); Sound.speak(WORDS[i][0].toLowerCase());
        msg.textContent = '✓ ' + WORDS[i][0].toLowerCase() + ' — what does it mean? Tell the class!';
        if (Object.keys(found).length === WORDS.length) { Engine.confetti('star'); Engine.score(6, 6); }
      } else if (i < 0) { Sound.playEffect('bad'); seg.forEach(x => { x.classList.remove('shake'); void x.offsetWidth; x.classList.add('shake'); }); }
      void s;
    };
    ctx.on(grid, 'pointerdown', (e) => {
      const c = cellAt(e); if (!c) return;
      e.preventDefault();
      if (start && start !== c) { finish(c); return; }
      start = c; downAt = c; moved = false; clearSel(); c.classList.add('sel');
    });
    ctx.on(grid, 'pointermove', (e) => {
      if (!start || !downAt || !(e.buttons & 1) && e.pointerType === 'mouse') return;
      const c = cellAt(e); if (!c || c === start) return;
      moved = true; clearSel(); (line(start, c) || [start]).forEach(x => x.classList.add('sel'));
    });
    ctx.on(document, 'pointerup', (e) => {
      if (!downAt) return;
      const c = cellAt(e); downAt = null;
      if (moved && start && c && c !== start) finish(c);
    });
    root.appendChild(ctx.buttons({
      check: () => { const n = Object.keys(found).length; btns.forEach((b, i) => found[i] ? ctx.markResult(b, true) : ctx.markResult(b, false)); return { correct: n, total: WORDS.length }; },
      show: () => { WORDS.forEach((_, i) => { if (!found[i]) paintWord(i); ctx.clearResult(btns[i]); }); },
      reset: () => { Object.keys(found).forEach(k => delete found[k]); cells.forEach(x => { x.className = 'c'; }); btns.forEach(b => { b.classList.remove('found'); ctx.clearResult(b); }); start = null; msg.textContent = 'Tap the first letter, then the last letter of a word (or drag across it).'; }
    }));
  }
});
