Engine.register({
  id: 'practice', section: 'Practice', title: 'C. Practice: fill in the blanks', mech: 'cloze', bg: 'page3',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks about the measures of two angles in the diagrams.' }));
    const W = ['adjacent', 'supplementary', 'vertically', 'opposite'];
    const dd = ctx.dragDrop({
      items: W.map((w, i) => ({ id: 'w' + i, label: w })),
      zones: [{ id: 'a1', accept: ['w0'], capacity: 1 }, { id: 'a2', accept: ['w1'], capacity: 1 }, { id: 'b1', accept: ['w2'], capacity: 1 }, { id: 'b2', accept: ['w3'], capacity: 1 }],
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const z = dd.zoneEls;
    const tbl = h('div', { class: 'practbl grow stagger' });
    const row = (img, alt, text) => {
      tbl.append(h('div', { class: 'pfig' }, [ctx.img(img, { alt })]), Lab.para(text, z, 'para pst'));
    };
    row('assets/img/prac1.png', 'Angles mEp and pEn on line mn', 'We can see that angle mEp and angle pEn are a pair of [[a1]] [[a2]] angles. Hence, ^mEp + ^pEn = 180°.');
    row('assets/img/prac2.png', 'Lines xy and zt intersect at O', 'We can see that angle xOz and angle yOt are a pair of [[b1]] [[b2]] angles. Hence, ^xOz = ^yOt.');
    root.appendChild(tbl);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
