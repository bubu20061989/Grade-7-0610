Engine.register({
  id: 'q2', section: 'Review', title: 'Review question 2', mech: 'drag1', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 2);
  }
});
