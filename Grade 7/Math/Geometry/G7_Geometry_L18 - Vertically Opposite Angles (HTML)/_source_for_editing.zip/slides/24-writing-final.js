Engine.register({
  id: 'writing-final', section: 'Writing', title: 'D. Writing: the last angle', mech: 'choose', bg: 'page3',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing · Solution' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the correct choice in each box.' }));
    const P = ['vertically opposite', 'adjacent supplementary'], D = ['35°', '145°'];
    const c1 = Lab.ich(ctx, P, 1), c2 = Lab.ich(ctx, D, 1);
    const k1 = Lab.ich(ctx, D, 0), k2 = Lab.ich(ctx, D, 1), k3 = Lab.ich(ctx, D, 1);
    const grp = Lab.ichGroup([c1, c2, k1, k2, k3]);
    const sol = h('div', { class: 'sol grow center-col stagger' });
    sol.append(
      Lab.para('Finally, we find the measure of angle mAy.', {}, 'bul'),
      Lab.para('Since ^xAm and ^mAy are a pair of [[c1]] angles, ^mAy = ^xAn = [[c2]].', { c1, c2 }, 'sub para'),
      Lab.para('In conclusion, the measure of angle nAy is [[k1]], the measure of angle xAn is [[k2]], and the measure of angle mAy is [[k3]].', { k1, k2, k3 }, 'concl para'));
    const fig = h('div', { class: 'mini' }, [ctx.img('assets/img/prob.png', { alt: 'Lines xy and mn intersect at A; angle xAm = 35 degrees' })]);
    root.appendChild(h('div', { class: 'rowwrap stagger' }, [h('div', { class: 'colhalf', style: 'flex:0 1 26%' }, [fig]), h('div', { class: 'colhalf', style: 'flex:1 1 74%' }, [sol])]));
    root.appendChild(ctx.buttons({ check: () => grp.check(), show: () => grp.show(), reset: () => grp.reset() }));
  }
});
