Engine.register({
  id: 'q6', section: 'Review', title: 'Review question 6', mech: 'quizfig', bg: 'space',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    Lab.quiz(root, ctx, 6);
  }
});
