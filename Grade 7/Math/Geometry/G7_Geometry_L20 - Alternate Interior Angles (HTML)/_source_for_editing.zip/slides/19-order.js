Engine.register({
  id: 'order', section: 'Hands-on', title: 'Put the steps in order', mech: 'order', bg: 'green',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Put the steps in order' }));
    const imgs = ['image78.png', 'image79.png', 'image80.png', 'image81.png', 'image82.png', 'image83.png'];
    const items = imgs.map((f, i) => ({ id: 's' + i, img: f }));
    const zones = imgs.map((_, i) => ({ id: 'z' + i, accept: ['s' + i], capacity: 1 }));
    const tray = h('div', { class: 'dd-tray ordtray fixed' });
    this._dd = ctx.dragDrop({
      items, zones, tray,
      renderItem: it => { const d = h('div', { class: 'imgitem' }); const im = h('img', { src: 'assets/img/' + it.img, alt: 'A step photo', draggable: 'false' }); d.appendChild(im); return d; },
      renderZone: z => h('div', { class: 'card ordslot' }, [h('span', { class: 'sn', text: 'Step ' + (+z.id.slice(1) + 1) })])
    });
    const slots = h('div', { class: 'ordslots stagger' });
    zones.forEach(z => slots.appendChild(this._dd.zoneEls[z.id]));
    root.append(slots, h('div', { class: 'note fixed onphoto', style: 'align-self:center', text: 'Drag each photo to its step (or tap a photo, then tap a step)' }), tray);
    root.appendChild(ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() }));
  }
});
