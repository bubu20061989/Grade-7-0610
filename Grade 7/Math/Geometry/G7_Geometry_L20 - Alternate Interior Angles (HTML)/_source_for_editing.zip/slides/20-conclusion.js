Engine.register({
  id: 'conclusion', section: 'Hands-on', title: '3. Conclusion: turn the straw', mech: 'sim', bg: 'green',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '3. Conclusion' }));
    const sp = h('div', { class: 'split stagger' });
    const right = h('div', {});
    const left = h('div', {});
    const card = h('div', { class: 'card' });
    card.appendChild(h('div', { class: 'para', style: 'text-align:center;color:#2F6B52;font-weight:800', text: 'What happens to the corresponding angles when you move the straw?' }));
    const opts = h('div', { class: 'optgrid', style: 'grid-template-columns:minmax(0,1fr)' });
    let answered = false;
    [['They stay equal.', true], ['They become different.', false]].forEach(([t, ok]) => {
      const b = h('button', { class: 'opt', text: t });
      ctx.on(b, 'click', () => {
        ctx.markResult(b, ok, { sound: answered });
        if (!answered) { answered = true; Engine.score(ok ? 1 : 0, 1); }
      });
      opts.appendChild(b);
    });
    card.appendChild(opts);
    left.append(card, h('div', { class: 'note onphoto', text: 'Turn the straw on the model, then answer' }));
    const sectors = [
      { key: 'p1ar', value: 1 }, { key: 'p2ar', value: 1 },   // đồng vị
      { key: 'p1bl', value: 1 }, { key: 'p2al', value: 0 }
    ];
    const g = Lab.geo({ id: 'cc', theta: 55, r: 80, sectors: [{ key: 'p1ar', value: 1 }, { key: 'p2ar', value: 1 }, { key: 'p1bl', value: 1 }] });
    const COL = { p1ar: '#EC4899', p2ar: '#0EA5E9', p1bl: '#22C55E' };
    Object.keys(COL).forEach(k => { g.secs[k].style.fill = COL[k]; g.secs[k].style.opacity = '.85'; if (g.vals[k]) g.vals[k].style.fill = COL[k]; });
    let mode = 'corr';
    const paintMode = () => {
      const vis = mode === 'corr' ? ['p1ar', 'p2ar'] : ['p1bl', 'p2ar'];
      Object.keys(COL).forEach(k => { const on = vis.indexOf(k) >= 0; g.secs[k].style.display = on ? '' : 'none'; if (g.vals[k]) g.vals[k].style.display = on ? '' : 'none'; });
      bC.classList.toggle('on', mode === 'corr'); bA.classList.toggle('on', mode === 'alt');
    };
    const bC = h('button', { class: 'btn', text: 'Corresponding' });
    const bA = h('button', { class: 'btn', text: 'Alternate interior' });
    ctx.on(bC, 'click', () => { mode = 'corr'; paintMode(); });
    ctx.on(bA, 'click', () => { mode = 'alt'; paintMode(); });
    const gc = h('div', { class: 'geocard big fill-w' }); gc.appendChild(g.el);
    let anim = null;
    const turn = (d) => {
      const from = g.theta(), to = Math.max(35, Math.min(145, from + d));
      if (to === from) { Engine.toast('The straw cannot turn further'); return; }
      if (anim) clearInterval(anim);
      const t0 = Date.now(), dur = document.body.classList.contains('nomotion') ? 1 : 450;
      anim = ctx.interval(() => {
        const k = Math.min(1, (Date.now() - t0) / dur), e = 1 - Math.pow(1 - k, 3);
        g.set(from + (to - from) * e);
        if (k >= 1) { clearInterval(anim); anim = null; }
      }, 30);
      Sound.playEffect('click');
    };
    const tl = h('button', { class: 'btn btn-primary', text: '↶ Turn' });
    const tr = h('button', { class: 'btn btn-primary', text: 'Turn ↷' });
    ctx.on(tl, 'click', () => turn(15));
    ctx.on(tr, 'click', () => turn(-15));
    right.append(h('div', { class: 'modebar' }, [bC, bA]), gc, h('div', { class: 'btnrow' }, [tl, tr]));
    sp.append(left, right);
    root.appendChild(sp);
    paintMode();
  }
});
