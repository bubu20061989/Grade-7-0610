Engine.register({
  id: 'model', section: 'Hands-on', title: '3D model of corresponding angles', mech: 'section', bg: 'green',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    media.appendChild(ctx.img('assets/img/image83.png', { alt: 'The finished straw model on two protractors', class: 'hero-img float-anim' }));
    const txt = h('div', { class: 'cover-text onphoto', style: 'padding:clamp(10px,2.4vh,30px) clamp(14px,2vw,34px)' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Geometry' }), h('span', { class: 'tag', text: 'Hands-on' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '3D Model of <em>Corresponding</em> Angles';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's build ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: 'Materials → Procedure → Conclusion' }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
