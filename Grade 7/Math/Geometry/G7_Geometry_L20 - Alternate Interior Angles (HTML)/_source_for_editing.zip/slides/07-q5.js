Engine.register({
  id: 'q5', section: 'Warm-up', title: 'Q5 · El Aziziya', mech: 'quiz', bg: 'photo:image43.png',
  render(root, ctx) {
    Lab.pvzQuestion(root, ctx, { n: 5, variant: 'quiz', zombie: 'image32.gif',
      q: 'How many degree Celsius is it in El Aziziya, Libya?',
      opts: ['57,8 degrees Celsius', '28 degrees Celsius', '12 degrees Celsius', '-57 degrees Celsius'], ans: 0 });
  }
});
