Engine.register({
  id: 'leadin', section: 'Lead-in', title: 'Opening problem: the Z-shape table', mech: 'numpad', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Opening problem' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image46.png', { alt: 'Z-shape table: 60° at the floor, ? at the tabletop', class: 'hero-img' }), ctx.zoomHint());
    const side = h('div', {});
    side.appendChild(h('div', { class: 'probtxt', html: '<span class="ttl">Uncle Lam</span> is constructing a Z-shape table. If the angle formed by the inclined bar and the leg of the table on the ground measures 60 degrees, what should be the angle between the inclined bar and the tabletop to ensure that the tabletop is parallel to the ground?' }));
    let val = '';
    const box = h('span', { class: 'ansbox', text: '?' });
    const paint = () => { box.textContent = val ? val + '°' : '?'; };
    side.appendChild(h('div', { class: 'conso' }, [h('div', { class: 'row' }, [h('span', { class: 'lab', text: 'The angle at the tabletop =' }), box])]));
    const work = h('div', { class: 'center-col' });
    const pad = Lab.keypad(ctx, k => {
      ctx.clearResult(box);
      if (k === '⌫') val = val.slice(0, -1); else if (k === 'C') val = ''; else if (val.length < 3) val += k;
      paint();
    });
    work.appendChild(pad);
    side.appendChild(work);
    const explain = () => {
      work.innerHTML = '';
      work.appendChild(h('div', { class: 'explain pop-in', html: 'The inclined bar acts as a transversal intersecting the tabletop and the ground (or table leg). To ensure the tabletop is parallel to the ground, the alternate interior angles must be equal. <b>Since the angle between the inclined bar and the leg on the ground is 60°, the angle between the inclined bar and the tabletop must also be 60°</b>' }));
    };
    sp.append(media, side);
    root.appendChild(sp);
    root.appendChild(ctx.buttons({
      check: () => {
        const ok = val.trim() === '60';
        ctx.markResult(box, ok);
        if (ok) explain();
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { val = '60'; paint(); ctx.clearResult(box); explain(); },
      reset: () => { val = ''; paint(); ctx.clearResult(box); work.innerHTML = ''; work.appendChild(pad); }
    }));
  }
});
