Engine.register({
  id: 'consolidation', section: 'Consolidation', title: 'Consolidation', mech: 'unscramble', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const g = h('div', { class: 'grow center-col' });
    const card = h('div', { class: 'stagecard conso stagger' });
    const vrow = h('div', { class: 'row' }, [h('span', { class: 'lab', text: 'Vocabulary:' })]);
    ['alternate', 'interior'].forEach(w => { const c = h('button', { class: 'vchip', text: '🔊 ' + w }); ctx.on(c, 'click', () => Sound.speak(w)); vrow.appendChild(c); });
    const parts = ['A pair of alternate interior angles', 'is formed', 'when a transversal line', 'intersects', 'a pair of straight lines.'];
    const line = h('div', { class: 'buildline' });
    const bank = h('div', { class: 'chunks' });
    const mk = (t) => { const b = h('button', { text: t }); ctx.on(b, 'click', () => { ctx.clearResult(line); Sound.playEffect('click'); (b.parentNode === bank ? line : bank).appendChild(b); }); return b; };
    let order = ctx.shuffle(parts.map((_, i) => i));
    if (order.every((v, i) => v === i)) order = order.reverse();
    const btns = parts.map(mk);
    order.forEach(k => bank.appendChild(btns[k]));
    card.append(vrow,
      h('div', { class: 'row' }, [h('span', { class: 'lab', text: 'Define alternate interior angles — build the sentence pattern:' })]),
      line, bank,
      h('div', { class: 'note', text: '📚 Prepare the next lesson.' }));
    g.appendChild(card);
    root.appendChild(g);
    root.appendChild(ctx.buttons({
      check: () => {
        const got = Array.from(line.children).map(b => b.textContent).join(' ');
        const ok = got === parts.join(' ');
        ctx.markResult(line, ok);
        if (ok) Sound.speak(got);
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { ctx.clearResult(line); btns.forEach(b => line.appendChild(b)); Sound.speak(parts.join(' ')); },
      reset: () => { ctx.clearResult(line); order.forEach(k => bank.appendChild(btns[k])); }
    }));
  }
});
