Engine.register({
  id: 'listening', section: 'B. Listening', title: 'Listen: name the diagrams', mech: 'listen', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Listen and write A, B or C' }));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [Lab.player(ctx, 'assets/audio/media2.mp3', 'Track 26'), h('span', { class: 'note', text: 'Drag A, B, C to the right diagram' })]));
    const items = [{ id: 'A', label: 'A' }, { id: 'B', label: 'B' }, { id: 'C', label: 'C' }];
    const ans = ['A', 'C', 'B'];
    const zones = ans.map((a, i) => ({ id: 'd' + i, accept: [a], capacity: 1 }));
    this._dd = ctx.dragDrop({
      items, zones,
      renderZone: () => h('div', { class: 'card dd-zone bin' }, [h('span', { class: 'dlab', text: 'Diagram' })])
    });
    const grid = h('div', { class: 'lgrid stagger' });
    ans.forEach((_, i) => {
      const cell = h('div', { class: 'cell' });
      cell.appendChild(Lab.cropBox('assets/img/image51.png', 2172, 724, [30, 770, 1480][i], 30, 665, 440, 'Diagram ' + (i + 1)));
      cell.appendChild(this._dd.zoneEls['d' + i]);
      grid.appendChild(cell);
    });
    root.append(grid, this._dd.tray);
    root.appendChild(ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() }));
  }
});
