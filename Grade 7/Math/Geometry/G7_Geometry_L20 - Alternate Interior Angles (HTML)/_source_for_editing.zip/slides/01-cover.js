Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Alternate Interior Angles', mech: 'intro', bg: 'paper',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const pic = ctx.img('assets/img/image3.png', { alt: 'Geometry tools, a board and a book', zoom: false, class: 'hero-img float-anim' });
    pic.style.cursor = 'pointer';
    ctx.on(pic, 'click', () => { pic.classList.remove('nudge'); void pic.offsetWidth; pic.classList.add('nudge'); Sound.speak('Alternate interior angles'); });
    media.appendChild(pic);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 4 · Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Lesson 20:<br>Alternate <em>Interior</em> Angles';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths" }), h('div', { class: 'note', text: '👆 Tap the picture to hear the lesson name' }), h('div', { class: 'btnrow' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
