/* Bảng 5 làn PvZ (slide 2 + 3 + 9 gốc): bấm làn nào nhảy đúng câu đó, làn đã xong tự đánh dấu ✓ */
Engine.register({
  id: 'hub', section: 'Warm-up', title: 'Plants vs. Zombies', mech: 'hub', bg: 'lawn',
  render(root, ctx) {
    const lanesDef = [
      { id: 'q1', plant: 'image18.png', zom: 'image28.gif', place: 'Ho Chi Minh City' },
      { id: 'q2', plant: 'image15.png', zom: 'image29.gif', place: 'Mount McKinley' },
      { id: 'q3', plant: 'image13.png', zom: 'image31.gif', place: 'Tower of Pisa' },
      { id: 'q4', plant: 'image14.png', zom: 'image27.gif', place: 'Oymyakon' },
      { id: 'q5', plant: 'image16.png', zom: 'image32.gif', place: 'El Aziziya' }
    ];
    const head = h('div', { class: 'pvzhead fixed' });
    head.append(ctx.img('assets/img/image37.png', { alt: 'Plants vs. Zombies', zoom: false, class: 'logo' }),
      h('div', { class: 'grow1' }, [h('div', { class: 'tag onphoto', text: 'Pick a lane — stop the zombie!' })]));
    head.appendChild(Lab.player(ctx, 'assets/audio/media1.mp3', 'Theme'));
    root.appendChild(head);

    const lanes = h('div', { class: 'lanes stagger' });
    const left = [];
    lanesDef.forEach((d, i) => {
      const cleared = !!Engine.done[d.id];
      const ln = h('button', { class: 'lane' + (cleared ? ' cleared' : '') });
      const pl = h('img', { src: 'assets/img/' + d.plant, alt: 'Plant' });
      const z = h('img', { src: 'assets/img/' + d.zom, alt: 'Zombie', class: 'zom' });
      const mid = h('div', { class: 'lbl', text: (cleared ? '✓ ' : '') + d.place });
      if (cleared) mid.classList.add('tick');
      ln.append(h('span', { class: 'num', text: '0' + (i + 1) }), pl, mid, z);
      ctx.on(ln, 'click', () => { Sound.playEffect('click'); Lab.goTo(d.id); });
      lanes.appendChild(ln);
      if (!cleared) left.push(d.id);
    });
    root.appendChild(lanes);

    const row = h('div', { class: 'btnrow fixed' });
    if (left.length) {
      const rnd = h('button', { class: 'btn btn-primary', text: '🎲 Random lane' });
      ctx.on(rnd, 'click', () => Lab.goTo(left[Math.floor(Math.random() * left.length)]));
      row.append(rnd, h('div', { class: 'tag onphoto', text: (5 - left.length) + ' / 5 zombies stopped' }));
    } else {
      const done = h('div', { class: 'allclear', text: '🏆 THANK YOU — all zombies stopped!' });
      const nx = h('button', { class: 'btn btn-primary pulse', text: 'Lead-in ▶' });
      ctx.on(nx, 'click', () => Lab.goTo('leadin'));
      row.append(done, nx);
      ctx.timeout(() => Engine.confetti('star'), 350);
    }
    root.appendChild(row);
  }
});
