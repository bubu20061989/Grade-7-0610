Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary: alternate, interior', mech: 'flashcard', bg: 'paper',
  render(root, ctx) {
    const cards = [
      { word: 'alternate', col: 0, def: 'angles that are on opposite sides of a transversal.', ex: '<b>Example: Alternate</b> interior angles lie on opposite sides of a transversal and between two parallel lines.' },
      { word: 'interior', col: 1, def: 'angles or regions that are inside the two lines cut by a transversal.', ex: '<b>Example:</b> The <b>interior</b> angles are located between the two parallel lines.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    const dots = h('div', { class: 'dots fixed' });
    const wrap = h('div', { class: 'grow center-col vocabfc' });
    const fw = h('div', { class: 'fc-wrap' });
    wrap.appendChild(fw);
    root.append(dots, wrap);
    let i = 0; const seen = {};
    const show = () => {
      seen[i] = 1;
      const c = cards[i];
      fw.innerHTML = '';
      const fc = h('div', { class: 'fc pop-in' });
      const front = h('div', { class: 'face front' });
      const row = h('div', { class: 'fcrow' });
      const l = h('div', {}); l.appendChild(Lab.crop('assets/img/image47.png', 2, c.col, 1774, 887, c.word));
      const r = h('div', {});
      r.append(h('div', { class: 'word', text: c.word }), h('div', { class: 'pron', text: 'Say it aloud!' }), h('div', { class: 'tapflip', text: '👆 Tap the card to see the meaning' }));
      row.append(l, r); front.appendChild(row);
      const back = h('div', { class: 'face back' });
      back.append(h('div', { class: 'word', text: c.word }), h('div', { class: 'def', text: c.def }), h('div', { class: 'ex', html: c.ex }));
      fc.append(front, back);
      ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); if (fc.classList.contains('flipped')) Sound.speak(c.def); });
      fw.appendChild(fc);
      dots.innerHTML = '';
      cards.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      if (Object.keys(seen).length === cards.length && i === cards.length - 1) ctx.timeout(() => Engine.confetti(), 300);
    };
    const prev = h('button', { class: 'btn', text: '◀', title: 'Previous card' });
    const listen = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    const rep = h('button', { class: 'btn', text: '🔁 x3' });
    const next = h('button', { class: 'btn', text: '▶', title: 'Next card' });
    ctx.on(prev, 'click', () => { i = (i + cards.length - 1) % cards.length; show(); });
    ctx.on(next, 'click', () => { i = (i + 1) % cards.length; show(); });
    ctx.on(listen, 'click', () => Sound.speak(cards[i].word));
    ctx.on(rep, 'click', () => Sound.repeat(cards[i].word, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [prev, listen, rep, next]));
    show();
  }
});
