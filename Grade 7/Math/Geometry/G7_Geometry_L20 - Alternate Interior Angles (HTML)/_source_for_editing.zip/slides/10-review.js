Engine.register({
  id: 'review', section: 'Vocabulary', title: 'Review: match the meanings', mech: 'match', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Drag each meaning next to the right word' }));
    const items = [
      { id: 'd1', label: 'angles that are on opposite sides of a transversal.' },
      { id: 'd2', label: 'angles or regions that are inside the two lines cut by a transversal.' }
    ];
    const zones = [
      { id: 'alt', accept: ['d1'], capacity: 1 },
      { id: 'int', accept: ['d2'], capacity: 1 }
    ];
    this._dd = ctx.dragDrop({ items, zones });
    const grid = h('div', { class: 'lgrid rows stagger' });
    ['alt', 'int'].forEach((z, k) => {
      const cell = h('div', { class: 'cell' });
      cell.appendChild(Lab.crop('assets/img/image47.png', 2, k, 1774, 887, k ? 'interior' : 'alternate'));
      const zn = this._dd.zoneEls[z];
      zn.style.flexDirection = 'column'; zn.style.alignItems = 'stretch';
      cell.appendChild(zn);
      grid.appendChild(cell);
    });
    this._dd.tray.classList.add('small-items');
    root.append(grid, this._dd.tray);
    root.appendChild(ctx.buttons({ check: () => this._dd.check(), show: () => this._dd.show(), reset: () => this._dd.reset() }));
  }
});
