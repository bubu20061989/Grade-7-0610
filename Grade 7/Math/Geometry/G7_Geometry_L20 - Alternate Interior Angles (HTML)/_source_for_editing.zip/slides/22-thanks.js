Engine.register({
  id: 'thanks', section: 'Consolidation', title: 'Thanks!', mech: 'outro', bg: 'paper',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const pic = h('div', { class: 'crowd' });
    const gang = h('div', { class: 'gang' });
    ['image24.png', 'image25.png', 'image16.png', 'image18.png', 'image15.png', 'image20.png', 'image21.png', 'image23.png'].forEach(f => gang.appendChild(h('img', { src: 'assets/img/' + f, alt: '' })));
    pic.append(gang, h('div', { class: 'ty', text: 'THANK YOU' }), ctx.img('assets/img/image19.png', { alt: 'Plants vs. Zombies', zoom: false, class: 'fitimg' }));
    pic.style.cursor = 'pointer';
    ctx.on(pic, 'click', () => { Engine.confetti('star'); Sound.speak('Thank you!'); });
    media.appendChild(pic);
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Thanks!</em>';
    txt.append(t, h('div', { class: 'hero-sub', style: 'font-style:italic;color:#1E3A8A', text: '“Angles define perspectives; changing them changes everything.”' }));
    const stars = Engine.stars, wrong = Engine.wrongList().filter(id => Engine.slides.some(s => s.id === id));
    const msg = stars > 0 ? 'You earned ' + stars + ' ⭐ today — well done!' : 'Thanks for learning with us today!';
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: msg })]));
    const row = h('div', { class: 'btnrow' });
    if (wrong.length) {
      const b = h('button', { class: 'btn btn-primary', text: '↩ Let\'s review (' + wrong.length + ')' });
      ctx.on(b, 'click', () => Lab.goTo(wrong[0]));
      row.appendChild(b);
    }
    const home = h('button', { class: 'btn', text: '⌂ Back to start' });
    ctx.on(home, 'click', () => Engine.go(0, 'jump'));
    row.appendChild(home);
    txt.appendChild(row);
    cov.append(media, txt);
    root.appendChild(cov);
    if (stars > 0) ctx.timeout(() => Engine.confetti('star'), 500);
  }
});
