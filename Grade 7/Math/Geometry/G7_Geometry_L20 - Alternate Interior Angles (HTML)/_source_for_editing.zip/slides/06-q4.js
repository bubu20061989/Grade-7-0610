Engine.register({
  id: 'q4', section: 'Warm-up', title: 'Q4 · Oymyakon', mech: 'shoot', bg: 'photo:image42.png',
  render(root, ctx) {
    Lab.pvzQuestion(root, ctx, { n: 4, variant: 'shoot', zombie: 'image27.gif',
      q: 'How many degree Celsius is it in Oymyakon village, Russia?',
      opts: ['4 degrees Celsius', '25 degrees Celsius', '47 degrees Celsius', '-47 degrees Celsius'], ans: 3 });
  }
});
