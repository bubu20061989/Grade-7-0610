Engine.register({
  id: 'q2', section: 'Warm-up', title: 'Q2 · Mount McKinley', mech: 'shoot', bg: 'photo:image40.png',
  render(root, ctx) {
    Lab.pvzQuestion(root, ctx, { n: 2, variant: 'shoot', zombie: 'image29.gif',
      q: 'How many degree Celsius is it in Mount McKinley, Alaska?',
      opts: ['-34 degrees Celsius', '-73 degrees Celsius', '34 degrees Celsius', '73 degrees Celsius'], ans: 1 });
  }
});
