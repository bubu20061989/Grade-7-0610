Engine.register({
  id: 'practice', section: 'C. Practice', title: 'Fill in the blanks', mech: 'cloze', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Fill in the blanks' }));
    const items = [
      { id: 'ai1', label: 'alternate interior' }, { id: 'ai2', label: 'alternate interior' },
      { id: 'par', label: 'parallel' }, { id: 'tra', label: 'transversal' }
    ];
    const zones = [
      { id: 'z1', accept: ['ai1', 'ai2'], capacity: 1 }, { id: 'z2', accept: ['ai1', 'ai2'], capacity: 1 }, { id: 'z3', accept: ['par'], capacity: 1 }
    ];
    this._dd = ctx.dragDrop({ items, zones, renderZone: () => h('span', { class: 'dd-zone slot' }) });
    const Z = this._dd.zoneEls;
    const sp = h('div', { class: 'split wide-side stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image52.png', { alt: 'Figures and statements table', class: 'hero-img' }), ctx.zoomHint());
    const side = h('div', {});
    const p = (html, slots) => { const d = h('div', { class: 'para small', html: Lab.fmt(html) }); d.querySelectorAll('[data-s]').forEach(s => s.replaceWith(slots[s.dataset.s])); return d; };
    side.append(
      h('div', { class: 'stmt' }, [p('We can see that {M1} and {N1} are a pair of <i data-s="a"></i> angles. Also, line a and line b are parallel. Therefore, we obtain: {M1} = {N1}.', { a: Z.z1 })]),
      h('div', { class: 'stmt' }, [p('We can see that {A1} and {B1} are a pair of <i data-s="a"></i> angles. Moreover, {A1} = {B1}. Hence, line x and line y are <i data-s="b"></i>.', { a: Z.z2, b: Z.z3 })]),
      this._dd.tray);
    sp.append(media, side);
    root.appendChild(sp);
    root.appendChild(ctx.buttons({ check: () => Lab.ddCheck(ctx, this._dd, zones), show: () => { Object.values(Z).forEach(z => ctx.clearResult(z)); this._dd.show(); }, reset: () => { Object.values(Z).forEach(z => ctx.clearResult(z)); this._dd.reset(); } }));
  }
});
