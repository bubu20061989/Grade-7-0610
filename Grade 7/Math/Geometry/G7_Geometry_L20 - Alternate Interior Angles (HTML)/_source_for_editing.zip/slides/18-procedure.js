const STEPS_L20 = [
  { t: 'Draw 2 parallel lines on the paper.', img: 'image78.png' },
  { t: 'Cut the big straw into 4 small pieces (about 1 cm each) and stick them at the ends of the lines with double-sided tape.', img: 'image79.png' },
  { t: 'Stick 2 paper protractors in the middle of the 2 lines.', img: 'image80.png' },
  { t: 'Put 2 straws through the 4 small straw pieces on the paper.', img: 'image81.png' },
  { t: 'Place the last straw across the two. Pin it at the centers of the protractors.', img: 'image82.png' },
  { t: 'Turn the straw to see and compare the corresponding angles.', img: 'image83.png' }
];
Engine.register({
  id: 'procedure', section: 'Hands-on', title: '2. Procedure (6 steps)', mech: 'stepper', bg: 'green',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '2. Procedure' }));
    const dots = h('div', { class: 'dots fixed' });
    const g = h('div', { class: 'grow center-col' });
    const card = h('div', { class: 'stagecard', style: 'flex:1 1 auto;min-height:0;width:100%;max-width:none' });
    g.appendChild(card);
    root.append(dots, g);
    let i = 0; const seen = {};
    const show = () => {
      seen[i] = 1;
      const s = STEPS_L20[i];
      card.innerHTML = '';
      const row = h('div', { class: 'fcrow pop-in' });
      const l = h('div', {}); l.append(ctx.img('assets/img/' + s.img, { alt: 'Step ' + (i + 1), class: 'hero-img' }));
      const r = h('div', { style: 'align-items:flex-start' });
      r.append(h('div', { class: 'stepno', text: 'Step ' + (i + 1) + ' / 6' }), h('div', { class: 'steptext', text: s.t }));
      row.append(l, r); card.appendChild(row);
      dots.innerHTML = '';
      STEPS_L20.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
    };
    const prev = h('button', { class: 'btn', text: '◀ Step' });
    const listen = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    const next = h('button', { class: 'btn', text: 'Step ▶' });
    ctx.on(prev, 'click', () => { if (i > 0) { i--; show(); } });
    ctx.on(next, 'click', () => { if (i < STEPS_L20.length - 1) { i++; show(); } else Engine.toast('All 6 steps done — next: put them in order!'); });
    ctx.on(listen, 'click', () => Sound.speak(STEPS_L20[i].t));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [prev, listen, next]));
    show();
  }
});
