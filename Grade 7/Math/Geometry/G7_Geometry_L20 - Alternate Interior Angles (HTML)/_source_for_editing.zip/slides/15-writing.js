Engine.register({
  id: 'writing', section: 'D. Writing', title: 'Find the measure of angle N₁', mech: 'choose', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Complete the solution' }));
    const g = h('div', { class: 'split stagger' });
    const top = h('div', {});
    const prob = h('div', { class: 'card probcard', html: Lab.fmt('a) In the diagram on the right, a and b are two parallel lines. Given that measure of angle M₁ is 30°, find the measure of angle N₁.') });
    const dia = h('div', { class: 'geocard big' });
    dia.appendChild(Lab.cropBox('assets/img/image53.png', 2170, 725, 1230, 40, 820, 640, 'Diagram: lines a and b cut by a transversal at M and N'));
    top.append(prob, dia);
    const w1 = Lab.ich(ctx, ['alternate interior', 'corresponding'], 0);
    const w2 = Lab.ich(ctx, ['parallel', 'perpendicular'], 0);
    const w3 = Lab.ich(ctx, ['30°', '60°', '150°'], 0);
    const line = (html, w) => { const d = h('div', { class: 'para small', html: Lab.fmt(html) }); const s = d.querySelector('[data-s]'); if (s) s.replaceWith(w); return d; };
    const sol = h('div', { class: 'solcard' }, [
      h('div', { class: 'tagsol', text: 'Solution' }),
      line('We can see that {M1} and {N1} are a pair of <i data-s></i> angles.', w1),
      line('Also, line a and line b are <i data-s></i>.', w2),
      line('Therefore, we obtain: &nbsp; {N1} = {M1} = 30°.'),
      line('In conclusion, the measure of angle N₁ is <i data-s></i>.', w3)
    ]);
    g.append(top, h('div', {}, [sol]));
    root.appendChild(g);
    const grp = Lab.ichGroup([w1, w2, w3]);
    root.appendChild(ctx.buttons({ check: () => grp.check(), show: () => grp.show(), reset: () => grp.reset() }));
  }
});
