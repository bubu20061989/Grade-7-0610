Engine.register({
  id: 'q3', section: 'Warm-up', title: 'Q3 · Tower of Pisa', mech: 'quiz', bg: 'photo:image41.png',
  render(root, ctx) {
    Lab.pvzQuestion(root, ctx, { n: 3, variant: 'quiz', zombie: 'image31.gif',
      q: 'How many degrees is the tower of Pisa tilted?',
      opts: ['39,7 degrees', '45 degrees', '3,97 degrees', '90 degrees'], ans: 2 });
  }
});
