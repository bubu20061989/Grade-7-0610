Engine.register({
  id: 'q1', section: 'Warm-up', title: 'Q1 · Ho Chi Minh City', mech: 'quiz', bg: 'photo:image36.png',
  render(root, ctx) {
    Lab.pvzQuestion(root, ctx, { n: 1, variant: 'quiz', zombie: 'image28.gif',
      q: 'How many degree Celsius is it in Ho Chi Minh city?',
      opts: ['32 degrees Celsius', '17 degrees Celsius', '42 degrees Celsius', '-8 degrees Celsius'], ans: 0 });
  }
});
