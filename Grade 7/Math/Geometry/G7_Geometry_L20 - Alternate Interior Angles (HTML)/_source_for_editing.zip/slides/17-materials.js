Engine.register({
  id: 'materials', section: 'Hands-on', title: '1. Materials', mech: 'checklist', bg: 'green',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: '1. Materials' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' });
    media.append(ctx.img('assets/img/image71.png', { alt: 'Paper protractors, straws, push pins, pencil and ruler', class: 'hero-img' }), ctx.zoomHint());
    const side = h('div', {});
    side.appendChild(h('div', { class: 'note onphoto', text: '👆 Tap each thing your group has ready' }));
    const list = h('div', { class: 'checkl' });
    const mats = ['2 paper protractors', 'Double-sided tape', '3 small straws', '1 bigger straw', '2 push pins', 'Pencil & Ruler'];
    const on = new Set();
    const ready = h('div', { class: 'allclear', style: 'visibility:hidden', text: '✅ Ready to build!' });
    mats.forEach(m => {
      const b = h('button', {}, [h('span', { class: 'box', text: '✓' }), m]);
      ctx.on(b, 'click', () => {
        if (on.has(m)) on.delete(m); else { on.add(m); Sound.speak(m.replace('&', 'and')); }
        b.classList.toggle('on', on.has(m));
        const all = on.size === mats.length;
        if (all && ready.style.visibility === 'hidden') { Engine.confetti(); Sound.playEffect('ok'); }
        ready.style.visibility = all ? 'visible' : 'hidden';
      });
      list.appendChild(b);
    });
    const tape = ctx.img('assets/img/image76.png', { alt: 'Double-sided tape', zoom: false, class: 'fitimg' });
    side.append(list, h('div', { class: 'rowwrap', style: 'flex:1 1 12vh;align-items:center' }, [h('div', { class: 'colhalf', style: 'height:100%' }, [tape]), h('div', { class: 'colhalf' }, [ready])]));
    sp.append(media, side);
    root.appendChild(sp);
  }
});
