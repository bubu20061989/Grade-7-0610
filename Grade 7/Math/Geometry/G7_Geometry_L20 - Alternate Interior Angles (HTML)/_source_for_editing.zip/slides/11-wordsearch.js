Engine.register({
  id: 'wordsearch', section: 'A. Vocabulary', title: 'Word search', mech: 'wordsearch', bg: 'paper',
  render(root, ctx) {
    const G = ['LTAIGTAAREANNR', 'BRAFERRCTRVOIV', 'LASDMCSAAEFANB', 'ENSCVTACFFXMTR', 'TSSASXMNVBIFEO',
      'AVDLTTFCTVITRG', 'BERTCORSBDRTIC', 'XRMEEHRASXVHOB', 'CSNRSLLFIFESRS', 'VALNRFHTAGHTAT',
      'CLNAEVCMASHACL', 'XTTTTNFCSSBTVF', 'ATBENMFGHFDGNT', 'RRMTIFRNNTFESR'];
    const WORDS = [
      { w: 'TRANSVERSAL', a: [0, 1], b: [10, 1] }, { w: 'INTERSECT', a: [13, 4], b: [5, 4] },
      { w: 'STRAIGHT', a: [4, 4], b: [11, 11] }, { w: 'ALTERNATE', a: [4, 3], b: [12, 3] },
      { w: 'INTERIOR', a: [1, 12], b: [8, 12] }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'Find the words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the first letter, then the last letter. Then give their meanings.' }));
    const box = h('div', { class: 'wsbox stagger' });
    const grid = h('div', { class: 'wsgrid' });
    const cells = [];
    G.forEach((row, r) => { cells[r] = []; row.split('').forEach((ch, c) => { const d = h('div', { class: 'c', text: ch }); d.dataset.r = r; d.dataset.c = c; cells[r][c] = d; grid.appendChild(d); }); });
    const list = h('div', { class: 'wslist' });
    const found = {};
    const rows = WORDS.map(w => { const d = h('div', { class: 'w' }, [h('span', { class: 'box', text: '✓' }), w.w.toLowerCase()]); list.appendChild(d); return d; });
    box.append(grid, list);
    root.appendChild(box);

    const path = (a, b) => {
      const dr = Math.sign(b[0] - a[0]), dc = Math.sign(b[1] - a[1]);
      const n = Math.max(Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
      if (!(a[0] === b[0] || a[1] === b[1] || Math.abs(b[0] - a[0]) === Math.abs(b[1] - a[1]))) return null;
      const out = []; for (let k = 0; k <= n; k++) out.push([a[0] + dr * k, a[1] + dc * k]); return out;
    };
    const mark = (k) => {
      if (found[k]) return;
      found[k] = 1;
      path(WORDS[k].a, WORDS[k].b).forEach(([r, c]) => cells[r][c].classList.add('f' + k));
      rows[k].classList.add('found');
      Sound.speak(WORDS[k].w.toLowerCase());
    };
    let start = null;
    const clearSel = () => grid.querySelectorAll('.sel,.start').forEach(x => x.classList.remove('sel', 'start'));
    const tryLine = (a, b) => {
      const p = path(a, b); clearSel(); start = null;
      if (!p) { grid.classList.remove('shake'); void grid.offsetWidth; grid.classList.add('shake'); return; }
      const s = p.map(([r, c]) => G[r][c]).join('');
      const k = WORDS.findIndex(w => w.w === s || w.w === s.split('').reverse().join(''));
      if (k >= 0 && !found[k]) { Sound.playEffect('ok'); mark(k); if (Object.keys(found).length === WORDS.length) Engine.confetti('star'); }
      else { p.forEach(([r, c]) => cells[r][c].classList.add('sel')); Sound.playEffect('bad'); ctx.timeout(clearSel, 450); }
    };
    const cellAt = (e) => { const t = document.elementFromPoint(e.clientX, e.clientY); return t && t.classList && t.classList.contains('c') && grid.contains(t) ? t : null; };
    let downCell = null;
    ctx.on(grid, 'pointerdown', e => { const t = cellAt(e); if (!t) return; downCell = t; e.preventDefault(); });
    ctx.on(grid, 'pointerup', e => {
      const t = cellAt(e); if (!t || !downCell) return;
      const p0 = [+downCell.dataset.r, +downCell.dataset.c], p1 = [+t.dataset.r, +t.dataset.c];
      downCell = null;
      if (p0[0] !== p1[0] || p0[1] !== p1[1]) { tryLine(p0, p1); return; }     // kéo 1 nét
      if (!start) { start = p1; t.classList.add('start'); Sound.playEffect('click'); return; }
      if (start[0] === p1[0] && start[1] === p1[1]) { clearSel(); start = null; return; }
      tryLine(start, p1);                                                       // chạm 2 lần
    });
    root.appendChild(ctx.buttons({
      check: () => {
        const n = Object.keys(found).length;
        rows.forEach((d, k) => { ctx.clearResult(d); if (!found[k]) ctx.markResult(d, false); });
        return { correct: n, total: WORDS.length };
      },
      show: () => { rows.forEach(d => ctx.clearResult(d)); WORDS.forEach((_, k) => mark(k)); },
      reset: () => {
        Object.keys(found).forEach(k => delete found[k]);
        grid.querySelectorAll('.c').forEach(c => c.className = 'c');
        rows.forEach(d => { d.classList.remove('found'); ctx.clearResult(d); });
        start = null;
      }
    }));
  }
});
