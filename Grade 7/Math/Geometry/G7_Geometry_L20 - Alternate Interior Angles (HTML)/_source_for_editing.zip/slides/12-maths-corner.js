Engine.register({
  id: 'mathscorner', section: 'Maths Corner', title: 'What is a pair of alternate interior angles?', mech: 'hotspot', bg: 'paper',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    const sp = h('div', { class: 'split stagger' });
    const txt = h('div', {});
    const card = h('div', { class: 'card' });
    card.append(h('div', { class: 'h2', style: 'color:var(--accent);font-weight:800;font-family:var(--font-display);text-align:center', text: 'What is a pair of alternate interior angles?' }),
      h('ul', { class: 'para', style: 'margin:.3em 0 0;padding-left:1.1em' }, [
        h('li', { text: 'A pair of alternate interior angles is formed when a transversal line intersects a pair of straight lines.' }),
        h('li', { text: 'The two angles are located between the pair of straight lines but on different sides of the transversal line.' })]));
    const speak = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(speak, 'click', () => Sound.speak('A pair of alternate interior angles is formed when a transversal line intersects a pair of straight lines. The two angles are located between the pair of straight lines but on different sides of the transversal line.'));
    txt.append(card);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'note', text: '👆 Tap the 2 angles that make a pair of alternate interior angles' }));
    const keys = ['p1bl', 'p1br', 'p2al', 'p2ar'];
    const g = Lab.geo({ id: 'mc', theta: 58, r: 92, sectors: keys.map(k => ({ key: k, tap: true })) });
    const gc = h('div', { class: 'geocard big fill-w' }); gc.appendChild(g.el);
    right.appendChild(gc);
    const picked = new Set();
    keys.forEach(k => ctx.on(g.secs[k], 'click', () => {
      ctx.clearResult(gc);
      if (picked.has(k)) picked.delete(k); else { if (picked.size >= 2) { const f = picked.values().next().value; picked.delete(f); g.secs[f].classList.remove('on'); } picked.add(k); }
      g.secs[k].classList.toggle('on', picked.has(k));
      Sound.playEffect('click');
    }));
    sp.append(txt, right);
    root.appendChild(sp);
    const brow = ctx.buttons({
      check: () => {
        const ok = picked.size === 2 && ((picked.has('p1bl') && picked.has('p2ar')) || (picked.has('p1br') && picked.has('p2al')));
        ctx.markResult(gc, ok);
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { ctx.clearResult(gc); picked.clear(); keys.forEach(k => g.secs[k].classList.remove('on')); ['p1br', 'p2al'].forEach(k => { picked.add(k); g.secs[k].classList.add('on'); }); Engine.toast('Also correct: the other pair of alternate interior angles'); },
      reset: () => { ctx.clearResult(gc); picked.clear(); keys.forEach(k => g.secs[k].classList.remove('on')); }
    });
    brow.insertBefore(speak, brow.firstChild);
    root.appendChild(brow);
  }
});
