(function (global) {
  'use strict';
  if (global.Lab) return;
  var NS = 'http://www.w3.org/2000/svg';
  var Lab = {};
  global.Lab = Lab;

  function sv(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  Lab.sv = sv;
  function dv(cls, txt) { var d = document.createElement('div'); if (cls) d.className = cls; if (txt != null) d.textContent = txt; return d; }
  Lab.dv = dv;

  /* ===== 1. TẦNG NỀN THEO PHẦN HỌC (nằm ngoài .slide) ===== */
  /* Mỗi SECTION tự nhận 1 bảng màu theo thứ tự xuất hiện -> đổi bài không phải sửa gì.
     Chỉ định tay: Lab.PAL = { 'Tên section': ['#..','#..','#..'] }. */
  var POOL = [
    ['#5EEAD4', '#93C5FD', '#A7F3D0'],
    ['#7DD3FC', '#BAE6FD', '#5EEAD4'],
    ['#34D399', '#A3E635', '#A7F3D0'],
    ['#2DD4BF', '#34D399', '#93C5FD'],
    ['#A5B4FC', '#93C5FD', '#C7D2FE'],
    ['#FCD34D', '#A3E635', '#FDE68A']
  ];
  var palMap = null;
  function palFor(key) {
    if (!palMap) {
      palMap = {};
      var seen = [];
      Engine.slides.forEach(function (s) { var k = s.section || '-'; if (seen.indexOf(k) < 0) seen.push(k); });
      seen.forEach(function (k, i) { palMap[k] = POOL[i % POOL.length]; });
    }
    return (Lab.PAL && Lab.PAL[key]) || palMap[key] || POOL[0];
  }
  function rgba(hex, a) {
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.slice(0,2),16) + ',' + parseInt(h.slice(2,4),16) + ',' + parseInt(h.slice(4,6),16) + ',' + a + ')';
  }

  /* Khung gần trung tính, màu CHỈ ở 2 góc, giữa màn hình sạch tuyệt đối:
     không có gì nằm sau vùng chữ -> mắt không bị nhiễu. */
  function sceneD(c) {
    var sc = dv('scene');
    sc.style.background = 'linear-gradient(180deg,#FFFFFF 0%,#F7FBF9 56%,#EEF6F2 100%)';
    var tr = dv('deco');
    tr.style.right = '-16vw'; tr.style.top = '-34vh'; tr.style.width = '62vw'; tr.style.height = '62vw';
    tr.style.borderRadius = '50%'; tr.style.opacity = '1';
    tr.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[0], .26) + ' 0%,' + rgba(c[0], 0) + ' 66%)';
    sc.appendChild(tr);
    var bl = dv('deco');
    bl.style.left = '-20vw'; bl.style.bottom = '-32vh'; bl.style.width = '56vw'; bl.style.height = '56vw';
    bl.style.borderRadius = '50%'; bl.style.opacity = '1';
    bl.style.background = 'radial-gradient(circle at 50% 50%,' + rgba(c[2], .22) + ' 0%,' + rgba(c[2], 0) + ' 66%)';
    sc.appendChild(bl);
    return sc;
  }

  var STYLES = { D: sceneD };
  Lab.bgStyle = 'D';
  function buildScene(key) { if (Lab.scene) { var s = Lab.scene(key); if (s) return s; } return (STYLES[Lab.bgStyle] || sceneD)(palFor(key)); }

  var bgHost = null, curScene = null, curKey = null;
  function applyScene() {
    if (!bgHost) {
      bgHost = document.getElementById('bgLayer');
      if (!bgHost) { bgHost = dv(''); bgHost.id = 'bgLayer'; document.body.insertBefore(bgHost, document.body.firstChild); }
    }
    var def = Engine.slides[Engine.idx];
    var key = (def && (def.bg || def.section)) || '-';
    document.body.setAttribute('data-bg', key);
    if (key === curKey && !Lab.__force) return;
    Lab.__force = false;
    curKey = key;
    var next = buildScene(key);
    bgHost.appendChild(next);
    void next.offsetWidth;
    next.classList.add('on');
    var old = curScene;
    curScene = next;
    if (old) setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 700);
  }

  /* ===== 2. fitStage() — lưới an toàn chống vỡ =====
     Dùng biến CSS, KHÔNG transform:scale() lên .slide: tổ tiên có transform
     sẽ phá position:fixed của #dragLayer. */
  var fitRaf = 0, fitTries = 0;
  function curSlide() { return document.querySelector('.stage > .slide'); }
  function minFit() {
    var fs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--fs-scale')) || 1;
    return Math.min(1, 0.72 / fs);
  }
  /* Sàn CHÍNH XÁC cho từng slide: đo cỡ chữ NHỎ NHẤT đang hiện ở --fit = 1, rồi cho co
     đúng tới lúc cỡ đó chạm ngưỡng đọc được từ cuối lớp (1/40 chiều cao màn hình, tối
     thiểu 22px). Bỏ qua chữ trong <svg> vì nó co theo khung hình, không theo --fit. */
  function textFloor(slide) {
    var th = Math.max(22, global.innerHeight / 40);
    var min = Infinity;
    var nodes = slide.querySelectorAll('*');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.ownerSVGElement || n.tagName.toLowerCase() === 'svg') continue;
      var hasText = false;
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3 && c.nodeValue.trim()) { hasText = true; break; }
      }
      if (!hasText) continue;
      var r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      var fsz = parseFloat(getComputedStyle(n).fontSize);
      if (fsz && fsz < min) min = fsz;
    }
    if (!isFinite(min) || !th) return 0.45;
    /* co hệ số f => chữ nhỏ nhất thành min*f; cần min*f >= th => f >= th/min */
    return Math.max(0.45, Math.min(1, (th * 1.06) / min));   // +6% biên an toàn
  }
  function fitNow() {
    fitRaf = 0;
    var slide = curSlide();
    if (!slide) return;
    var lo = slide.__floor != null ? slide.__floor : minFit();
    var cur = parseFloat(slide.style.getPropertyValue('--fit'));
    if (!(cur > 0)) cur = 1;
    var guard = 0;
    /* Vòng lặp ĐỒNG BỘ: đọc scrollHeight ép trình duyệt tính lại layout ngay, nên slide
       vừa vào là đã vừa khung — không nhấp nháy 1-2 khung hình. */
    while (slide.scrollHeight > slide.clientHeight + 1 && cur > lo + 0.001 && guard++ < 16) {
      cur = Math.max(lo, cur - 0.05);
      slide.style.setProperty('--fit', cur.toFixed(3));
    }
    fitTries = guard;
  }
  function scheduleFit() {
    if (fitRaf) return;
    fitRaf = global.requestAnimationFrame ? requestAnimationFrame(fitNow) : setTimeout(fitNow, 16);
  }
  function resetFit() {
    var slide = curSlide();
    if (slide) {
      slide.style.setProperty('--fit', '1');
      slide.__floor = textFloor(slide);
    }
    fitTries = 0;
    fitNow();
    scheduleFit();
  }
  Lab.setBgStyle = function (k) { Lab.bgStyle = k; Lab.__force = true; applyScene(); };
  Lab.fit = scheduleFit;
  Lab.refit = resetFit;

  Lab.goTo = function (id) {
    var i = Engine.slides.findIndex(function (s) { return s.id === id; });
    if (i >= 0) Engine.go(i, 'jump');
  };

  /* ===== 3. NÚT LỚP HỌC: Tập trung / Giảm chuyển động ===== */
  function addNavButtons() {
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#focusBtn')) return;
    var anchor = nav.querySelector('#fullscreenBtn') || nav.querySelector('#tlockBtn');
    var mk = function (id, icon, title, cls) {
      var b = document.createElement('button');
      b.className = 'iconbtn'; b.id = id; b.textContent = icon; b.title = title;
      b.addEventListener('click', function () {
        var on = document.body.classList.toggle(cls);
        b.classList.toggle('on', on);
        try { sessionStorage.setItem('pref:' + cls, on ? '1' : '0'); } catch (e) { }
        Engine.toast(title + (on ? ' — ON' : ' — OFF'));
        resetFit();
      });
      try { if (sessionStorage.getItem('pref:' + cls) === '1') { document.body.classList.add(cls); b.classList.add('on'); } } catch (e) { }
      if (anchor) nav.insertBefore(b, anchor); else nav.appendChild(b);
      return b;
    };
    mk('focusBtn', '🎯', 'Focus mode', 'focus');
    mk('motionBtn', '🌀', 'Reduce motion', 'nomotion');
  }

  /* ===== 4. NỐI VÀO ENGINE ===== */
  /* Khay kéo-thả giữ nguyên chiều cao khi nhấc thẻ ra: không thì khay co lại, cả slide
     dịch lên và ô đích chạy khỏi ngón tay đang kéo (bài L20 đo được: thả trượt ô). */
  var lockT = 0;
  function lockTrays() {
    clearTimeout(lockT);
    document.querySelectorAll('.stage .dd-tray').forEach(function (t) { t.style.minHeight = ''; });
    lockT = setTimeout(function () {
      document.querySelectorAll('.stage .dd-tray').forEach(function (t) { if (t.offsetHeight) t.style.minHeight = t.offsetHeight + 'px'; });
    }, 700);
  }
  Lab.lockTrays = lockTrays;
  var origGo = Engine.go;
  Engine.go = function (i, dir) {
    origGo.call(Engine, i, dir);
    applyScene();
    resetFit();
    setTimeout(scheduleFit, 140);
    setTimeout(scheduleFit, 620);
    lockTrays();
  };
  var origFs = Engine._applyFontScale;
  Engine._applyFontScale = function (v) { origFs.call(Engine, v); resetFit(); };

  var origStart = Engine.start;
  Engine.start = function (cfg) {
    origStart.call(Engine, cfg);
    applyScene();
    addNavButtons();
    resetFit();
    var stage = document.querySelector('.stage');
    if (stage) {
      if (global.ResizeObserver) new ResizeObserver(function () { resetFit(); lockTrays(); }).observe(stage);
      else global.addEventListener('resize', resetFit);
      new MutationObserver(scheduleFit).observe(stage, { childList: true, subtree: true, characterData: true });
      stage.addEventListener('load', scheduleFit, true);   // ảnh tải xong -> đo lại
    }
    global.addEventListener('resize', resetFit);
    document.addEventListener('fullscreenchange', resetFit);
  };

  /* ===== 5. LỚP THẨM MỸ: icon SVG, thanh công cụ gọn, nhãn phần =====
     Chạy SAU engine dựng navbar, không sửa engine.js. Tắt từng phần nếu cần:
     Lab.tidyNav = false · Lab.svgIcons = false · Lab.autoEyebrow = false (đặt trong slide đầu). */
  var IC = {
    prev: '<path d="M15 5l-7 7 7 7"/>',
    next: '<path d="M9 5l7 7-7 7"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.2 7.5l2.1 1.2M17.7 15.3l2.1 1.2M4.2 16.5l2.1-1.2M17.7 8.7l2.1-1.2"/><circle cx="12" cy="12" r="7"/>',
    check: '<path d="M4.5 12.5l4.8 4.8L19.5 7"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/>',
    sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.5M9.5 2.5h5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    star: '<path d="M12 3.2l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 17l-5.4 2.9 1.1-6.1-4.5-4.2 6.1-.8z"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a6 6 0 0 1 0 12"/>'
  };
  /* Icon vẽ bằng CSS mask (thẻ <i>), KHÔNG chèn <svg> vào DOM: qa.py mục 5 coi mọi <svg> là
     widget và báo "QUÁ NHỎ" oan cho icon trong nút. Màu icon = currentColor của nút. */
  Lab.icon = function (name) {
    var i = document.createElement('i');
    i.className = 'ic'; i.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + (IC[name] || '') + '</svg>';
    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    i.style.webkitMaskImage = url; i.style.maskImage = url;
    return i;
  };
  function setIcon(btn, name) { if (!btn) return; btn.textContent = ''; btn.appendChild(Lab.icon(name)); }

  /* Emoji đầu nhãn nút -> icon SVG cùng nghĩa. Emoji không có trong bảng thì để nguyên. */
  var LEAD = [
    [/^\s*(✅|✔️?)\s*/, 'check'], [/^\s*👁️?\s*/, 'eye'], [/^\s*(↺|🔄)\s*/, 'reset'],
    [/^\s*(🔊|🔈)\s*/, 'sound'], [/^\s*(⏱️?)\s*/, 'timer'], [/^\s*(▶️?)\s*/, 'play'], [/^\s*(↩️?)\s*/, 'undo']
  ];
  function iconizeButtons(scope) {
    if (Lab.svgIcons === false || !scope) return;
    scope.querySelectorAll('.btn').forEach(function (b) {
      if (b.querySelector('.ic') || b.children.length) return;
      var t = b.textContent;
      for (var i = 0; i < LEAD.length; i++) {
        if (LEAD[i][0].test(t)) { b.textContent = t.replace(LEAD[i][0], ''); b.insertBefore(Lab.icon(LEAD[i][1]), b.firstChild); return; }
      }
    });
  }
  Lab.iconize = iconizeButtons;

  function tidyNav() {
    if (Lab.tidyNav === false) return;
    var nav = document.querySelector('.navbar');
    if (!nav || nav.querySelector('#tdrawerBtn')) return;
    var byTitle = function (p) { var r = null; nav.querySelectorAll('.iconbtn').forEach(function (b) { if (!r && (b.title || '').indexOf(p) === 0) r = b; }); return r; };
    var prev = byTitle('Previous'), next = byTitle('Next'), full = nav.querySelector('#fullscreenBtn');
    var drawer = dv(''); drawer.id = 'tdrawer';
    var row = function (label, els) {
      els = els.filter(Boolean); if (!els.length) return;
      var r = dv('row'); r.appendChild(dv('lbl', label)); els.forEach(function (e) { r.appendChild(e); }); drawer.appendChild(r);
    };
    row('Text size', [nav.querySelector('.fs-group')]);
    row('Sound', [byTitle('Mute'), nav.querySelector('#voiceBtn')]);
    row('Teams', [nav.querySelector('.teams')]);
    row('Class tools', [byTitle('Timer'), byTitle('Spotlight'), byTitle('Slides')]);
    row('Display', [nav.querySelector('#focusBtn'), nav.querySelector('#motionBtn')]);
    row('Lock', [nav.querySelector('#tlockBtn')]);
    document.body.appendChild(drawer);

    var tb = document.createElement('button');
    tb.id = 'tdrawerBtn'; tb.className = 'iconbtn tbtn'; tb.title = 'Teacher tools';
    tb.appendChild(Lab.icon('gear')); tb.appendChild(document.createTextNode('Teacher'));
    tb.addEventListener('click', function (e) { e.stopPropagation(); drawer.classList.toggle('on'); });
    document.addEventListener('pointerdown', function (e) {
      if (drawer.classList.contains('on') && !drawer.contains(e.target) && !tb.contains(e.target)) drawer.classList.remove('on');
    });
    var anchor = full || prev;
    if (anchor) nav.insertBefore(tb, anchor); else nav.appendChild(tb);

    if (Lab.svgIcons !== false) {
      if (prev) { setIcon(prev, 'prev'); prev.classList.add('nav-arrow'); }
      if (next) { setIcon(next, 'next'); next.classList.add('nav-arrow'); }
      if (full) {
        var sync = function () { setIcon(full, document.fullscreenElement ? 'shrink' : 'expand'); };
        sync(); document.addEventListener('fullscreenchange', function () { setTimeout(sync, 0); });
      }
    }
  }

  /* Nhãn phần (section) nhỏ phía trên tiêu đề — người xem luôn biết đang ở phần nào của bài */
  function addEyebrow() {
    if (Lab.autoEyebrow === false) return;
    var slide = curSlide(); var def = Engine.slides[Engine.idx];
    if (!slide || !def || !def.section || slide.querySelector('.eyebrow, .cover')) return;
    var pill = slide.querySelector(':scope > .pill');
    if (!pill || pill.textContent.toLowerCase().indexOf(def.section.toLowerCase()) >= 0) return;
    var eb = dv('eyebrow fixed', def.section);
    slide.insertBefore(eb, pill);
    /* Nhãn phần là trang trí: slide chật (font 150%, màn dọc) thì bỏ nhãn TRƯỚC khi fitStage phải co chữ */
    var f0 = slide.style.getPropertyValue('--fit');
    slide.style.setProperty('--fit', '1');
    var tight = slide.scrollHeight > slide.clientHeight + 1;
    if (f0) slide.style.setProperty('--fit', f0);
    if (tight || global.innerHeight < 560) eb.remove();
    resetFit();
  }

  var goAes = Engine.go;
  Engine.go = function (i, dir) {
    goAes.call(Engine, i, dir);
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
  };
  var startAes = Engine.start;
  Engine.start = function (cfg) {
    startAes.call(Engine, cfg);
    tidyNav();
    addEyebrow();
    iconizeButtons(document.querySelector('.stage'));
    var st = document.querySelector('.stage');
    if (st) new MutationObserver(function () { iconizeButtons(st); }).observe(st, { childList: true, subtree: true });
  };

  /* ===================== 6. RIÊNG BÀI G7 · GEOMETRY L20 ===================== */
  /* Nền: GIỮ hình minh hoạ gốc của PPT (yêu cầu GV). Mỗi slide khai `bg`:
     'paper' (nền kem + khối 3D trong suốt), 'lawn' (sân cỏ PvZ), 'green' (nền xanh + dụng cụ học tập),
     'photo:<file>' (ảnh địa danh của câu hỏi khởi động). Hoạ tiết chỉ ở mép, giữa màn hình để trống. */
  var IMG = 'assets/img/';
  function deco(sc, file, pos, o) {
    o = o || {};
    var d = dv('deco img' + (o.drift ? ' ' + o.drift : ''));
    d.style.backgroundImage = 'url("' + IMG + file + '")';
    for (var k in pos) d.style[k] = pos[k];
    if (!pos.height) d.style.aspectRatio = o.ar || '1';
    if (o.op != null) d.style.opacity = o.op;
    if (o.rot) d.style.rotate = o.rot;
    sc.appendChild(d);
  }
  Lab.scene = function (key) {
    var sc;
    if (key === 'paper') {
      sc = dv('scene paper');
      deco(sc, 'image4.png', { right: '-4vw', top: '3vh', width: '15vw' }, { op: .9, drift: 'drift' });
      deco(sc, 'image6.png', { left: '-4vw', bottom: '-5vh', width: '15vw' }, { op: .9 });
      deco(sc, 'image9.png', { left: '-3vw', top: '9vh', width: '13vw' }, { op: .85, ar: '1500/811' });
      deco(sc, 'image10.png', { right: '1vw', bottom: '-7vh', width: '12vw' }, { op: .9, drift: 'drift2' });
      deco(sc, 'image11.png', { right: '24vw', top: '-8vh', width: '8vw' }, { op: .8 });
      deco(sc, 'image8.png', { right: '-4vw', top: '46vh', width: '10vw' }, { op: .75, ar: '1500/830' });
      return sc;
    }
    if (key === 'green') {
      sc = dv('scene green');
      deco(sc, 'image63.png', { right: '-6vw', top: '-6vh', width: '26vw' }, { op: .6, ar: '1992/1436' });
      deco(sc, 'image55.png', { left: '-6vw', bottom: '0vh', width: '32vw' }, { op: .6, ar: '2000/1024' });
      deco(sc, 'image57.png', { left: '1vw', top: '5vh', width: '5vw' }, { ar: '392/800', rot: '-18deg' });
      deco(sc, 'image59.png', { left: '6vw', top: '3vh', width: '6vw' }, { ar: '968/1028', drift: 'drift' });
      deco(sc, 'image61.png', { left: '-1vw', top: '44vh', width: '8vw' }, { ar: '1044/720' });
      deco(sc, 'image65.png', { right: '1vw', top: '20vh', width: '9vw' }, { ar: '1032/744', drift: 'drift2' });
      deco(sc, 'image67.png', { right: '2vw', bottom: '24vh', width: '5vw' }, { ar: '756/852' });
      deco(sc, 'image72.png', { left: '2vw', bottom: '3vh', width: '8vw' }, { op: .55 });
      deco(sc, 'image74.png', { right: '1vw', bottom: '1vh', width: '12vw' }, { op: .55, ar: '800/604' });
      return sc;
    }
    if (key === 'lawn' || key.indexOf('photo:') === 0) {
      sc = dv('scene ' + (key === 'lawn' ? 'lawn' : 'photo'));
      sc.style.backgroundImage = 'url("' + IMG + (key === 'lawn' ? 'image12.png' : key.slice(6)) + '")';
      var v = dv('veil');
      v.style.background = key === 'lawn' ? 'linear-gradient(180deg, rgba(0,0,0,.05), rgba(0,0,0,.18))'
        : 'linear-gradient(180deg, rgba(0,0,0,.08) 0%, rgba(0,0,0,0) 40%, rgba(0,0,0,.22) 100%)';
      sc.appendChild(v);
      return sc;
    }
    return null;
  };
  Lab.autoEyebrow = true;

  /* Chữ góc có mũ: Lab.ang('M',1) -> M̂₁ */
  var SUBS = '₀₁₂₃₄₅₆₇₈₉';
  Lab.angHTML = function (L, i) { return '<span class="math">' + L + '\u0302' + (i != null ? String(i).split('').map(function (d) { return SUBS[+d]; }).join('') : '') + '</span>'; };
  /* "{M1}" trong chuỗi -> chữ góc có mũ */
  Lab.fmt = function (s) { return String(s).replace(/\{([A-Z])(\d)\}/g, function (_, L, i) { return Lab.angHTML(L, i); }); };

  /* Hiện 1/n ảnh (cột i) bằng CSS — không đổi pixel ảnh gốc. w,h = kích thước gốc */
  var cropSeq = 0;
  Lab.cropBox = function (src, W, H, x, y, w, h, alt) {
    var box = dv('crop');
    var s = sv('svg', { viewBox: x + ' ' + y + ' ' + w + ' ' + h, preserveAspectRatio: 'xMidYMid meet', role: 'img', 'aria-label': alt || '' });
    var cid = 'cb' + (++cropSeq);
    s.appendChild(sv('defs', null, [sv('clipPath', { id: cid }, [sv('rect', { x: x, y: y, width: w, height: h })])]));
    s.appendChild(sv('image', { href: src, x: 0, y: 0, width: W, height: H, 'clip-path': 'url(#' + cid + ')' }));
    box.appendChild(s);
    return box;
  };
  Lab.crop = function (src, n, i, w, h, alt, vh) { return Lab.cropBox(src, w, h, i * w / n, 0, w / n, vh || h, alt); };

  /* Track audio gốc của PPT */
  Lab.player = function (ctx, src, label) {
    var wrap = document.createElement('span'); wrap.className = 'player';
    var a = document.createElement('audio'); a.src = src; a.preload = 'auto'; a.style.display = 'none';
    var b = document.createElement('button'); b.className = 'btn btn-primary'; b.textContent = '▶ ' + label;
    var bar = document.createElement('span'); bar.className = 'bar';
    var fill = document.createElement('i'); bar.appendChild(fill);
    function setLbl(p) { b.textContent = (p ? '❚❚ ' : '▶ ') + label; }
    ctx.on(b, 'click', function () {
      if (!a.paused) { a.pause(); return; }
      if (Sound.muted()) { Engine.toast('Sound is muted'); return; }
      Sound.stopAll();
      try { if (a.ended) a.currentTime = 0; } catch (e) { }
      var p = a.play(); if (p && p.catch) p.catch(function () { Engine.toast('Tap again to play'); });
    });
    ctx.on(a, 'play', function () { setLbl(true); });
    ctx.on(a, 'pause', function () { setLbl(false); });
    ctx.on(a, 'ended', function () { setLbl(false); fill.style.transform = 'scaleX(1)'; });
    ctx.on(a, 'timeupdate', function () { if (a.duration) fill.style.transform = 'scaleX(' + (a.currentTime / a.duration).toFixed(3) + ')'; });
    ctx.on(a, 'error', function () { b.disabled = true; b.textContent = 'Audio unavailable'; });
    document.body.appendChild(a);
    ctx._off.push(function () { try { a.pause(); } catch (e) { } a.remove(); });
    wrap.append(b, bar);
    return wrap;
  };

  /* Chọn 1 trong n phương án ngay trong câu */
  Lab.ich = function (ctx, opts, answer) {
    var w = document.createElement('span'); w.className = 'ich'; w.__val = -1;
    opts.forEach(function (o, i) {
      var b = document.createElement('button'); b.innerHTML = o;
      ctx.on(b, 'click', function () {
        Sound.playEffect('click'); ctx.clearResult(w); w.__val = i;
        w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === i); });
        w.classList.add('chosen');
      });
      w.appendChild(b);
    });
    w.__check = function () { var ok = w.__val === answer; ctx.markResult(w, ok); return ok; };
    w.__show = function () { ctx.clearResult(w); w.__val = answer; w.querySelectorAll('button').forEach(function (x, j) { x.classList.toggle('on', j === answer); }); w.classList.add('chosen'); };
    w.__reset = function () { ctx.clearResult(w); w.__val = -1; w.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); }); w.classList.remove('chosen'); };
    return w;
  };
  Lab.ichGroup = function (list) {
    return {
      check: function () { var c = 0; list.forEach(function (w) { if (w.__check()) c++; }); return { correct: c, total: list.length }; },
      show: function () { list.forEach(function (w) { w.__show(); }); },
      reset: function () { list.forEach(function (w) { w.__reset(); }); }
    };
  };

  /* ---------- Hình học: 2 đường thẳng song song + 1 cát tuyến (SVG) ----------
     Toạ độ toán (y hướng lên) cho góc; viewBox 1000x620. theta = góc cát tuyến với đường ngang.
     Vùng góc tại giao điểm: 'ar' trên-phải (0..θ), 'al' trên-trái (θ..180), 'bl' dưới-trái (180..180+θ), 'br' dưới-phải (180+θ..360).
     Góc TRONG: P1 (đường trên) 'bl','br'; P2 (đường dưới) 'al','ar'. So le trong: P1.bl↔P2.ar, P1.br↔P2.al. */
  var Y1 = 210, Y2 = 430, CX = 500, CY = 320;
  function pt(cx, cy, r, deg) { var a = deg * Math.PI / 180; return [cx + r * Math.cos(a), cy - r * Math.sin(a)]; }
  function sector(cx, cy, r, a1, a2) {
    var p1 = pt(cx, cy, r, a1), p2 = pt(cx, cy, r, a2);
    return 'M' + cx + ' ' + cy + ' L' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 ' + (a2 - a1 > 180 ? 1 : 0) + ' 0 ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1) + ' Z';
  }
  function range(reg, th) { return { ar: [0, th], al: [th, 180], bl: [180, 180 + th], br: [180 + th, 360] }[reg]; }
  Lab.geo = function (o) {
    o = o || {};
    var th = o.theta || 60;
    var svg = sv('svg', { viewBox: '0 0 1000 620', class: 'geo', role: 'img', 'aria-label': 'Two parallel lines cut by a transversal' });
    var defs = sv('defs');
    var mk = sv('marker', { id: 'arw' + (o.id || ''), viewBox: '0 0 10 10', refX: '6', refY: '5', markerWidth: '4', markerHeight: '4', orient: 'auto-start-reverse' }, [sv('path', { d: 'M0 0 L10 5 L0 10 z', fill: '#111827' })]);
    defs.appendChild(mk); svg.appendChild(defs);
    var gSec = sv('g'), gLines = sv('g'), gTxt = sv('g');
    svg.append(gSec, gLines, gTxt);
    var mid = 'url(#arw' + (o.id || '') + ')';
    var l1 = sv('line', { x1: 60, y1: Y1, x2: 940, y2: Y1, class: 'ln', 'marker-start': mid, 'marker-end': mid });
    var l2 = sv('line', { x1: 60, y1: Y2, x2: 940, y2: Y2, class: 'ln', 'marker-start': mid, 'marker-end': mid });
    var tr = sv('line', { class: 'ln', 'marker-start': mid, 'marker-end': mid });
    gLines.append(l1, l2, tr);
    if (o.names) {
      gTxt.appendChild(sv('text', { x: 70, y: Y1 - 22, class: 'lbl' })).textContent = o.names[0];
      gTxt.appendChild(sv('text', { x: 70, y: Y2 - 22, class: 'lbl' })).textContent = o.names[1];
    }
    var api = { el: svg, secs: {}, vals: {} };
    var R = o.r || 78;
    (o.sectors || []).forEach(function (s) {   // s: {key:'p1bl', fill, tap}
      var p = sv('path', { class: 'sec' + (s.tap ? ' tap' : '') });
      if (s.fill) p.setAttribute('fill', s.fill);
      gSec.appendChild(p);
      api.secs[s.key] = p;
      if (s.value) { var t = sv('text', { class: 'val', 'text-anchor': 'middle', 'dominant-baseline': 'middle', fill: s.fill || '#111827' }); gTxt.appendChild(t); api.vals[s.key] = t; }
    });
    api.set = function (theta) {
      th = theta;
      var t = Math.tan(th * Math.PI / 180);
      var x1 = CX + (CY - Y1) / t, x2 = CX - (Y2 - CY) / t;   // giao điểm với 2 đường
      api.p1 = [x1, Y1]; api.p2 = [x2, Y2];
      var a = pt(CX, CY, 330, th), b = pt(CX, CY, 330, th + 180);
      tr.setAttribute('x1', b[0].toFixed(1)); tr.setAttribute('y1', b[1].toFixed(1));
      tr.setAttribute('x2', a[0].toFixed(1)); tr.setAttribute('y2', a[1].toFixed(1));
      Object.keys(api.secs).forEach(function (k) {
        var P = k.slice(0, 2) === 'p1' ? api.p1 : api.p2, rg = range(k.slice(2), th);
        api.secs[k].setAttribute('d', sector(P[0], P[1], R, rg[0], rg[1]));
        if (api.vals[k]) {
          var m = pt(P[0], P[1], R + 46, (rg[0] + rg[1]) / 2);
          api.vals[k].setAttribute('x', m[0].toFixed(1)); api.vals[k].setAttribute('y', m[1].toFixed(1));
          api.vals[k].textContent = Math.round(rg[1] - rg[0]) + '°';
        }
      });
    };
    api.theta = function () { return th; };
    api.set(th);
    return api;
  };

  /* Bàn phím số trên màn hình (không dùng <input>) */
  Lab.keypad = function (ctx, onKey) {
    var k = dv('keypad');
    ['1', '2', '3', '⌫', '4', '5', '6', '0', '7', '8', '9', 'C'].forEach(function (c) {
      var b = document.createElement('button'); b.textContent = c;
      ctx.on(b, 'click', function () { Sound.playEffect('click'); onKey(c); });
      k.appendChild(b);
    });
    return k;
  };

  /* ---------- PvZ: header + câu hỏi trắc nghiệm ---------- */
  Lab.QIDS = ['q1', 'q2', 'q3', 'q4', 'q5'];
  Lab.pvzHead = function (ctx, n) {
    var hd = dv('pvzhead fixed');
    var logo = ctx.img(IMG + 'image37.png', { alt: 'Plants vs. Zombies', zoom: false, class: 'logo' });
    var mid = dv('grow1'); mid.appendChild(dv('tag onphoto', 'Question ' + n + ' / 5'));
    var sign = document.createElement('button'); sign.className = 'signbtn'; sign.title = 'Back to the lanes';
    var si = document.createElement('img'); si.src = IMG + 'image35.png'; si.alt = '';
    var sl = document.createElement('span'); sl.textContent = 'Lanes';
    sign.append(si, sl);
    ctx.on(sign, 'click', function () { Lab.goTo('hub'); });
    hd.append(logo, mid, sign);
    hd.__sign = sign;
    return hd;
  };
  /* spec: {n, q, opts:[A,B,C,D], ans, zombie, variant:'quiz'|'shoot'} */
  Lab.pvzQuestion = function (root, ctx, spec) {
    var head = Lab.pvzHead(ctx, spec.n);
    root.appendChild(head);
    var done = false, scored = false;
    var zom = ctx.img(IMG + spec.zombie, { alt: 'Zombie', zoom: false, class: 'zombie' });
    function finish(ok) {
      if (!scored) { scored = true; Engine.score(ok ? 1 : 0, 1); }
      else Sound.playEffect(ok ? 'ok' : 'bad');
      if (ok) {
        done = true;
        ctx.timeout(function () { zom.classList.add('defeated'); }, spec.variant === 'shoot' ? 380 : 120);
        head.__sign.classList.add('pulse');
        Engine.toast(['🌻 Zombie defeated!', '🌱 Great shot!', '🎯 Correct!'][spec.n % 3]);
      }
    }
    var letters = ['A', 'B', 'C', 'D'];
    if (spec.variant === 'shoot') {
      var qc = dv('stagecard glass fixed');
      qc.style.width = '100%'; qc.style.padding = 'clamp(4px,1vh,12px) clamp(10px,2vw,28px)';
      var row = dv('pvzq'); var qt = dv('q', spec.q); zom.style.height = 'clamp(70px,16vh,230px)';
      row.append(qt, zom); qc.appendChild(row);
      root.appendChild(qc);
      root.appendChild(dv('note fixed onphoto', 'Tap the lane with the right answer to shoot!'));
      var lanes = dv('lanes stagger');
      spec.opts.forEach(function (o, i) {
        var ln = document.createElement('button'); ln.className = 'lane';
        ln.style.gridTemplateColumns = 'auto auto minmax(0,1fr)';
        var pl = document.createElement('img'); pl.src = IMG + 'image14.png'; pl.alt = 'Peashooter';
        var sg = dv('sign'); sg.innerHTML = '<span class="k">' + letters[i] + '.</span>' + o;
        var trk = dv('track'); var shot = dv('shot'); var pea = document.createElement('img'); pea.src = IMG + 'image33.png'; pea.alt = '';
        shot.appendChild(pea); trk.append(sg, shot);
        ln.append(pl, trk);
        ctx.on(ln, 'click', function () {
          if (done) return;
          shot.classList.remove('fire'); void shot.offsetWidth; shot.classList.add('fire');
          Sound.playEffect('click');
          var ok = i === spec.ans;
          ctx.timeout(function () { ctx.markResult(ln, ok, { sound: false }); finish(ok); }, 330);
        });
        lanes.appendChild(ln);
      });
      root.appendChild(lanes);
    } else {
      var g = dv('grow center-col');
      var card = dv('stagecard glass stagger');
      var r2 = dv('pvzq'); r2.append(dv('q', spec.q), zom);
      var grid = dv('optgrid two');
      spec.opts.forEach(function (o, i) {
        var b = document.createElement('button'); b.className = 'opt';
        b.innerHTML = '<span class="k">' + letters[i] + '.</span>' + o;
        ctx.on(b, 'click', function () {
          if (done) return;
          var ok = i === spec.ans;
          ctx.markResult(b, ok, { sound: false });
          finish(ok);
        });
        grid.appendChild(b);
      });
      card.append(r2, grid);
      g.appendChild(card);
      root.appendChild(g);
    }
  };

  /* Chấm dragDrop CHỈ theo ô đích (khay có thẻ nhiễu): engine check() coi thẻ nhiễu nằm trong khay là sai. */
  Lab.ddCheck = function (ctx, dd, zones) {
    var correct = 0;
    dd.tray.querySelectorAll('.drag-item').forEach(function (n) { ctx.clearResult(n); });
    zones.forEach(function (z) {
      var zn = dd.zoneEls[z.id];
      var it = zn.querySelector('.drag-item');
      ctx.clearResult(zn);
      if (!it) { ctx.markResult(zn, false, { badge: false }); return; }
      var ok = z.accept.indexOf(it.dataset.ddId) >= 0;
      if (ok) correct++;
      ctx.markResult(it, ok);
    });
    return { correct: correct, total: zones.length };
  };
})(window);
