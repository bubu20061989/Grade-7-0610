Engine.register({
  id: 'cover', section: 'Warm-up', title: 'Triangular Prisms', mech: 'intro',
  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const pic = ctx.img('assets/img/cover-tools.png', { alt: 'Geometry tools: compass, ruler, board and book', zoom: false, class: 'hero-img float-anim' });
    ctx.on(pic, 'click', () => { pic.classList.remove('nudge'); void pic.offsetWidth; pic.classList.add('nudge'); Sound.speak('Hello class! Today we learn about triangular prisms.'); });
    media.appendChild(pic);
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Grade 7' }), h('span', { class: 'tag', text: 'Chapter 4 · Geometry' })]));
    const t = h('div', { class: 'hero-title' }); t.innerHTML = 'Lesson 15:<br><em>Triangular</em> Prisms';
    const go = h('button', { class: 'btn btn-primary pulse', text: "Let's start ▶" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: "Let's explore English in Maths · 👆 Tap the picture" }), h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [go]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
