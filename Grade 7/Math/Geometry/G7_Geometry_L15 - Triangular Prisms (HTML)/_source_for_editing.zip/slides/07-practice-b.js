Engine.register({
  id: 'practice-b', section: 'Practice', title: 'B. Practice: describe the prism', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'B. Practice' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Fill in the blanks with suitable words to describe the triangular prism.' }));
    const items = [{ id: 'vertex', label: 'vertex' }, { id: 'edges', label: 'edges' }, { id: 'parallel', label: 'parallel' }, { id: 'tb', label: 'triangular bases' }, { id: 'height', label: 'height' }];
    const zones = [{ id: 'a', accept: ['vertex'], capacity: 1 }, { id: 'b1', accept: ['edges'], capacity: 1 }, { id: 'b2', accept: ['parallel'], capacity: 1 }, { id: 'c', accept: ['tb'], capacity: 1 }, { id: 'd', accept: ['height'], capacity: 1 }];
    const dd = ctx.dragDrop({ items, zones, renderZone: z => h('div', { class: 'slot' + (z.id === 'c' ? ' wide' : '') }) });
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.7fr) minmax(0,1.3fr)' });
    const fig = h('div', { class: 'prismfig' });
    const P = { B: [40, 40], C: [390, 40], A: [240, 170], "B'": [40, 300], "C'": [390, 300], "A'": [240, 430] };
    const L = (p, q, cls) => `<line class="ed ${cls || ''}" x1="${P[p][0]}" y1="${P[p][1]}" x2="${P[q][0]}" y2="${P[q][1]}"/>`;
    const lab = { B: [-10, -16], C: [0, -16], A: [14, 34], "B'": [-62, 12], "C'": [14, 12], "A'": [-14, 46] };
    fig.innerHTML = '<svg viewBox="-40 -40 500 520" role="img" aria-label="Triangular prism ABC.A\'B\'C\'">' +
      L('B', 'C') + L('B', 'A') + L('A', 'C') + L('B', "B'") + L('C', "C'") + L('A', "A'") + L("B'", "A'") + L("A'", "C'") + L("B'", "C'", 'hid') +
      Object.keys(P).map(k => `<circle class="vx" cx="${P[k][0]}" cy="${P[k][1]}" r="7"/><text class="lb" x="${P[k][0] + lab[k][0]}" y="${P[k][1] + lab[k][1]}">${k.replace("'", '′')}</text>`).join('') + '</svg>';
    const Z = dd.zoneEls;
    const card = h('div', { class: 'card bcard' }, [
      Lab.para("a) B′ is a [[a]] of the triangular prism ABC.A′B′C′.", Z),
      Lab.para("b) The two [[b1]] AB and A′B′ are [[b2]].", Z),
      Lab.para("c) The two [[c]] ABC and A′B′C′ are congruent.", Z),
      Lab.para("d) The length of AA′ is the [[d]] of the triangular prism ABC.A′B′C′.", Z)
    ]);
    sp.append(h('div', { class: 'media' }, [fig]), h('div', {}, [card]));
    root.appendChild(sp);
    root.appendChild(dd.tray);
    const map = { vertex: 'a', edges: 'b1', parallel: 'b2', tb: 'c', height: 'd' };
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => { Lab.ddClear(ctx, dd); dd.reset(); Object.keys(map).forEach(it => { const n = dd.tray.querySelector('[data-dd-id="' + it + '"]'); if (n) { Z[map[it]].appendChild(n); dd.place[it] = map[it]; } }); },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
