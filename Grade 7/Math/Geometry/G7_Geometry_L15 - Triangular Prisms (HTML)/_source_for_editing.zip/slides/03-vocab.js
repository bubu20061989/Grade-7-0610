Engine.register({
  id: 'vocab', section: 'Vocabulary', title: 'Vocabulary flashcards', mech: 'flashcard',
  render(root, ctx) {
    const W = [
      { w: 'triangular prism', ipa: '/traɪˈæŋɡjələr ˈprɪzəm/', c: 'c-blu', base: false, def: 'a 3D shape with 2 triangular bases and 3 rectangular faces.', ex: '<b>Example:</b> A <b>triangular prism</b> has two triangular bases and three rectangular faces.' },
      { w: 'base', ipa: '/beɪs/', c: 'c-yel', base: true, def: 'the bottom part of something; the foundation or supporting part.', ex: '<b>Example:</b> The triangular prism has two triangular <b>bases</b>.' }
    ];
    root.appendChild(h('div', { class: 'pill fixed', text: 'New words' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap the card to see the meaning' }));
    const grow = h('div', { class: 'grow center-col stagger' });
    const box = h('div', { class: 'vfcbox' }, [h('div', { class: 'fc-stack-under' }), h('div', { class: 'fc-stack-under' })]);
    const fc = h('div', { class: 'vfc' });
    const front = h('div', { class: 'face vfront' });
    const back = h('div', { class: 'face back vback' });
    fc.append(front, back); box.appendChild(fc);
    grow.append(h('div', { class: 'fc-wrap' }, [box]));
    const dots = h('div', { class: 'dots fixed' });
    root.append(grow, dots);
    const prismSVG = (hl) => {
      const d = document.createElement('div'); d.className = 'prismfig' + (hl ? ' hl-base' : '');
      d.innerHTML = '<svg viewBox="-20 -30 470 300" aria-hidden="true">' +
        '<polygon class="fa" points="40,230 300,250 400,120 140,100" fill="#60A5FA"/>' +
        '<polygon class="fa" points="140,100 400,120 260,10 0,0" fill="#93C5FD" opacity="0"/>' +
        '<polygon class="fa" points="140,100 300,250 400,120 260,10" fill="#3B82F6"/>' +
        '<polygon class="fa base" points="40,230 140,100 300,250" fill="#38BDF8"/>' +
        '<polygon class="fa base" points="140,100 260,10 400,120" fill="#7DD3FC" opacity=".55"/>' +
        '<polyline class="ed" points="40,230 300,250 140,100 40,230"/><polyline class="ed" points="300,250 400,120 260,10 140,100"/>' +
        '<polyline class="ed hid" points="40,230 160,150 400,120"/><line class="ed hid" x1="160" y1="150" x2="260" y2="10"/>' +
        (hl ? '<text class="lb" x="-10" y="150" style="fill:#B45309;font-style:normal">base</text><text class="lb" x="330" y="40" style="fill:#B45309;font-style:normal">base</text>' : '') +
        '</svg>';
      return d;
    };
    let i = 0; const seen = {};
    const paint = () => {
      const v = W[i]; seen[i] = 1;
      fc.classList.remove('flipped');
      front.innerHTML = ''; back.innerHTML = '';
      front.append(h('div', { class: 'vimg' }, [prismSVG(v.base)]),
        h('div', { class: 'vtext' }, [h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vpos', text: '(noun)' }), h('div', { class: 'vipa', text: v.ipa })]));
      back.append(h('div', { class: 'vword ' + v.c, text: v.w }), h('div', { class: 'vdef', text: v.def }), h('div', { class: 'vex', html: v.ex }));
      dots.innerHTML = '';
      W.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      front.classList.remove('pop-in'); void front.offsetWidth; front.classList.add('pop-in');
      if (Object.keys(seen).length === W.length && !this._cheered) { this._cheered = true; ctx.timeout(() => Engine.confetti('star'), 300); }
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    const bPrev = h('button', { class: 'btn', text: '◀ Back' });
    const bNext = h('button', { class: 'btn btn-primary', text: 'Next word ▶' });
    const bSay = h('button', { class: 'btn', text: '🔊 Listen' });
    const bRep = h('button', { class: 'btn', text: '🔁 x3' });
    ctx.on(bPrev, 'click', () => { i = (i + W.length - 1) % W.length; paint(); });
    ctx.on(bNext, 'click', () => { i = (i + 1) % W.length; paint(); });
    ctx.on(bSay, 'click', () => { const v = W[i]; Sound.speak(fc.classList.contains('flipped') ? v.w + '. ' + v.def : v.w); });
    ctx.on(bRep, 'click', () => Sound.repeat(W[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [bPrev, bSay, bRep, bNext]));
    paint();
  }
});
