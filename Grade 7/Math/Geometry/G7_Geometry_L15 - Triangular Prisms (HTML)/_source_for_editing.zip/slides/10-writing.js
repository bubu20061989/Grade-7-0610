Engine.register({
  id: 'writing', section: 'Writing', title: 'D. Writing: the tent', mech: 'numpad',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/image24.png', { alt: 'Tent shaped like a triangular prism: base sides 2.4 m, 2.4 m, 2.5 m; length 4 m', class: 'hero-img' }), ctx.zoomHint()]);
    const fP = Lab.numField(ctx, 7.3), fH = Lab.numField(ctx, 4), fA = Lab.numField(ctx, 29.2);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'qcard small', html: '<b>a)</b> Mai is building a tent in the woods. Look at the dimensions of the tent in the figure, find the total lateral area of the tent.' }));
    const l1 = h('div', { class: 'mline' }, [h('div', { class: 'lbl', html: 'Perimeter of the base (<i>P</i><sub>base</sub>):' }), h('span', { html: '<i>P</i><sub>base</sub> = 2.4 + 2.4 + 2.5 = ' }), fP, h('span', { text: ' (m)' })]);
    const l2 = h('div', { class: 'mline' }, [h('div', { class: 'lbl', html: 'Lateral area (<i>A</i><sub>lateral</sub>):' }), h('span', { html: '<i>A</i><sub>lateral</sub> = <i>P</i> × <i>h</i> = 7.3 × ' }), fH, h('span', { text: ' = ' }), fA, h('span', { text: ' m²' })]);
    right.append(h('div', { class: 'card' }, [l1, l2]), Lab.keypad(ctx, right));
    sp.append(media, right);
    root.appendChild(sp);
    fP.click();
    const g = Lab.ichGroup([fP, fH, fA]);
    root.appendChild(ctx.buttons(g));
  }
});
