Engine.register({
  id: 'maths-corner', section: 'Maths Corner', title: 'What is a triangular prism?', mech: 'fact',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'What is a triangular prism?' }));
    const sp = h('div', { class: 'split stagger' });
    const fig = h('div', { class: 'prismfig' });
    fig.innerHTML = '<svg viewBox="0 -10 420 330" role="img" aria-label="Triangular prism ABC.DEF">' +
      '<polygon class="fa" points="110,120 175,290 365,190 300,20" fill="#FDE68A" opacity=".8"/>' +
      '<polygon class="fa base" points="300,20 220,170 365,190" fill="#FDBA74" opacity=".8"/>' +
      '<polygon class="fa base" points="110,120 30,270 175,290" fill="#60A5FA" opacity=".9"/>' +
      '<line class="ed hid lat" x1="30" y1="270" x2="220" y2="170"/><line class="ed hid bs" x1="300" y1="20" x2="220" y2="170"/><line class="ed hid bs" x1="220" y1="170" x2="365" y2="190"/>' +
      '<polyline class="ed bs" points="110,120 30,270 175,290 110,120"/><line class="ed bs" x1="300" y1="20" x2="365" y2="190"/>' +
      '<line class="ed lat h1" x1="110" y1="120" x2="300" y2="20"/><line class="ed lat" x1="175" y1="290" x2="365" y2="190"/>' +
      [['A', 110, 120, -30, -8], ['B', 30, 270, -30, 14], ['C', 175, 290, 4, 34], ['D', 300, 20, -6, -14], ['E', 220, 170, -6, 34], ['F', 365, 190, 12, 8]]
        .map(([n, x, y, dx, dy]) => `<circle class="vx" cx="${x}" cy="${y}" r="6"/><text class="lb" x="${x + dx}" y="${y + dy}">${n}</text>`).join('') +
      '<text class="hlab" x="160" y="52">height</text>' +
      '</svg>';
    const left = h('div', { class: 'media' }, [fig]);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'defcard', html: 'A <b>triangular prism</b> is a 3D shape with 2 triangular bases and 3 rectangular faces.' }));
    right.appendChild(h('div', { class: 'note', style: 'text-align:left', text: 'The triangular prism ABC.DEF has: (tap each line)' }));
    const F = [
      ['hl-vert', '#1D4ED8', '6 vertices: A, B, C, D, E, and F.'],
      ['hl-edge', '#DC2626', '3 parallel congruent edges: AD = CF = BE.'],
      ['hl-base', '#F59E0B', '2 congruent triangular bases: ABC and DEF.'],
      ['hl-height', '#7C3AED', 'The length of AD is the height of the triangular prism.']
    ];
    const list = h('div', { class: 'factlist' });
    const seen = new Set();
    F.forEach(([cls, c, t], k) => {
      const b = h('button', { class: 'fact', style: '--fc:' + c }, [h('span', { class: 'dot' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => {
        list.querySelectorAll('.fact').forEach(x => x.classList.toggle('on', x === b));
        F.forEach(f => fig.classList.remove(f[0]));
        fig.classList.add(cls);
        Sound.speak(t.replace('AD = CF = BE', 'A D equals C F equals B E').replace('ABC and DEF', 'A B C and D E F').replace('AD', 'A D'));
        seen.add(k);
        if (seen.size === F.length && !this._cheer) { this._cheer = true; ctx.timeout(() => Engine.confetti('star'), 600); }
      });
      list.appendChild(b);
    });
    right.appendChild(list);
    sp.append(left, right);
    root.appendChild(sp);
  }
});
