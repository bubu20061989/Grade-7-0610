Engine.register({
  id: 'leadin', section: 'Warm-up', title: 'Lead-in: What shapes are those?', mech: 'quiz',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/image14.png', { alt: 'A slice of pie and a sandwich', class: 'hero-img' }), ctx.zoomHint()]);
    const right = h('div', {});
    const ask = h('div', { class: 'askrow' }, [h('div', { class: 'bubble', text: 'What shapes are those?' }), h('div', { class: 'boy' }, [ctx.img('assets/img/image13.png', { alt: 'A thinking boy', zoom: false })])]);
    const say = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(say, 'click', () => Sound.speak('What shapes are those?'));
    const opts = ['cube', 'cuboid', 'triangular prism'];
    const og = h('div', { class: 'optgrid', style: 'width:100%' });
    const res = h('div', { class: 'note', text: 'Tap your answer' });
    let done = false;
    opts.forEach(o => {
      const b = h('button', { class: 'opt', text: o });
      ctx.on(b, 'click', () => {
        if (done) return;
        const ok = o === 'triangular prism';
        ctx.markResult(b, ok, { sound: true });
        if (ok) { done = true; res.textContent = 'Yes! They look like triangular prisms.'; Sound.speak('Triangular prism'); Engine.score(1, 1); Engine.confetti('star'); }
      });
      og.appendChild(b);
    });
    const tm = h('button', { class: 'btn', text: '⏱ 20s' });
    ctx.on(tm, 'click', () => Engine.timer(20));
    right.append(ask, og, res, h('div', { class: 'btnrow' }, [say, tm]));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
