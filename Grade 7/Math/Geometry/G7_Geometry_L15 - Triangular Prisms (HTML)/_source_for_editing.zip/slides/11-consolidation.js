Engine.register({
  id: 'consolidation', section: 'Wrap-up', title: 'Consolidation', mech: 'speak',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.8fr) minmax(0,1.2fr)' });
    const chips = h('div', { class: 'vchips' });
    [['triangular prism', 'c-blu'], ['base', 'c-yel']].forEach(([w, c]) => { const b = h('button', { class: 'vchip ' + c, text: w }); ctx.on(b, 'click', () => { b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge'); Sound.speak(w); }); chips.appendChild(b); });
    const checks = h('div', { class: 'factlist' });
    ['Find the volume', 'Find the lateral area', 'Find the surface area'].forEach(t => {
      const b = h('button', { class: 'checkitem' }, [h('span', { class: 'box', text: '✓' }), h('span', { text: t })]);
      ctx.on(b, 'click', () => { b.classList.toggle('on'); Sound.playEffect('click'); if (checks.querySelectorAll('.on').length === 3) Engine.confetti('star'); });
      checks.appendChild(b);
    });
    const left = h('div', { class: 'pcard' }, [h('div', { class: 'plabel', html: '<b>Vocabulary</b> — tap to listen' }), chips, h('div', { class: 'plabel', html: 'I can… <b>(tap)</b>' }), checks]);
    const S = 'The triangular prism ABC.DEF has 6 vertices: A, B, C, D, E, and F; 3 parallel congruent edges: AD = CF = BE; 2 congruent triangular bases: ABC and DEF.';
    const spEl = h('div', { class: 'sp' });
    const words = S.split(' ').map(w => { const s = h('span', { class: 'w', text: w }); spEl.append(s, ' '); return s; });
    const say = h('button', { class: 'btn btn-primary', text: '🔊 Say it together' });
    ctx.on(say, 'click', () => {
      say.disabled = true;
      Sound.speak(S, { onBoundary: (e) => { let n = 0; words.forEach(s => { s.classList.toggle('kara', e.charIndex >= n && e.charIndex < n + s.textContent.length + 1); n += s.textContent.length + 1; }); } })
        .then(() => { words.forEach(s => s.classList.remove('kara')); say.disabled = false; });
    });
    const tm = h('button', { class: 'btn', text: '⏱ 60s' });
    ctx.on(tm, 'click', () => Engine.timer(60));
    const right = h('div', { class: 'pcard' }, [h('div', { class: 'plabel', html: '<b>Sentence pattern</b>' }), spEl, h('div', { class: 'btnrow' }, [say, tm]), h('div', { class: 'note', text: '📖 Prepare the next lesson.' })]);
    sp.append(left, right);
    root.appendChild(sp);
  }
});
