Engine.register({
  id: 'practice-cb', section: 'Practice', title: 'C. Practice b) find the height', mech: 'order',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'qcard small fixed', html: '<b>b)</b> A triangular prism has a lateral area of 88 cm² and the side lengths of the triangular base are 5 cm, 7 cm, and 10 cm. Find the height of the triangular prism.' }));
    const pick = Lab.ich(ctx, ['volume', 'lateral area', 'surface area'], 1);
    const items = [{ id: 'e1', label: 'The sum of 5, 7, and 10 is 22.' }, { id: 'e2', label: 'Divide both sides by 22.' }, { id: 'e3', label: 'We obtain h = 4.' }];
    const zones = [{ id: 'l1', accept: ['e1'], capacity: 1 }, { id: 'l2', accept: ['e2'], capacity: 1 }, { id: 'l3', accept: ['e3'], capacity: 1 }];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'slot' }) });
    const Z = dd.zoneEls;
    const lines = h('div', { class: 'eqlines' }, [
      h('div', { class: 'eq', text: '(5 + 7 + 10) × h = 88' }), Z.l1,
      h('div', { class: 'eq', text: '22 × h = 88' }), Z.l2,
      h('div', { class: 'eq', text: 'h = 88 ÷ 22' }), Z.l3,
      h('div', { class: 'eq', text: 'h = 4' }), h('div', { class: 'blank' })
    ]);
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr)' });
    const s1 = h('div', { class: 'solcard' }, [
      h('div', { class: 'soltag', text: 'Solution' }),
      Lab.para('Let h (cm) be the height of the triangular prism.'),
      Lab.para('The [[p]] of the triangular prism is:<br>(5 + 7 + 10) × h = 88 cm².', { p: pick })
    ]);
    const s2 = h('div', { class: 'solcard' }, [Lab.para('Solve the equation to find h:'), lines, Lab.para('Hence, the height of the triangular prism is 4 cm.')]);
    sp.append(h('div', {}, [s1]), h('div', {}, [s2]));
    root.appendChild(sp);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({
      check: () => { const r = Lab.ddCheck(ctx, dd, zones); const ok = pick.__check(); return { correct: r.correct + (ok ? 1 : 0), total: r.total + 1 }; },
      show: () => { pick.__show(); Lab.ddClear(ctx, dd); dd.reset(); [['e1', 'l1'], ['e2', 'l2'], ['e3', 'l3']].forEach(([it, z]) => { const n = dd.tray.querySelector('[data-dd-id="' + it + '"]'); if (n) { Z[z].appendChild(n); dd.place[it] = z; } }); },
      reset: () => { pick.__reset(); Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
