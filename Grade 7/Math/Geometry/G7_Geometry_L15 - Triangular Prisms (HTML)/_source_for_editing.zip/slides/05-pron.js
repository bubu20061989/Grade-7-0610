Engine.register({
  id: 'pron', section: 'Pronunciation', title: 'A. Pronunciation: odd one out', mech: 'listen',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'A. Pronunciation' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Choose a word with the underlined part pronounced differently from the rest.' }));
    const W = [['surface', 'sur<u>fa</u>ce', '/ˈsɜː.fɪs/'], ['face', 'f<u>a</u>ce', '/feɪs/'], ['base', 'b<u>a</u>se', '/beɪs/'], ['shape', 'sh<u>a</u>pe', '/ʃeɪp/']];
    const ANS = 'surface';
    const card = h('div', { class: 'stagecard stagger' });
    const grid = h('div', { class: 'pgrid' });
    let pick = null; const btns = {};
    W.forEach(([w, html, ipa]) => {
      const b = h('button', { class: 'pword', html });
      const hear = h('button', { class: 'btn', text: '🔊 Listen' });
      ctx.on(hear, 'click', () => Sound.speak(w));
      ctx.on(b, 'click', () => {
        pick = w; Sound.speak(w);
        Object.values(btns).forEach(x => { x.classList.toggle('is-picked', x === b); ctx.clearResult(x); });
      });
      btns[w] = b;
      grid.appendChild(h('div', { class: 'pwordbox' }, [b, Object.assign(h('div', { class: 'pron-ipa', text: '/ ? /' }), { __ipa: ipa }), hear]));
    });
    card.append(grid, h('div', { class: 'note', text: 'Listen to each word, then tap the odd one out' }));
    root.appendChild(h('div', { class: 'grow center-col' }, [card]));
    const reveal = on => grid.querySelectorAll('.pron-ipa').forEach(x => { x.textContent = on ? x.__ipa : '/ ? /'; });
    root.appendChild(ctx.buttons({
      check: () => {
        if (!pick) { Engine.toast('Tap a word first'); return null; }
        const ok = pick === ANS; ctx.markResult(btns[pick], ok); reveal(true);
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => { pick = ANS; Object.values(btns).forEach(x => { ctx.clearResult(x); x.classList.remove('is-picked'); }); btns[ANS].classList.add('is-picked'); ctx.markResult(btns[ANS], true); reveal(true); },
      reset: () => { pick = null; reveal(false); Object.values(btns).forEach(x => { ctx.clearResult(x); x.classList.remove('is-picked'); }); }
    }));
  }
});
