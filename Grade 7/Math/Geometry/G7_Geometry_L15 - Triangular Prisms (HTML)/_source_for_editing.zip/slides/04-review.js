Engine.register({
  id: 'review', section: 'Vocabulary', title: 'Review: match the meanings', mech: 'sort',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    const items = [
      { id: 'd1', label: 'a 3D shape with 2 triangular bases and 3 rectangular faces' },
      { id: 'd2', label: 'the bottom part of something; the foundation or supporting part' }
    ];
    const zones = [{ id: 'tp', accept: ['d1'], capacity: 1 }, { id: 'ba', accept: ['d2'], capacity: 1 }];
    const dd = ctx.dragDrop({ items, zones, renderZone: () => h('div', { class: 'slot revslot' }) });
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,1.25fr) minmax(0,1fr)' });
    const media = h('div', { class: 'media' }, [ctx.img('assets/img/image15.png', { alt: 'Word cards: triangular prism and base', class: 'hero-img' }), ctx.zoomHint()]);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'note', text: 'Tap a word to listen, then drag its meaning into the box' }));
    [['tp', 'triangular prism', 'c-blu'], ['ba', 'base', 'c-yel']].forEach(([z, w, c]) => {
      const b = h('button', { class: 'vchip ' + c, text: '🔊 ' + w });
      ctx.on(b, 'click', () => Sound.speak(w));
      right.appendChild(h('div', { class: 'revpair' }, [b, dd.zoneEls[z]]));
    });
    sp.append(media, right);
    root.appendChild(sp);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
