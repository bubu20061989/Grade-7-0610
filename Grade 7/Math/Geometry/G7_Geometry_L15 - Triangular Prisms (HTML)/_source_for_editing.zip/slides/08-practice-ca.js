Engine.register({
  id: 'practice-ca', section: 'Practice', title: 'C. Practice a) volume & areas', mech: 'cloze',
  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    const items = [{ id: 'base', label: 'base' }, { id: 'volume', label: 'volume' }, { id: 'n42', label: '42' }, { id: 'lat', label: 'lateral area' }, { id: 'n84', label: '84' }, { id: 'surf', label: 'surface area' }, { id: 'n96', label: '96' }];
    const zones = [{ id: 'z1', accept: ['base'], capacity: 1 }, { id: 'z2', accept: ['volume'], capacity: 1 }, { id: 'z3', accept: ['n42'], capacity: 1 }, { id: 'z4', accept: ['lat'], capacity: 1 }, { id: 'z5', accept: ['n84'], capacity: 1 }, { id: 'z6', accept: ['surf'], capacity: 1 }, { id: 'z7', accept: ['n96'], capacity: 1 }];
    const NUM = { z3: 1, z5: 1, z7: 1 }, WIDE = { z4: 1, z6: 1 };
    const dd = ctx.dragDrop({ items, zones, renderZone: z => h('div', { class: 'slot' + (NUM[z.id] ? ' num' : '') + (WIDE[z.id] ? ' wide' : '') }) });
    const Z = dd.zoneEls;
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.62fr) minmax(0,1.38fr)' });
    const fig = h('div', { class: 'prismfig' });
    /* đáy là tam giác vuông cạnh góc vuông 3 cm, 4 cm (cạnh huyền 5 cm), chiều cao lăng trụ 7 cm — lấy từ bài giải gốc */
    fig.innerHTML = '<svg viewBox="-30 -20 330 420" role="img" aria-label="Right triangular prism: legs 3 cm and 4 cm, hypotenuse 5 cm, height 7 cm">' +
      '<polygon class="fa" points="40,60 40,340 200,340 200,60" fill="#FDE68A" opacity=".55"/>' +
      '<polygon class="fa" points="40,60 200,60 120,20" fill="#FDBA74" opacity=".8"/>' +
      '<polyline class="ed" points="40,60 200,60 120,20 40,60"/><line class="ed" x1="40" y1="60" x2="40" y2="340"/><line class="ed" x1="200" y1="60" x2="200" y2="340"/>' +
      '<line class="ed" x1="40" y1="340" x2="200" y2="340"/><polyline class="ed hid" points="40,340 120,300 200,340"/><line class="ed hid" x1="120" y1="20" x2="120" y2="300"/>' +
      '<polyline points="110,25 105,35 115,40" fill="none" stroke="#1E293B" stroke-width="2.5"/>' +
      '<text class="dim" x="45" y="30">3</text><text class="dim" x="170" y="30">4</text><text class="dim" x="105" y="98">5</text><text class="dim" x="212" y="210">7</text>' +
      '<text class="dim" x="20" y="392" style="font-style:italic">(cm)</text></svg>';
    const left = h('div', { class: 'colfig' }, [h('div', { class: 'qcard small', html: '<b>a)</b> Find the volume, lateral area, and surface area of the triangular prism in the figure. Given that the bases are right triangles.' }), h('div', { class: 'media' }, [fig])]);
    const sol = h('div', { class: 'solcard' }, [
      h('div', { class: 'soltag', text: 'Solution' }),
      Lab.para('The area of the [[z1]] is ${1/2}$ × 3 × 4 = 6 cm².', Z),
      Lab.para('The [[z2]] of the triangular prism is: 6 × 7 = [[z3]] cm³.', Z),
      Lab.para('The [[z4]] of the triangular prism is: (3 + 4 + 5) × 7 = [[z5]] cm².', Z),
      Lab.para('The [[z6]] of the triangular prism is: 2 × 6 + 84 = [[z7]] cm².', Z)
    ]);
    sp.append(left, h('div', {}, [sol]));
    root.appendChild(sp);
    root.appendChild(dd.tray);
    const ans = { base: 'z1', volume: 'z2', n42: 'z3', lat: 'z4', n84: 'z5', surf: 'z6', n96: 'z7' };
    root.appendChild(ctx.buttons({
      check: () => Lab.ddCheck(ctx, dd, zones),
      show: () => { Lab.ddClear(ctx, dd); dd.reset(); Object.keys(ans).forEach(it => { const n = dd.tray.querySelector('[data-dd-id="' + it + '"]'); if (n) { Z[ans[it]].appendChild(n); dd.place[it] = ans[it]; } }); },
      reset: () => { Lab.ddClear(ctx, dd); dd.reset(); }
    }));
  }
});
