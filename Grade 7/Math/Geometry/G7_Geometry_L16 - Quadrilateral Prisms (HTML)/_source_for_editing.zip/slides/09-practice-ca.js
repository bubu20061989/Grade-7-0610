Engine.register({
  id: 'practice-ca',
  section: 'Practice',
  title: 'C. Practice a) volume and areas',
  mech: 'cloze',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'panel fixed', style: 'font-size:var(--f-small)', html:
      '<b style="color:#0369A1">a)</b> Find the volume, lateral area, and surface area, of the quadrilateral prism in the figure, ' +
      'given that each base is a parallelogram with an area of 18 cm<sup>2</sup>. AB = 6 cm, BC = 4 cm, AM = 5 cm.' }));
    const media = h('div', { class: 'media colhalf panel', style: 'flex:.42 1 0' });
    media.appendChild(Lab.crop(ctx, 'assets/img/image21.png', 2097, 750, [1305, 60, 792, 600], 'Quadrilateral prism with AB = 6 cm, BC = 4 cm, AM = 5 cm'));
    media.firstChild.style.flex = '1 1 16vh';
    media.appendChild(ctx.zoomHint());
    const items = [
      { id: 'area', label: 'area' }, { id: 'volume', label: 'volume' }, { id: '90', label: '90' },
      { id: 'lateral', label: 'lateral area' }, { id: '100', label: '100' },
      { id: 'surface', label: 'surface area' }, { id: '136', label: '136' }
    ];
    const dd = ctx.dragDrop({
      items,
      zones: items.map(it => ({ id: 'z' + it.id, accept: [it.id], capacity: 1 })),
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const Z = {}; items.forEach(it => { Z[it.id] = dd.zoneEls['z' + it.id]; });
    const sol = h('div', { class: 'panel colhalf', style: 'flex:1.6 1 0;align-items:stretch;background:#F0F9FF;border-color:#7DD3FC;justify-content:center' });
    sol.append(
      h('div', { class: 'tag', style: 'align-self:flex-start;color:#1E3A8A', text: 'Solution' }),
      Lab.sentence('• The [area] of each base is 18 cm<sup>2</sup>.', Z),
      Lab.sentence('• The [volume] of the quadrilateral prism is: 18 × 5 = [90] cm<sup>3</sup>.', Z),
      Lab.sentence('• The [lateral] of the quadrilateral prism is: 2(6 + 4) × 5 = [100] cm<sup>2</sup>.', Z),
      Lab.sentence('• The [surface] of the quadrilateral prism is: 2 × 18 + 100 = [136] cm<sup>2</sup>.', Z)
    );
    root.appendChild(h('div', { class: 'rowwrap nowrap stackp stagger', style: 'min-height:auto' }, [sol, media]));
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
