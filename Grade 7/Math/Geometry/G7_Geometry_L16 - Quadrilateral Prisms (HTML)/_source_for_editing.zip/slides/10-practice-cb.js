Engine.register({
  id: 'practice-cb',
  section: 'Practice',
  title: 'C. Practice b) find the height',
  mech: 'keypad',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'C. Practice' }));
    root.appendChild(h('div', { class: 'panel fixed', style: 'font-size:var(--f-small)', html:
      '<b style="color:#0369A1">b)</b> A quadrilateral prism has the volume of 80 cm<sup>3</sup> and the area of each base is 20 cm<sup>2</sup>. Find the height of the quadrilateral prism.' }));
    const media = h('div', { class: 'media colhalf panel', style: 'flex:.8 1 0' });
    media.appendChild(Lab.crop(ctx, 'assets/img/image24.png', 2094, 751, [1220, 150, 760, 530], 'Quadrilateral prism ABCD.A′B′C′D′ with height h'));
    media.firstChild.style.flex = '1 1 16vh';
    media.appendChild(ctx.zoomHint());
    const row = h('div', { class: 'rowwrap nowrap stagger', style: 'min-height:auto' });
    const sol = h('div', { class: 'panel colhalf', style: 'flex:1.5 1 0;min-height:auto;background:#F0F9FF;border-color:#7DD3FC;align-items:stretch' });
    const why = [0, 1].map(() => h('span', { class: 'why chip', style: 'min-height:1.4em;border-style:dashed;font-size:var(--f-small)', text: '…' }));
    const ans = h('span', { class: 'ansbox', text: '?' });
    sol.append(
      h('div', { class: 'sent', style: 'font-size:var(--f-small)', text: 'Let h (cm) be the height of the quadrilateral prism. We obtain 20 × h = 80. Solve the equation to find h,' }),
      h('div', { class: 'sent', style: 'display:grid;grid-template-columns:auto 1fr;gap:.2em .6em;align-items:center' }, [
        h('span', { text: '20 × h = 80' }), why[0],
        h('span', { text: 'h = 80 ÷ 20' }), why[1],
        h('span', { text: 'h =' }), h('div', {}, [ans])
      ])
    );
    const opts = ['Divide both sides by 20.', 'We obtain h = 4.'];
    const optRow = h('div', { class: 'optrow' });
    const filled = [null, null];
    ctx.shuffle(opts).forEach(t => {
      const b = h('button', { class: 'opt', style: 'font-size:var(--f-small);padding:.25em .6em', text: '👆 ' + t });
      ctx.on(b, 'click', () => {
        if (b.classList.contains('picked')) return;
        const k = filled.indexOf(null); if (k < 0) return;
        filled[k] = t; why[k].textContent = t; why[k].style.borderStyle = 'solid'; b.classList.add('picked');
      });
      optRow.appendChild(b);
    });
    sol.appendChild(optRow);

    const padCol = h('div', { class: 'colhalf', style: 'flex:.7 1 0' });
    let val = '';
    const pad = h('div', { class: 'keypad', style: 'grid-template-columns:repeat(3,minmax(0,1fr))' });
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', 'C'].forEach(k => {
      const b = h('button', { class: 'key', text: k });
      ctx.on(b, 'click', () => {
        if (k === 'C') val = ''; else if (k === '⌫') val = val.slice(0, -1); else if (val.length < 3) val += k;
        ans.textContent = val || '?';
        ctx.clearResult(ans);
      });
      pad.appendChild(b);
    });
    padCol.append(h('div', { class: 'note', text: 'h = ? (cm)' }), pad);
    row.append(media, sol, padCol);
    root.appendChild(row);

    const resetOpts = () => {
      filled[0] = filled[1] = null;
      why.forEach(w => { w.textContent = '…'; w.style.borderStyle = 'dashed'; ctx.clearResult(w); });
      optRow.querySelectorAll('.opt').forEach(o => o.classList.remove('picked'));
    };
    const done = 'Hence, the height of the quadrilateral prism is 4 cm.';
    root.appendChild(ctx.buttons({
      check: () => {
        const r = [val === '4', filled[0] === opts[0], filled[1] === opts[1]];
        ctx.markResult(ans, r[0]); ctx.markResult(why[0], r[1]); ctx.markResult(why[1], r[2]);
        const c = r.filter(Boolean).length;
        if (c === 3) Engine.toast(done);
        return { correct: c, total: 3 };
      },
      show: () => {
        val = '4'; ans.textContent = '4'; ctx.clearResult(ans);
        resetOpts();
        opts.forEach((t, k) => { filled[k] = t; why[k].textContent = t; why[k].style.borderStyle = 'solid'; });
        optRow.querySelectorAll('.opt').forEach(o => o.classList.add('picked'));
        Engine.toast(done);
      },
      reset: () => { val = ''; ans.textContent = '?'; ctx.clearResult(ans); resetOpts(); }
    }));
  }
});
