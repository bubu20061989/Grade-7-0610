Engine.register({
  id: 'practice-b',
  section: 'Practice',
  title: 'B. Practice: describe the prism',
  mech: 'cloze',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'B. Practice' }));
    root.appendChild(h('div', { class: 'note fixed', style: 'color:#9A3412;font-weight:800', text: 'Fill in the blanks with suitable words to describe the quadrilateral prism.' }));
    const words = ['vertex', 'edges', 'parallel', 'bases', 'height'];
    const dd = ctx.dragDrop({
      items: words.map(w => ({ id: w, label: w })),
      zones: words.map(w => ({ id: 'z-' + w, accept: [w], capacity: 1 })),
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const Z = {}; words.forEach(w => { Z[w] = dd.zoneEls['z-' + w]; });
    const sp = h('div', { class: 'split stagger', style: 'min-height:auto;grid-template-columns:minmax(0,.62fr) minmax(0,1.6fr)' });
    const media = h('div', { class: 'media' });
    media.appendChild(Lab.crop(ctx, 'assets/img/image20.png', 1938, 812, [1340, 20, 598, 700], 'Quadrilateral prism ABCD.A′B′C′D′'));
    media.appendChild(ctx.zoomHint());
    const right = h('div', { class: 'panel', style: 'min-height:auto' });
    right.append(
      Lab.sentence('a) D′ is a [vertex] of the quadrilateral prism ABCD.A′B′C′D′.', Z),
      Lab.sentence('b) The two [edges] AD and A′D′ are [parallel].', Z),
      Lab.sentence('c) The two parallel [bases] ABCD and A′B′C′D′ are congruent.', Z),
      Lab.sentence('d) The length of DD′ is the [height] of the quadrilateral prism ABCD.A′B′C′D′.', Z)
    );
    sp.append(media, right);
    root.appendChild(sp);
    root.appendChild(dd.tray);
    root.appendChild(ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() }));
  }
});
