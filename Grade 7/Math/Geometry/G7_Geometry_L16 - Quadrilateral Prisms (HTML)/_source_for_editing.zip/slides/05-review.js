Engine.register({
  id: 'review',
  section: 'Vocabulary',
  title: 'Review: Listen and tap',
  mech: 'listen',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Review' }));
    root.appendChild(h('div', { class: 'note fixed', text: 'Listen or read, then tap the right word card.' }));
    const prompts = ctx.shuffle([
      { k: 'prism', t: 'a 3D shape with 2 quadrilateral bases and 4 rectangular faces.' },
      { k: 'total', t: 'the complete amount of surface area of a three-dimensional object, including all of its faces.' },
      { k: 'prism', t: 'A ______ has two quadrilateral bases and four rectangular faces.', s: 'A blank has two quadrilateral bases and four rectangular faces.' },
      { k: 'total', t: 'The ______ of the prism is 100 cm².', s: 'The blank of the prism is 100 square centimetres.' }
    ]);
    let n = 0, firstOk = 0, tried = false;
    const grow = h('div', { class: 'grow stagger' });
    const q = h('div', { class: 'panel txt fixed', style: 'text-align:center;display:flex;align-items:center;justify-content:center;gap:.5em' });
    const qText = h('span', {});
    const counter = h('span', { class: 'tag' });
    q.append(counter, qText);
    const grid = h('div', { class: 'imgrid', style: 'grid-template-columns:repeat(2,minmax(0,1fr))' });
    const cells = {};
    [['prism', [0, 0, 880, 887], 'quadrilateral prism'], ['total', [880, 0, 894, 887], 'total area']].forEach(([k, r, w]) => {
      const cell = h('div', { class: 'cell' });
      const pic = h('div', { class: 'crop', style: 'cursor:pointer' });
      pic.innerHTML = Lab.cropSVG('assets/img/image17.png', 1774, 887, r, w);
      cell.appendChild(pic);
      ctx.on(cell, 'click', () => {
        if (n >= prompts.length) return;
        const ok = prompts[n].k === k;
        ctx.markResult(cell, ok, { sound: true });
        if (!tried && ok) firstOk++;
        tried = true;
        if (ok) { n++; ctx.timeout(() => { ctx.clearResult(cell); show(); }, 900); }
      });
      cells[k] = cell; grid.appendChild(cell);
    });
    const show = () => {
      tried = false;
      Object.values(cells).forEach(c => ctx.clearResult(c));
      if (n >= prompts.length) {
        counter.textContent = '🎉';
        qText.textContent = 'Great listening! ' + firstOk + ' / ' + prompts.length + ' on the first try.';
        Engine.score(firstOk, prompts.length);
        return;
      }
      counter.textContent = (n + 1) + ' / ' + prompts.length;
      qText.textContent = prompts[n].t;
    };
    grow.append(q, grid);
    root.appendChild(grow);
    const listen = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    ctx.on(listen, 'click', () => { const p = prompts[Math.min(n, prompts.length - 1)]; Sound.speak(p.s || p.t); });
    const again = h('button', { class: 'btn btn-reset', text: '↺ Start again' });
    ctx.on(again, 'click', () => { n = 0; firstOk = 0; show(); });
    root.appendChild(h('div', { class: 'btnrow fixed' }, [listen, again]));
    show();
  }
});
