Engine.register({
  id: 'vocab',
  section: 'Vocabulary',
  title: 'Vocabulary flashcards',
  mech: 'flashcard',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Vocabulary' }));
    const cards = [
      { w: 'quadrilateral prism', r: [0, 0, 880, 887],
        d: 'a 3D shape with 2 quadrilateral bases and 4 rectangular faces.',
        ex: 'A <b>quadrilateral prism</b> has two quadrilateral bases and four rectangular faces.' },
      { w: 'total area', r: [880, 0, 894, 887],
        d: 'the complete amount of surface area of a three-dimensional object, including all of its faces.',
        ex: 'The <b>total area</b> of the prism is 100 cm<sup>2</sup>.' }
    ];
    let i = 0;
    const grow = h('div', { class: 'grow stagger' });
    const wrap = h('div', { class: 'fc-wrap' });
    const fc = h('div', { class: 'fc', style: 'width:min(86vw,96vh,100%)' });
    const front = h('div', { class: 'face front' });
    const back = h('div', { class: 'face back' });
    fc.append(front, back); wrap.appendChild(fc);
    const dots = h('div', { class: 'dots' });
    const seen = {};
    const paint = () => {
      const c = cards[i];
      fc.classList.remove('flipped');
      front.innerHTML = '';
      const pic = h('div', { class: 'crop' });
      pic.innerHTML = Lab.cropSVG('assets/img/image17.png', 1774, 887, c.r, c.w);
      front.append(pic, h('div', { class: 'muted', text: 'Tap the card to see the meaning' }));
      back.innerHTML = '';
      back.append(
        h('div', { class: 'txt', style: 'text-align:center', text: c.d }),
        h('div', { class: 'txt', style: 'text-align:center', html: '<b>Example:</b> ' + c.ex }));
      seen[i] = 1;
      dots.innerHTML = '';
      cards.forEach((_, k) => dots.appendChild(h('i', { class: k === i ? 'now' : (seen[k] ? 'done' : '') })));
      fc.classList.remove('pop-in'); void fc.offsetWidth; fc.classList.add('pop-in');
    };
    ctx.on(fc, 'click', () => { fc.classList.toggle('flipped'); Sound.playEffect('click'); });
    grow.append(wrap, dots);
    root.appendChild(grow);
    const prev = h('button', { class: 'btn', text: '◀ Back' });
    const listen = h('button', { class: 'btn btn-primary', text: '🔊 Listen' });
    const rep = h('button', { class: 'btn', text: '🔁 x3' });
    const next = h('button', { class: 'btn', text: 'Next card ▶' });
    ctx.on(prev, 'click', () => { i = (i + cards.length - 1) % cards.length; paint(); });
    ctx.on(next, 'click', () => { i = (i + 1) % cards.length; paint(); });
    ctx.on(listen, 'click', () => {
      const c = cards[i];
      Sound.speak(fc.classList.contains('flipped') ? c.w + '. ' + c.d : c.w);
    });
    ctx.on(rep, 'click', () => Sound.repeat(cards[i].w, 3));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [prev, listen, rep, next]));
    paint();
  }
});
