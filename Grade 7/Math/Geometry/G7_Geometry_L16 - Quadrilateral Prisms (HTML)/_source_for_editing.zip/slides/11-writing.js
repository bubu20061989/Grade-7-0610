Engine.register({
  id: 'writing',
  section: 'Writing',
  title: 'D. Writing: the tent',
  mech: 'write',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'D. Writing' }));
    const grow = h('div', { class: 'grow stagger' });
    const row = h('div', { class: 'rowwrap' });
    const left = h('div', { class: 'colhalf panel', style: 'flex:1 1 0' });
    left.appendChild(h('div', { class: 'sent', style: 'font-size:var(--f-small)', html: '<b>a)</b> The tent in the figure is a quadrilateral prism. Find the <b>lateral area</b> of the tent. <span class="muted">🔍 Click to zoom in</span>' }));
    const tent = ctx.img('assets/img/image25.png', { alt: 'A tent shaped like a quadrilateral prism: 2 m, 2 m, 1 m, length 5 m', class: 'hero-img' });
    tent.style.flex = '1 1 20vh';
    left.appendChild(tent);
    const right = h('div', { class: 'colhalf', style: 'flex:1 1 0;align-items:stretch' });
    const wa = h('div', { class: 'workarea drawwrap' });
    const cv = ctx.canvas({ color: '#1D4ED8', width: 6 });
    cv.style.background = 'transparent'; cv.style.border = '0';
    wa.appendChild(cv);
    const tools = h('div', { class: 'btnrow tools' });
    [['Blue', '#1D4ED8'], ['Red', '#DC2626']].forEach(([n, c]) => {
      const b = h('button', { class: 'btn', style: 'color:' + c, text: '● ' + n });
      ctx.on(b, 'click', () => { cv.__color = c; });
      tools.appendChild(b);
    });
    const undo = h('button', { class: 'btn', text: '↩ Undo' }); ctx.on(undo, 'click', () => cv.__undo());
    const clr = h('button', { class: 'btn', text: '🧽 Clear' }); ctx.on(clr, 'click', () => cv.__clear());
    tools.append(undo, clr);
    right.append(h('div', { class: 'note', text: 'Work it out here ✏️' }), wa, tools);
    row.append(left, right);
    grow.appendChild(row);

    const steps = [
      'A<sub>lateral</sub> = P<sub>base</sub> × h',
      'Perimeter of the base: P<sub>base</sub> = 2 + 2 + 3 + <span class="sq">√<span class="rad">5</span></span> = 7 + <span class="sq">√<span class="rad">5</span></span> (m)',
      'Lateral area: A<sub>lateral</sub> = (7 + <span class="sq">√<span class="rad">5</span></span>) × 5 = 35 + 5<span class="sq">√<span class="rad">5</span></span> (m<sup>2</sup>)',
      'A<sub>lateral</sub> ≈ 35 + 5 × 2.236 ≈ 46.18 (m<sup>2</sup>)'
    ];
    const box = h('div', { class: 'panel steps fixed', style: 'background:#FEF2F2;border-color:#FCA5A5;font-size:var(--f-btn)' });
    const hint = h('div', { class: 'st hint', text: 'Try it first, then tap “Show next step”.' });
    box.appendChild(hint);
    grow.appendChild(box);
    root.appendChild(grow);
    let k = 0;
    const next = h('button', { class: 'btn btn-show', text: '👁 Show next step' });
    ctx.on(next, 'click', () => {
      if (k >= steps.length) return;
      if (k === 0) hint.remove();
      const d = h('div', { class: 'st red', html: steps[k++] });
      box.appendChild(d); void d.offsetWidth; d.classList.add('on');
      if (k === steps.length) Engine.score(1, 1);
    });
    const rs = h('button', { class: 'btn btn-reset', text: '↺ Reset' });
    ctx.on(rs, 'click', () => { k = 0; cv.__clear(); box.innerHTML = ''; box.appendChild(hint); });
    const tm = h('button', { class: 'btn', text: '⏱ 3 min' }); ctx.on(tm, 'click', () => Engine.timer(180));
    root.appendChild(h('div', { class: 'btnrow fixed' }, [tm, next, rs]));
  }
});
