Engine.register({
  id: 'maths-corner',
  section: 'Maths Corner',
  title: 'What is a quadrilateral prism?',
  mech: 'fact',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Maths Corner' }));
    const sp = h('div', { class: 'split stagger', style: 'grid-template-columns:minmax(0,.8fr) minmax(0,1.25fr)' });
    const media = h('div', { class: 'media' });
    const viz = h('div', { class: 'viz' });
    viz.innerHTML = Lab.prismSVG();
    media.appendChild(viz);
    const right = h('div', {});
    right.appendChild(h('div', { class: 'qhead', style: 'color:#1E3A8A', text: 'What is a quadrilateral prism?' }));
    right.appendChild(h('div', { class: 'txt', text: 'A quadrilateral prism is a 3D shape with 2 quadrilateral bases and 4 rectangular faces.' }));
    right.appendChild(h('div', { class: 'txt', style: 'font-weight:800', text: 'The quadrilateral prism ABCD.EFGH has:' }));
    const facts = [
      ['show-v', '8 vertices: A, B, C, D, E, F, G, and H.'],
      ['show-e', '4 parallel congruent edges: AE = BF = CG = DH.'],
      ['show-b', '2 parallel bases: ABCD and EFGH.'],
      ['show-h', 'The length of AE is the height of the quadrilateral prism.']
    ];
    const list = h('div', { style: 'display:flex;flex-direction:column;gap:clamp(6px,1.1vh,14px)' });
    const svg = () => viz.querySelector('svg');
    facts.forEach(([cls, t]) => {
      const b = h('button', { class: 'opt', style: 'text-align:left;padding:.3em .7em', text: '👆 ' + t });
      ctx.on(b, 'click', () => {
        list.querySelectorAll('.opt').forEach(o => o.classList.remove('picked'));
        b.classList.add('picked');
        svg().classList.remove('show-v', 'show-e', 'show-b', 'show-h');
        svg().classList.add(cls);
        Sound.speak(t.replace('ABCD.EFGH', 'A B C D dot E F G H'));
      });
      list.appendChild(b);
    });
    right.appendChild(list);
    sp.append(media, right);
    root.appendChild(sp);
    root.appendChild(h('div', { class: 'note fixed', text: 'Tap each fact to see it on the prism.' }));
  }
});
