Engine.register({
  id: 'cover',
  section: 'Start',
  title: 'Lesson 16: Quadrilateral Prisms',
  mech: 'cover',

  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger', style: 'padding-left:11vw' });
    const txt = h('div', { class: 'cover-text' });
    txt.appendChild(h('div', { class: 'tagrow' }, [
      h('span', { class: 'tag', text: 'Grade 7' }),
      h('span', { class: 'tag', text: 'Chapter 4: Geometry' })
    ]));
    const t = h('div', { class: 'hero-title' });
    t.innerHTML = 'Lesson 16:<br><em>Quadrilateral</em> Prisms';
    const go = h('button', { class: 'btn btn-primary pulse', text: "▶ Let's start" });
    ctx.on(go, 'click', () => Engine.next());
    txt.append(t, h('div', { class: 'hero-sub', text: 'Let’s explore English in Maths' }),
      h('div', { class: 'hero-sub', text: '👆 Tap the prism to explore it' }), h('div', { class: 'btnrow' }, [go]));

    const media = h('div', { class: 'cover-media' });
    const card = h('div', { class: 'viz', style: 'width:72%;height:84%' });
    card.innerHTML = Lab.prismSVG();
    media.appendChild(card);
    const steps = [
      ['show-b', 'Two quadrilateral bases'],
      ['show-f', 'Four rectangular faces'],
      ['show-e', 'Four parallel edges'],
      ['show-v', 'Eight vertices'],
      ['', 'Quadrilateral prism']
    ];
    let k = 0;
    ctx.on(card, 'click', () => {
      const svg = card.querySelector('svg');
      svg.classList.remove('show-b', 'show-f', 'show-e', 'show-v');
      const s = steps[k % steps.length]; k++;
      if (s[0]) svg.classList.add(s[0]);
      Engine.toast(s[1]);
      Sound.speak(s[1]);
    });
    cov.append(txt, media);
    root.appendChild(cov);
  }
});
