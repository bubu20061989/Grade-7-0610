Engine.register({
  id: 'odd-one-out',
  section: 'Warm-up',
  title: 'The Shape Detective: Odd One Out',
  mech: 'pick',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'The Shape Detective' }));
    const sp = h('div', { class: 'split stagger' });
    const media = h('div', { class: 'media' });
    media.appendChild(ctx.img('assets/img/image14.png', { alt: 'Which shape is the odd one out, and why? Shapes A, B, C, D', class: 'hero-img' }));
    media.appendChild(ctx.zoomHint());

    const right = h('div', {});
    const banner = ctx.img('assets/img/image13.png', { alt: 'The Shape Detective: Odd One Out', class: 'fitimg' });
    banner.style.flex = '0 1 24vh';
    banner.style.borderRadius = '22px';
    right.appendChild(banner);
    right.appendChild(h('div', { class: 'qhead', html: 'Which shape is the <span class="red">odd one out</span>, and why?' }));
    const reasons = {
      A: ['ok', '<b>A</b> is different: all 6 faces are identical squares.'],
      B: ['bad', '<b>B</b> has two quadrilateral bases, like A and C. Look again!'],
      C: ['bad', '<b>C</b> has two quadrilateral bases, like A and B. Look again!'],
      D: ['ok', '<b>D</b> is different: its base is a triangle, not a quadrilateral.']
    };
    const row = h('div', { class: 'optrow' });
    const reason = h('div', { class: 'reason panel', text: 'Think for 45 seconds, then tap a letter.' });
    let scored = false;
    ['A', 'B', 'C', 'D'].forEach(L => {
      const b = h('button', { class: 'opt', text: L, style: 'min-width:2.6em' });
      ctx.on(b, 'click', () => {
        row.querySelectorAll('.opt').forEach(o => ctx.clearResult(o));
        const ok = reasons[L][0] === 'ok';
        ctx.markResult(b, ok, { sound: true });
        reason.innerHTML = reasons[L][1];
        if (ok && !scored) { scored = true; Engine.score(1, 1); }
      });
      row.appendChild(b);
    });
    right.append(row, reason);
    const tm = h('button', { class: 'btn', text: '⏱ 45s' });
    ctx.on(tm, 'click', () => Engine.timer(45));
    const show = h('button', { class: 'btn btn-show', text: '👁 Show ideas' });
    ctx.on(show, 'click', () => {
      reason.innerHTML = reasons.A[1] + '<br>' + reasons.D[1] +
        '<br>Today: solids with two identical and parallel quadrilateral bases — <b>Quadrilateral Prisms</b>!';
    });
    right.appendChild(h('div', { class: 'btnrow' }, [tm, show]));
    sp.append(media, right);
    root.appendChild(sp);
  }
});
