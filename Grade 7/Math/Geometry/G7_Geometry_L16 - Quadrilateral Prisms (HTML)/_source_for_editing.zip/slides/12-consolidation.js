Engine.register({
  id: 'consolidation',
  section: 'Wrap-up',
  title: 'Consolidation',
  mech: 'build',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Consolidation' }));
    const card = h('div', { class: 'stagecard stagger', style: 'align-items:stretch' });
    const voc = h('div', { class: 'optrow', style: 'align-items:center' });
    voc.appendChild(h('span', { class: 'txt', style: 'font-weight:800', text: 'Vocabulary:' }));
    ['quadrilateral prism', 'total area'].forEach(w => {
      const b = h('button', { class: 'opt', style: 'color:#9A3412', text: '🔊 ' + w });
      ctx.on(b, 'click', () => Sound.speak(w));
      voc.appendChild(b);
    });
    card.appendChild(voc);
    card.appendChild(h('div', { class: 'sent', text: '• Find the volume, the lateral area and surface area of the quadrilateral prism.' }));
        const words = ['vertices', 'edges', 'bases'];
    const dd = ctx.dragDrop({
      items: words.map(w => ({ id: w, label: w })),
      zones: words.map(w => ({ id: 'z' + w, accept: [w], capacity: 1 })),
      renderZone: () => h('span', { class: 'dd-zone slot' })
    });
    const Z = {}; words.forEach(w => { Z[w] = dd.zoneEls['z' + w]; });
    const s = Lab.sentence('<b style="color:#2D2A26">• Sentence Patterns:</b> <i>The quadrilateral prism ABCD.EFGH has 8 </i>[vertices]<i>: A, B, C, D, E, F, G, and H; 4 parallel congruent </i>[edges]<i>: AE = BF = CG = DH; 2 parallel </i>[bases]<i>: ABCD and EFGH.</i>', Z);
    s.style.color = '#9A3412';
    card.appendChild(s);
    card.appendChild(dd.tray);
    card.appendChild(h('div', { class: 'sent', text: '• Prepare the next lesson.' }));
    root.appendChild(h('div', { class: 'grow center-col', style: 'min-height:auto' }, [card]));
    const listen = h('button', { class: 'btn', text: '🔊 Listen' });
    ctx.on(listen, 'click', () => Sound.speak('The quadrilateral prism A B C D dot E F G H has 8 vertices: A, B, C, D, E, F, G, and H; 4 parallel congruent edges: A E equals B F equals C G equals D H; 2 parallel bases: A B C D and E F G H.'));
    const row = ctx.buttons({ check: () => dd.check(), show: () => dd.show(), reset: () => dd.reset() });
    row.insertBefore(listen, row.firstChild);
    root.appendChild(row);
  }
});
