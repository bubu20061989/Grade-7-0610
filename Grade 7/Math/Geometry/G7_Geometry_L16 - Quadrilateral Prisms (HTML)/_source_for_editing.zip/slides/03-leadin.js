Engine.register({
  id: 'leadin',
  section: 'Warm-up',
  title: 'Lead-in: What shapes are those?',
  mech: 'reveal',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'Lead-in' }));
    const grow = h('div', { class: 'grow stagger' });
    const pic = h('div', { class: 'panel grow center-col' });
    pic.appendChild(h('div', { class: 'fill-w grow center-col' }, [ctx.img('assets/img/image16.png', { alt: 'A table, an ambulance and a wooden shelf', class: 'hero-img' })]));
    pic.appendChild(ctx.zoomHint());
    grow.appendChild(pic);

    const row = h('div', { class: 'fixed', style: 'display:flex;align-items:center;justify-content:center;gap:clamp(10px,2vw,30px);height:clamp(120px,24vh,300px)' });
    const boy = ctx.img('assets/img/image15.png', { alt: 'A boy thinking', zoom: false, class: 'fitimg float-anim' });
    boy.style.height = '100%'; boy.style.width = 'auto'; boy.style.flex = '0 0 auto';
    const bubble = h('div', { class: 'bubble', text: 'What shapes are those?' });
    const side = h('div', { style: 'display:flex;flex-direction:column;gap:clamp(6px,1.2vh,14px);align-items:center' });
    const ans = h('div', { class: 'reason', text: 'Think · Pair · Share' });
    const tm = h('button', { class: 'btn', text: '⏱ 30s' });
    ctx.on(tm, 'click', () => Engine.timer(30));
    const rv = h('button', { class: 'btn btn-primary', text: '💡 Reveal' });
    ctx.on(rv, 'click', () => {
      ans.innerHTML = 'They all look like <b>quadrilateral prisms</b>!';
      ans.classList.remove('pop-in'); void ans.offsetWidth; ans.classList.add('pop-in');
      Sound.speak('They all look like quadrilateral prisms!');
    });
    side.append(ans, h('div', { class: 'btnrow' }, [tm, rv]));
    row.append(boy, h('div', { style: 'display:flex;flex-direction:column;gap:12px;align-items:center' }, [bubble, side]));
    grow.appendChild(row);
    root.appendChild(grow);
  }
});
