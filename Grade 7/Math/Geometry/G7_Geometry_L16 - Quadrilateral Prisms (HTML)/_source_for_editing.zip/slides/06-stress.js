Engine.register({
  id: 'stress',
  section: 'Pronunciation',
  title: 'A. Pronunciation: word stress',
  mech: 'quiz',

  render(root, ctx) {
    root.appendChild(h('div', { class: 'pill fixed', text: 'A. Pronunciation' }));
    const card = h('div', { class: 'stagecard stagger' });
    card.appendChild(h('div', { class: 'qhead', text: 'Find the word that has a different stress pattern from the others.' }));
    card.appendChild(h('div', { class: 'note', text: 'Tap a word to hear it and choose it.' }));
    const words = [
      { w: 'quadrilateral', ipa: '/ˌkwɒdrɪˈlætərəl/', syl: ['quad', 'ri', '*lat', 'er', 'al'] },
      { w: 'diagonal', ipa: '/daɪˈæɡənəl/', syl: ['di', '*ag', 'o', 'nal'] },
      { w: 'triangular', ipa: '/traɪˈæŋɡjələr/', syl: ['tri', '*an', 'gu', 'lar'] },
      { w: 'rectangular', ipa: '/rekˈtæŋɡjələr/', syl: ['rec', '*tan', 'gu', 'lar'] }
    ];
    const grid = h('div', { class: 'optgrid', style: 'grid-template-columns:repeat(2,minmax(0,1fr));width:100%' });
    let picked = null;
    const btns = words.map(it => {
      const b = h('button', { class: 'opt word' });
      const ww = h('span', {});
      it.syl.forEach(s => ww.appendChild(h('span', { class: 'syl' + (s[0] === '*' ? ' st' : ''), text: s.replace('*', '') })));
      b.append(ww, h('span', { class: 'ipa', text: it.ipa }));
      ctx.on(b, 'click', () => {
        btns.forEach(x => { x.classList.remove('picked'); ctx.clearResult(x); });
        b.classList.add('picked'); picked = it.w;
        Sound.speak(it.w);
      });
      grid.appendChild(b);
      return b;
    });
    card.appendChild(grid);
    const g = h('div', { class: 'grow center-col' }, [card]);
    root.appendChild(g);
    root.appendChild(ctx.buttons({
      check: () => {
        const ok = picked === 'quadrilateral';
        btns.forEach((b, i) => { if (b.classList.contains('picked')) ctx.markResult(b, ok); });
        if (!picked) Engine.toast('Choose a word first');
        if (ok) grid.classList.add('show-stress');
        return { correct: ok ? 1 : 0, total: 1 };
      },
      show: () => {
        grid.classList.add('show-stress');
        btns.forEach(x => ctx.clearResult(x));
        ctx.markResult(btns[0], true);
        Engine.toast('quad-ri-LAT-er-al: stress on the 3rd syllable. The others: 2nd syllable.');
      },
      reset: () => {
        picked = null; grid.classList.remove('show-stress');
        btns.forEach(x => { x.classList.remove('picked'); ctx.clearResult(x); });
      }
    }));
  }
});
