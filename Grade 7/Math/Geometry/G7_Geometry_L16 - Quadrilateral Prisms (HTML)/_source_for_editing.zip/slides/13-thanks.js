Engine.register({
  id: 'thanks',
  section: 'Wrap-up',
  title: 'Thanks!',
  mech: 'cover',

  render(root, ctx) {
    const cov = h('div', { class: 'cover stagger' });
    const media = h('div', { class: 'cover-media' });
    const im = ctx.img('assets/img/image3.png', { alt: 'Geometry tools: compass, set square, board and book', zoom: false, class: 'hero-img float-anim' });
    media.appendChild(im);
    const txt = h('div', { class: 'cover-text' });
    const t = h('div', { class: 'hero-title' }); t.innerHTML = '<em>Thanks!</em>';
    const quote = 'Keep your curiosity active and your logic steady.';
    const stars = Engine.stars || 0;
    const doneN = Object.keys(Engine.done || {}).length;
    const msg = stars > 0 ? '⭐ You earned ' + stars + (stars === 1 ? ' star' : ' stars') + ' today!'
      : (doneN > 2 ? 'Good effort today — keep practising!' : 'Try the activities to earn stars!');
    txt.append(h('div', { class: 'tagrow' }, [h('span', { class: 'tag', text: 'Lesson 16 · Quadrilateral Prisms' })]), t,
      h('div', { class: 'hero-sub', style: 'color:#0E7490;font-style:italic', text: '“' + quote + '”' }),
      h('div', { class: 'hero-sub', text: msg }));
    const wrong = (Engine.wrongList() || []).filter(id => Engine.slides.some(s => s.id === id));
    if (wrong.length) {
      const r = h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [h('span', { class: 'hero-sub', text: "Let's review:" })]);
      wrong.slice(0, 3).forEach(id => {
        const s = Engine.slides.find(x => x.id === id);
        const b = h('button', { class: 'btn', style: 'font-size:var(--f-small)', text: s.title });
        ctx.on(b, 'click', () => Lab.goTo(id));
        r.appendChild(b);
      });
      txt.appendChild(r);
    }
    const cel = h('button', { class: 'btn btn-primary pulse', text: '🎉 Celebrate' });
    ctx.on(cel, 'click', () => { Engine.confetti('star'); Sound.speak(quote); });
    txt.appendChild(h('div', { class: 'btnrow', style: 'justify-content:flex-start' }, [cel]));
    cov.append(media, txt);
    root.appendChild(cov);
  }
});
